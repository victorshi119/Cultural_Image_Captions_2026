यो मान्छे    This man(sing.)
यी मान्छेहरू    These men (pl.)
दुई दिन    two days
पाँच साल    five years
धैरै किताबहरू    many books
धेरै किताब    many books
नेपालका मान्छेहरू     men of Nepal
छोराका किताबहरू    the son's books
रामका बहिनीहरू    Ram's sisters
पुरानो मन्दिर    the/an old temple
ठूलो शहर    the/ a big city
राम्रो सिनेमा    the/ a good film
यो किताब    this book
त्यो देश    that country
यो केटा    this boy
त्यो आइमाई    that woman.
मेरो घर त्यहाँ छ।    My house is there.
हामो देश नेपाल हो।    Our country is Nepal.
ठूला राजाहरू    Old temples
पुराना शहरहरू    My sons
मेरा किताबहरू    Big cities
त्यो राम्रो मान्छे हो।    He's a goodlooking man
त्यो असल मान्छे हो।    He's a good man (ref. to character)
पानी मीठो छ।    The water tastes good.
पानी असल छ।    The water is good (for drinking)
त्यो होटेल बेस छ।    That hotel is good.
सिनेमा बेसै छ।    The film is fairly good.
त्यो पसलमा असल असल माल छ।    There are all kinds of good things in the shop.
खोलामा सानसाना माछा धेरै छन्।    In the river there are lots of little fish.
भारतमा ठूलठूला शहरहरू छन्।    In India there are many big cities.
कलकत्ता दिल्ली भन्दा ठूलो छ।    Calcutta is bigger than Delhi.
यो तरकारी त्यो तरकारी भन्दा मीठो छैन।    These vegetables are not as nice as those vegetables.
तपाइंको घर मेरो घर भन्दा राम्रो छ।    Your house is more beautiful than mine.
स्कूलको सब भन्दा बद्दिमान विद्यार्थी राम हो।    Ram is the cleverest boy in the school (lit. 'than all clever student')
काठमाण्डौं नेपालको सब भन्दा ठूलो शहर हो।    Kathmandu is the biggest city in ('of') Nepal.
शहरको सब पसल बन्द छ ।    Every shop in the city is closed.
कुन देशमा?    in which country
कुन किताब?    which book?
कुनकिसिम?    which sort?
रामकी स्वास्नी कहाँ छे?    Where is Ram's wife?
मेरी बहिनी मन्दिरमा छे।    My little sister is in the temple.
तपाइंकी स्वास्नी कहाँ छिन्? उनी घरमा छिन्।    Where is your wife? She is at home.
मेरो कोट उसको (कोट) जस्तो छ।    My coat is like his (coat).
किताब कहाँ छ ?    Where is the book? (छ, locates)
कलम राम्रो हो    The pen is good. (हो defines)
नोकर त्यहाँ छ    The servant is there.(छ locates)
त्यो मान्छे, को हो ?    Who is that man? (हो defines)
मेरो किताब यहाँ छैन।    My book is not here.
त्यो मान्छे, बाहुन होइन।    That man is not a Brahmin.
मेरा छोराहरू स्कूलमा छैनन्।    My sons are not at school.
यी आइमाईहरू नेपाली होइनन्।    These women are not Nepalis.
मेरो किताब तिम्रो कोठामा रहेछ।    Oh, I see that my book is in your room.
त्यो होटेल महँगो पो रहेछ।    No, infact that hotel is expensive.
मेरो खल्तीमा केही पनि रहेनछ।    I find that I have nothing in my pocket.
त्यो गाउँमा चियापान रहेनछ।    It seems that there is no teashop in that village.
त्यो गई    She went
मेरीबहिनीले गरिन।    My sister did not do.
तिनी आइन्।    She (MGH) came.
यिनले धोइनन्।    She (MGH) did not wash.
पोहोर साल म नेपाल गएँ।    Last year, I went to Nepal.
गएको महिना पानी परेन।    It did not rain last month.
अस्तिको शुक्रबार म रामकहाँ थिएँ।    Last Friday, I was at Ram's place.
मेरी बहिनी सिकिस्त बिरामी थिई।    My little sister was seriously ill.
म बिरामी भएँ    I became ill/ I felt ill.
But म बिरामी थिएँ।    I was ill.
म गई्छु    I do
तँ बस्छस्    You sit
तिनीहरू सुत्छन्    They sleep
म खान्छु    I eat
हामी बिर्सन्छौं    We forget.
उ दिन्छे    She gives
त्यो जान्छ    He goes
म पठाउँछु    I will send.
मी आउँछौं    We come.
तिनीहरू पिउँछन्    They drink.
तपाईँ गर्नुहुन्छ।    You do.
वहाँहरू आउनुहुन्छ।    They come.
मेरो बुबा पठाउनुहुन्छ।    My father sends.
म दिनहुँ काम गई्छु ।    I work ('do work') every day.
मेरो छोरा महाविद्यालयमा पढ्छ ।    My son studies ('reads') at the college.
हिजोआज वहाँ नेपालमा बस्नुहुन्छ ।    Nowadays he lives in Nepal.
म बेलायतमा बस्छु।    I live in England.
म मेचमा बस्छु।    I sit down in a chair.
तपाईं चुरोट खानुहुन्छ?    Do you smoke cigarettes?
त्यो मान्छे, मासु खान्छ।    That man eats meat.
त्यो जोगी पानी मात्रै खान्छ।    That holy man (jogi) drinks only water.
हामी त कहिले कहीं मात्र रक्सी पिउँछों।    We sometimes drink spirits.
नेपालीहरू अक्सर भात नै खान्छन्।    The Nepalese often eat only (cooked) rice.
आउने साल म नेपाल जान्छु।    Next year, I am going to Nepal.
म गारदैध ।    I am doing.
उ खाँदे छ।    He/She is eating
हामी जाँदै छौ।    We are going
तपाईं आउँदै हुनुहुन्छ।    You (HGH) are coming.
उनीहरू धुँदै छन्।    They are washing.
तपाईं के गर्दें हुनुहुन्छ?? म काम गर्दैछु।    What are you doing? I am working.
म जाँदिन    I do not go
तँ खाँदैनस्    You do not eat
उ धुँदैन    He does not wash
हामी बिसंदैनौं    We do not forget
उनीहरू आउँदैनन्    They do not come.
तपाईं जानुहुन्र    You do not go
वहाँ देख्रुहुन्त    He does not see
मेरो बुबा निस्कनुहुन्र    My father does not go out
गर्नु    to do
भेट्नु    to meet
पिट्नु    to hit
हेर्नु    to look at
दुहुनु    to milk
जानु    to go
आउनु    to come
बस्नु    to sit/remain
म हुन्छु    I shall be
आउने हपा शहरको सबै अड्डा बन्द हुन्छन् तर पसल बन्द हुँदैनन्।    Next week all the offices in the city will be closed, but the shops will not be.
भित्र पाल्नुहोस्    please come in
म भित्र जान्छु।    I'll go outside.
हाम्रो घरभित्र    inside our house.
काठमाण्डौंभित्र    inside Kathmandu.
नआत्तिनुहोस्    do not panic
नरिसाउनुहोस्    do not be angry
मैले गएको मङ्गलबार तपाइंको चिठी पाएँ।    I received your letter last Tuesday.
म चालीस रूपियाँ पाउँछु।    I earn forty rupees.
तिमीले के पायौं? केही पनि पाइनँ।    What did you get? I got nothing at all.
यसलाई नेपालीमा के भन्छ? यसलाई किताब भन्छ।    What do they call this in Nepali? They call it kitab.
मान्छेहरूलाई रोटी सधैं चाहिन्छ।    Men always need bread.
तपाईंलाई अब के चाहियो? मलाई चिया चाहियो।    What do you want (now)? I want some tea.
बाटोको लागि हामीहरूलाई के के चाहिन्छ?    What things shall we need for the journey?
यो रोटी बासी रहेछ। मलाई त चाहिन्न बा।    This bread is stale. I don't want it.
हाम्रो घर यहाँबाट सजिलैसँग यहाँबाट पगिन्छे।    You can reach our house easily from here.
बेलामा पुगिएन।    We did not arrive on time.
तपाईँ कति बजे पुगनुहुन्छ? छ बजे पुग्छु।    What time will you arrive? I'll arrive at six o'clock.
त्यति पैसाले पुग्दैन रे।    He says that much money is not enough.
बेलुकासम्म पुग्छ कि पुग्दैन?    Can we get there by evening or not?
कोठामा गर्मी छ। म इयाल खोल्छु।    It is hot in the room. I'll open the window.
भात खा त नानी    Eat your dinner, won't you, child.
यता आइज। त्यहाँ नबस्।    Come here. Do not sit there.
यो कोठामा गर्मी छ। पंखा खोल त।    It is hot in this room. Switch on the fan, please.
नमस्कार विष्टज्यू। भित्र पाल्नुहोस्। बस्नुहोस् त।    Good morning, Mr. Bista. Come in and sit down.
भात खाएर म घर जान्छु।    Having eaten dinner, I shall go home.
म हवाईजहाजमा चढी बेलायत गए।    I boarded the plane and went to Britain.
तपाई मकहाँ कहिले आउनुहुन्छ?    When are you coming to my house?
राम दिल्ली कहिले जान्छ?    When is Ram going to Delhi?
त्यो कहिले कहीं मात्र मासु खान्छ।    He eats meat only sometimes.
म कहिले कहीं नेपाल जान्छु।    I sometimes go to Nepal.
म त कहिले पनि रक्सी पिउँदिन।    I never drink spirits.
हामी उसलाई कहिले पनि भेट्दैनौं।    We never meet him.
त्यो त कतै जान्न।    He does not go anywhere/ he goes nowhere.
कसरी जानुहुन्छ? म हवाईजहाजमा जान्छु।    How are you going? I am going by aeroplane.
सिनेमा कस्तो छ? बेसै छ।    What is the film like? It is not too bad.
तपाईँ कहाँ जाँदै हुनुहुन्छ? म त कतै जान्न।    Where are you going? I'm not going anywhere.
उसको कुरा साँचो जस्तो छैन।    What he says does not sound true.
आज पानी पर्ला जस्तो छैन।    It does not look like it will rain today.
म भोलि तपाईंसँग कुरा गई्छु।    I will have a word with you tomorrow.
त्यो को हो?    Who is he?
यो के हो?    What is this? Or, what is it?
त्यो त्यहाँ छ ।    He/She/It is there.
हाम्रो नोकर कहाँ छ?    Where is our servant?
त्यहाँ छ।    He is there.
मेरो किताब कहाँ छ?    Where is my book?
यहाँ छ ।    It is there.
त्यो मान्छे, को हो ?    Who is that man ?
धोबी हो ।    He is the washerman.
तिम्रो घरमा को को छ? (छन)    Who (i.e. what people) are in your house?
पसलमा के के छ?    What things are in the shop?
म अंग्रेज हुँ। हिन्दुस्तानी होइन।    I am English, not Indian.
ए नानी तँ कहाँ छस्?    Child, where are you?
तँ ज्ञानी होइनस्?    Aren't you good (little boy)?
तपाईँ हिजो आज कहाँ हुनुहुन्छ विष्टज्यू?    Where are you these days, Mr. Bista?
ए दाइ तपाईं बाहुन हुनुहुन्छ?    Excuse me, are you a Brahmin?
तपाइंहरू विद्यार्थी हुनुहुन्छ?    Are you students?
तपाईंहरू छेन्री हुनुहुन्छ?    Are you Chhetris?
हामी मजदुर हौं।    We are labourers.
हामी नेपाली हौं।    We are Nepalis.
ऊ घरमा छ।    He / She is at home.
त्यो दार्जीलिड्गमा छ।    He / She is in Darjeeling.
त्यो धेरै राम्रो हो।    That's very good.
यो नेपालमा छ तर त्यो भारतमा छ।    He is in Nepal, but he (the other one) is in India.
यिनी को हुन्?    Who is he/she?
उनी लन्डनमा छन्।    He is in London.
तिनी कहाँ छन्।    Where is he?
राम कहाँ छन्? Where is Ram?    उनी घरमा छन्।  He is at home.
वहाँ अड्डामा हुनुहुन्छ।    He is at the office.
यहाँ बाहुन हुनुहुन्छ।    (the person here) is a Brahmin.
मेरो बुबा कलकत्तामा हुनुहुन्छ, । वहाँ मन्त्री हुनुहुन्छ।    My father is in Calcutta. He is a minister.
मेरी दिदी घंरै हुनुहुन्छ। बिरामी हुनुहुन्छ।    My elder sister is at home. She is ill.
जापानकाप्रधानमन्त्री टोक्योमा हुनुहुन्न।    The Prime Minister of Japan is not in Tokyo.
फ्रान्सका राष्ट्रपति बेलायतमा हुनुहुन्छ।    The President of France is in England.
यिनीहरू बाहुन हुन् ।    They are Brahmins.
उनीहरू हिजोआज विश्वविद्यालयमा छैनन्।    They are not at the university nowadays.
तिनीहरू कहाँ छन्?    Where are they?
मेरो (मेरा)किताबहरू कहाँ छन्? यहाँ छन्?    Where are my books? They are here.
ढोकामा कोही छ?    Is there anyone at the door?
घरमा कोही छैन।    There isn't anyone at home.
हिजो आज पसलहरूमा केही छैन। ढोकामा कोही छैन।    There is no one at the door.
मेरो खल्तीमा केही पनि छैन।    There's nothing at all in my pocket.
त्यो गाउँमा कोही पनि छैन।    There is not anyone in that village.
केटालाई किन पिट्छौं?    Why do you beat the boy?
म रामलाई हेंदे छु।    I am looking at Ram.
म तपाईलाई एक बजेतिर भेट्छु है।    I'll meet you at about one o'clock, shall I?
कसको किताब?    Whose book?
कसकसकहाँ    at whose places?
म कसैलाई दिंदिन    I shall not give it to anyone.
केमा जानुहुन्छ??    हवाईजहाजमा जान्छु। How (in what) are you going? I'm going by air.
केको हतपत?    What's the hurry (lit. 'of what ...')?
नेपालमा    in Nepal
स्कूलमा    at school
टेबुलमा    on the table
ढोकामा    at the door
मान्छेसित    with the man
मेरो छोरासँग    with my son
नोकरको नाम के हो?    What is the servant's name?
रामको पसल कहाँ छ?    Where is Ram's shop?
नेपालको राजधानी काठमाण्डौं हो।    The capital of Nepal is Kathmandu.
रामको पसलमा कुन किसिमको माल छ?    What sort of goods are there in Ram's shop?
नेपालका मान्छेहरू    men of Nepal
काठमाण्डौंदेखि पोखरा कति टाढा छ?    How far is Pokhara from Kathmandu?
लन्डनबाट नेपाल छ हजार मील टाढा छ।    Nepal is six thousand miles away from London.
त्यो मान्छे, पाँच महिनादेखि यहाँ छ।    That man has been here for five months ('is here from five months')
मेरो छोरा तीन हस्सादेखि बिरामी छ।    My son has been ill for three weeks.
त्यो मान्छे, यहाँको होइन।    That man is not from here.
त्यो मान्छे कहाँको हो?    Where does this man come from?
यहाँबाट शहर कति टाढा छ?    How far is the city from here?
मलाई थाहा छ।    I know ('to me there is knowledge')
उसलाई थाहा छैन।    He / She does not know ('to him/her there is not knowledge')
त्यसलाई रूचि छैन।    He has no appetite.
उसलाई निश्चय छ।    He / She is certain.
तपाईलाई कस्तो छ?    How are you? ('to you how is it?')
रामलाई कस्तो छ?    How is Ram?
तपाइंनेपालमा कति बस्नुहुन्छ?    How long (lit. 'how much') will you stay in Nepal?
जूनसम्म बस्छु।    I'll stay until June.
राम गाई दुहुन्छ।    Ram milks the cow.
त्यो सिनेमा हेर्दैन।    He does not watch films.
हामी दिनहुँ काम गछौं।    We work ('do work') every day.
औंलोले मर्नु    to die of malaria
पानीले भिजेको    soaked with water
ठूलो स्वरले बोल्नु    to talk in a loud voice.
मान्छेहरूले भरिभराउ    packed with people.
प्रधानमन्त्रीले आज भाषण गर्नुहुन्छ।    The Prime Minister will make a speech today.
टयाक्सीले कति लिन्छ?    How much will the taxi take (i.e. 'how much will it cost by taxi?')
लिनु    to take
त्यो बाटोले कहाँ कहाँ लान्छ हँ?    Where does that road lead to?
उसले मलाई चिन्दैन।    He does not know me.
उसले मलाई भन्छ।    He says to me/tells me.
म तिमीलाई पैसा दिन्छु।    I'll give you some money.
त्यसले मलाई केही पनि भन्दैन।    He does not tell me anything at all ('say to me').
म यसलाई भन्छु।    I'll tell him.
उसले मलाई भन्छ।    He will tell me.
तीन बजेतिर    at about three o'clock
साढे पाँच बजेतिर    at about half past five.
म खुम्बुतिर जाँदै छु।    I am going towards Khumbu/ I'm heading for Khumbu.
रेल कति कति बेलामा आउँछ?    How often do the trains run?
रेल हरेक घण्टामा आउँछ।    The train comes every hour.
उसले मेरो निम्ति केही पनि गर्देंन।    He does nothing for me ('for my sake').
विवाहको निमित्त नेपालीहरू धैरै पैसा खर्च गर्छन्।    Nepalis spend a lot of money on wedding.
वहाँले नेपाली साहित्यको विषयमा भाषण गर्नुहुन्छ।    He is making a speech on the subject of Nepali literature.
महाराजधिराजको शुभजन्मोत्सवको उपलक्षमा    On the occasion of the birthday of His Majesty
त्यस साना देशका राजधानीमा    in the capital city of that small country
बसबाट    by bus
हवाईजहाजबाट    by air
यो बाटोबाट     by this road
कुन बाटोबाट    by which road?
पर्यटकहरू धेरैजसो काठमाण्डौंबाट बाहिर जाँदैनन्।    Tourists do not usually go outside Kathmandu.
यहाँबाट सब भन्दा नजीकको गाउँ कुन हो?    Which is the nearest village to here?
त्यो मेरो घरनजीक बस्छ।    He lives near my house.
भो भो, अब त खान्न।    That's enough. I can't eat any more.
भो भो, त्यो त धेरैर नै भयो।    Stop. That's plenty.
त्यो सगरमाथा हो नि।    That's Mt. Everest, you know.
म त ब्राह्मण हुँ।    I am a Brahmin.
मेरो भाइ त कलेजमा छ।    My brother is at the college.
त्यो सगरमाथा होइन त?    That's Mt. Everest, isn't it?
रक्सौंल भारतमा छ, होइन?    Raxaul's is in India, isn't it?
त्यो होटेल त राम्रो पो छत।    But that hotel is nice, I tell you.
म जाऊँ है त।    All right if I go now?
लेहरू बिहानै बेलुके दिनको दुई पटक नै दाल र भात खान्छन्।    Villagers eat rice and lentils twice a day morning and evening. Note the expressions:
दिनको दुई पटक    two times a day
महिनाको चार पटक    four times a month
त्यो त धैरै नै लामो बाटो छ।    But that's an extremely long way round (lit. 'long road')
मलाई भन्तुहोस् त।    Please tell me.
चिया खानुहोस् त।    Have some tea, won't you?
भरे पानी पई रे।    They say that it's going to rain this evening.
आउने हप्ता बिदा छ रे।    I hear that there's a holiday next week.
उसको खल्तीमा केही छैन रे।    He says that he's got nothing at all in his pocket.
के रे?    What does he say?
पच्चीसजना सिपाही    twenty-five soldiers
उनन्तीसवटा किताब    twenty-nine books
आधा मील    half a mile
डेढ महिना    one and a half months
अढाई रूपियाँ    two and a half rupees.
हवाईजहाज विहान नौं बजे काठमाण्डौं पुग्छ।    The aeroplane reaches Kathmandu at nine in the morning.
म भरे सात बजेतिर तपाइंकहाँ आउँछु।    I'll come and see you this evening at about seven.
ठूलोचाँहि    the big one
मेरोचाँहि    mine, my one
त्योचाँहि    that one
योचाँहि    this one
कुनचाँहि    which one?
रामकोचाँहि    Ram's one.
मचाँहि    as for me
गर्मीमाचाँहि    in the hot season (as opposed to others)
त्यो गाउँमा कुन चाँहि चियापसल सब भन्दा राम्रो छ?    Which (one) is the best tea shop in that village?
यो घडी राम्रो हो तर त्योचाँहि त्यति राम्रो होइन।    This watch is nice but that one is not so nice.
मोटर बिस्तारै हाँक्नुहोला।    Please drive the car slowly.
नरिसाउनुहोला।    Please do not be angry.
त्यो विशाल भवन,    That huge building
एक किलो + राम्रो आलु    one kilo + good potato/potatoes
नेपाली भाषा    Nepali Language
भक्तपुर जिल्ला    Bhaktapur District
गण्डकी अस्चल    Gandaki zone
त्यो विशाल भवन    That huge building
त्यो देविरमन    That Deviraman
यो सुभद्रा    This Subhadra
मेरी न्याउली    My Nyauli
कति लक्ष्मी    How many Laxmis?
दुई सुशिल    Two Sushils
विचरी सुभद्रा;    Poor Subhadra
कङाल देवीरमन    Penniless Deviraman
देवीरमण, नौलीहरू    Deviraman, Nauli and others
शारदा गयो(m)    Sharada went.
दुर्गा गयो(m)    Durga went
शारदा गई(f)    Sharada went.
दुर्गा गई(f)    Durga went
सुभद्रा दुलही भएर आउँदाको बखत    The time when Subhadra came as a bride
नरमाइलो लाग्नु पर्ने +कुरा    the matter to be unhappy about
सब भन्दा ठुलो + सन्तोष    the greatest + satisfaction
आँगनमा चरिरहेका + परेवा    the pigeons + wandering in the courtyard
तीर्थ गर्ने इच्छा    a desire to go on + a pilgrimage
हरिवंश पुराण    Haribamsha the legend
फागुन महीना    the month of Falgun
नौंली घर्तिनी    Nauli the slave
माघ महिना    The month of Magh (January-February)
काले कामी    Kale the blacksmith
हरेक उपाय    every effort
अर्को विवाह    another marriage
पल्लो कोठा    the next room
कुनै दिन    certain day
राम्रो केटो    handsome boy
रामी केटी    beautiful girl
राम्रा केटाहरू    handsome boys
राम्रा केटीहरू    beautiful girls
भाग्य भन्दा पुरूषार्थ ठूलो हो।    Hard work is greater than luck.
रात्री झन् भयङ्कर प्रतीत हुन्थ्यो।    The night appeared more terrifying.
सब भन्दा ठूलो सन्तोष यही हो।    This is the greatest satisfaction.
यो घर सुभद्रालाई संसारमा सबै भन्दा प्यारो वस्तु थियो।    This house was the dearest thing in the world for Subhadra.
घरबाट धेरैर टाढा    very far from home
अगाडि पट्टि    in front
आमने सामने    face to face
पारि पट्टि    on the other side
अघिल्तिर    in front
ऊ अगाडिपट्टि सर्यो।    He moved in front.
अघिल्तिर नबस।    Do not sit in the front.
उनीहरू आमने सामने उभिए।    They stood face-to-face.
घर अगाडि    In front of the house
देविरमणका आँखा सामु    In front of the eyes of Deviraman
मेरो विरूद्ध बोल्छ।    He talks against me.
अनि के भयो?    And then what happenned?
अथवा त्यस अपराधी जस्तो थियो।    Or, it was like that criminal..
जान्थिन् कि जाँदैनथिन्    Whether she would go or not.
कि त्यो जान्छ कि म जान्छु।    Either he goes, or I will go.
किन्तु ... बीचैमा लुप्तयो।    But it disappeared in the middle...
न ऊ आफै आयो न कसैलाई पठायो।    Neither he came himself, nor did he send anyone.
मानिसको पाण्डित्य अरूलाई उपदेश गर्नमा काम लाग्छ नकि आफुलाई परिआउँदा    A man's wisdom is useful in advising others, but not himself.
परन्तु देवीरमणका कपालमा अर्कै विचारको दून्द हुन लागेको थियो।    But in Deviraman's mind, another troubling thought arose.
आखिर लक्ष्मी र सुशीलालाई पनि साथमा लिए ।    In the end, he took Laksmi and Sushil as well.
तैपनि सुभद्राको कोख सफल हुन सकेन।    Even then Subhadra's womb could not be fruitful.
यद्यपि कुरा सत्य हो तैपनि मलाई राम्रो लागेन।    Although it is a true fact, even then I do not like it.
तर अपूतो भनेको सुन्रे बित्तिकै    But as soon as he heard someone calling him 'childless',
धर्म तथा विवेकको हत्या    The violation of religious duty and conscience.
सुभद्राको आदेश पाई हो वा नपाई हो ...    It was with the permission from Subhadra or not...
आशापाश या मृगतृष्णा    The snare of hope or mirage
डाक्टर आउनु अघि बिरामी मरिसकेको थियो।    The patient had died before the doctor came.
सुभद्वालाई ताडना गरून् भने    If he rebuked Subhadra
उसले भन्यो कि खबर झूटो हो।    He said that the news was incorrect.
आफ्नी आमालाई दुलही भन्थ्यो किनकि लक्ष्मीलाई घरमा सबैजना दुलही बज्यै भन्थे।    He called his own mother 'dulahi' because everyone at home called Laksmi 'Dulahi Bajyai'.
तिमीले कथा भने पछि मैले बुझें।    When you told the story, I understood (it).
घरमा चझ्चलाश्री भइकन पनि देवीरमणका सन्तान थिएनन्।    Although there was plenty of wealth at home, Deviraman had no children.
यदि तिमी आउँछौं भने म पनि आउँछु।    If you come, I will also come.
सुशील चाँहि    Sushil in particular
अघि नै    Long before
मलाई पो    Rather me
त्यो किताब लेड त ।    Please pass on that book.
मलाई अलिकति चिया दिनोस् न ।    Give me some tea please.
शायद ब्रम्हावादीहरू यसैलाई आशापाश या मृगतृष्णा भन्छन् क्यारे ।    The Vedanta school philosophers call it a snare of hope or mirage, I guess.
जान्छयौं कि?    Will you also go?
सानो बाबु कस्तो छ नि?    And how about the little boy?
कुन दौलतको चैन गरेकी छु र?    Am I enjoying any wealth?
त्यो तिमी जस्तै छ है ।    He is just like you. (be careful).
होश गर है कैदी भाग्ला ।    Be careful, the prisoner may run away.
जाउँ है?    May I go please?
बलेकै आगो न    Indeed a burning fire
मलाई एक किलो चिनी दिनोस् न ।    Please give me a kilo of sugar.
खानोस्    Please eat.
नखानोस्    Please do not eat.
जानोस्    Please go
नजानोस्    Please do not go
गर्नोस्    Please do it
नगर्नोस्    Please do not do it
जान    to go
नजान    not to go
खान    to eat
नखान    not to eat
गर्न    to do
नगर्न    not to do
खाए    if eat
नखाए    if not eat
गरे    if do
नगरे    if not do
गर्दैन    He does not do it
खादैन    He does not eat it
जाँदैन    He does not go.
गर्देनन्    They do not do it
खादेनन्    They do not eat it
जाँदैनन्    They do not go
भोक लाग्नु    feel hungry
दिक्क लाग्नु    feel sad
गाहो लाग्नु    find difficult
निको लाग्नु    be well, cured
थकाइ लाग्नु    feel tired
डर लाग्नु    be afraid
दिशा लाग्नु    have diarrohea
मन पर्नु    like
रक्सी लाग्नु    get drunk
तिर्खा लाग्नु    feel thirsty
सुस्तरी भनिन् ।    She said faintly.
एक एक गरी हेरे।    He examined one by one.
गए साल हरिवंश पुराण लगाए।    He listened to the Harivamsha purana last year.
सुशील तुलसीको मठनेर खेलिरहेको थियो ।    Sushil was playing near a mound of earth in which the sacred Tulsi plant was growing.
म आफ्नो छोरालाई पढाउँछु।    I teach my own son.
म भात खान्छु।    I eat rice.
सुभद्रा दमाईं र डोलेहरूलाई ज्याला बाँड्दैथिइन्।    Subhadra was giving away wages to the musicians and the litter-bearers.
सुभद्रा छोरालाई भात खुवाइरहेकी थिइन्।    Subdhra was feeding rice to her son.
देविरमण आफ्नो वैभवलाई तुच्छ समझन्थे।    Deviraman considered his wealth as worthless.
सुशील आफ्नी आमालाई दुलही भन्थ्यो।    Sushil called his own mother 'dulahi'
कन्यापक्षका मानिसले दुलहीलाई डोलीमा हालिदिए।    The people of the bride put her in the litter.
सुभद्रा गास मुखमा हालिदिन्थिन्।    Subhadra put the mouthfuls of food in the mouth.
ऊ नेपाली हो ।    He is a Nepali.
ऊ बाठो छ।    He is clever.
सुभद्रा रोइन् ।    Subhadra cried.
देविरमणलाई चाँडे निद्रा पर्यो।    Deviraman fell asleep soon.
देविरमण खाटमा पल्टे।    Deviraman lay in the bed.
आत्मग्लानिले पानी हुन्थे ।    He used to be inflicted by sorrow.
भाग्यले यो उमेरमा उनलाई फेरि दुलाहा बनायो।    Destiny made him (Deviraman) a bridegroom again at this age.
यसबाट उनको भलो कुभलो के हुने हो।    Whether good or evil would result from this.
घरमा चञ्चलाश्री भइकन पनि    Although there was wealth in his house.
जोरिपारीसँग ठोकाबाजी पर्दा    While in competition with the (jealous) neighbors
दुलही भएर    being (as) a bride.
छि! सुभद्राको आजीवन सेवाको पुरस्कार यही हो?    Fie! Is this the reward for Subhadra's life-long service?
घरमा चज्चलाश्री भइकन पनि    Although there was wealth in his house
आत्माग्लानिले पानी हुन्थे।    He used to be inflected by sorrow.
घरको सम्भार राखेस्    Take a good care of the house.
घरको सम्भार राख्छ    He takes a good care of the house.
नेपाल एक हिन्दू देश थियो    Nepal was a Hindu country
नेपाल हिन्दू देश थियो?    Was Nepal a Hindu country?
नेपाल हिन्दू देश थियो ।    Nepal was a Hindu country.
नेपाल हिन्दू देश हगि?    Nepal was a Hindu country, wasn't it?
मनमनले भने, के सुभद्राले साँचो मनले सल्लाह दिएको हो?    He said to himself, "Did Subhadra give her consent sincerely?"
आज देवीरमणको गति त्यस बालक छात्रको जस्तो थियो जो पहिलो दिनको पाठ बिर्सेर अबेला गुरूकहाँ पुग्छछ।    Today, Deviraman's situation was like that of a little boy who forgetting his previous lesson, arrives late at his guru's place.
लक्ष्मीलाई ताडना गरून् भने पुत्रवती पत्नी थिइन्।    If he rebuked Laksmi, she was his wife with a son.
आफ्नी आमालाई "दुलही" भन्थ्यो, किनकि लक्ष्मीलाई घरमा सबैजना "दुलही बज्यै" भन्थे ।    He called his own mother "Dulahi" because everyone in the family called Lashmi "Dulahi Bajyai".
यो योजना नेपालमा संभव छैन किनभने त्यहाँ पूँजीको कमी छ    This plan is not feasible in Nepal because there is a shortage of capital here.
सौंताको रीसले पोइको नाक काट्नु भनेको यही हो।    This is like cutting the nose of one's husband because of anger at one's co-wife.
बिहानमा घुम्नु राम्रो हो।    To walk in the morning is good.
बिरामी भएकोले हिजो म सकूल आइन ।    (Because was sick), I did not come to school yesterday.
सरकारले रोकेको हुनाले आज जुलुश भएन ।    Because the government had prevented it, there was no demonstration today.
एक वचन सोधेको सम्म भए उनको आँसु पुछिने थियो ।    If she was asked a word, her tears would have been wiped.
उनीहरू जाने भए जाउन् ।    If they are going, let them go.
छोड्नु परे छोडिदिउँला    If I must leave, I will leave.
घरमा चश्चलाश्री भइकन पनि देवीरमणका सन्तान थिएनन् ।    Although there was plenty of wealth at home, Deviraman had no children.
आफूखुशी भए पनि नौंलीले घर छाडिन।    Although it was voluntary, Nauli did not leave the house.
तर दैवले नसुनिदिए पछि कसको के लाग्दो रहेछ र?    But if God does not listen, who can do anything?
उनीहरू गए भने म पनि जान्छु ।    I'll also go if they go.
नेपाल भन्दा अमेरिका ठूलो छ ।    America is larger than Nepal.
म भात भन्दा तरकारी धेरै खान्छु ।    I eat more vegetables than rice.
उ धनी भन्दा पनि खुशी छ।    He is more happy than he is rich.
लेख्र भन्दा बढी पढ ।    Read more than you do writing.
सगरमाथा सबभन्दा अग्लो पहाड हो।    Sagarmatha (Mt. Everest) is higher than all (the highest) mountains.
यो किताब अझ राम्रो छ।    This book is even better(than one expected).
रान्री झन् भयङ्कर प्रतीत हुन्य्यो।    The night appeared even more terrifying.
म राम जति काम गर्छु।    I can do the work as much as Ram can.
म राम जति धनी छु।    I am as rich as Ram.
म राम जति काम गर्न सक्छु।    I can do the work as much as Ram can.
म रामलाई त्यत्ति नै चिठी लेख्छु जति गोविन्दलाई।    I write as many letters to Ram as I write to Govinda.
म जति यहाँ बस्छु उति त्यहाँ बस्तिन ।    I do not stay there as much as I stay here.
म त्यति नै लेख्छु जति पढ्छु।    I write as much as I study.
बिचरी सुभद्रा पनि खिन्न थिइन् ।    Poor Subhadra also was sad.
किन नौंली, किन त्यसो भनिस्?    Why Nauli, why did you say so?
घरको सम्भार राखेस्।    Take good care of the house.
ओहो बज्यै, हेर कति दुब्ली ।    O Bajai! Look, how thin you have become!
उनीहरू हिजो गए रे।    They went yesterday, they say.
साहै नराम्रो रोग हो अरे ।    It is a very bad disease, they say.
मेरो राजा" भनेर म्वाइ खाइन्।    She kissed the boy saying "My Raja".
खस्नुपर्ला भनेर बीचैमा अलप हुन्छन् ।    Thinking that they may have to fall, they disappear between the sky and the earth.
कसैले देख्छ कि भनेर ओढ्नेले छोपेकी थिइन् ।    Thinking that someone may see it, she covered it (the bundle) with her shawl.
तिमी काम गर्ने?    Would you like to do the job?
गर्ने    Yes, I would like to do that job.
