# Structure of Nepali Grammar 

Bal Krishna Bal<br>Madan Puraskar Pustakalaya, Nepal<br>bal@mpp.org.np


#### Abstract

This document is an attempt to provide some basic insight of the structure of Nepali Grammar. The report deals with the writing system of Nepali introducing the alphabets and symbols in usage. Similarly the form classes or parts of speech of Nepali is also discussed followed by a detailed discussion on the phrase structure of the Nepali Grammar. Special Characteristics of the Nepali Grammar are well illustrated wherever necessary. The report is concluded by a brief overview of the sentential structure of the Nepali Language.


## 1. Background

Nepali is the national language of Nepal. It is also a medium of a uniform, nationwide, educational system, public administration and mass communication . The most recent official census conducted by the government of Nepal in 2001 reports that there are around 20 million Nepali speakers in Nepal, out of which, it is spoken as the mother tongue by 11 million people, and as a lingua franca by others. Nepali is also spoken widely in the neighboring countries of Nepal like India, Bhutan and Myanmar. The Indian Constitution has recognized Nepali as a major language of India [1].

In this regard, despite the fact that the diaspora of Nepali speakers is comprised of more than 45 million people in Nepal and elsewhere, the Nepali language still continues to remain a underresourced language. Things seeming to be a matter to be taken granted for other languages like the availability of the digitized text corpora, digitized dictionaries, Natural Language, Image and Speech Processing Applications like the Spell-Checker and the Thesaurus, Grammar Checker, Machine Translation Systems, Optical Character Recognition Systems, Handwriting Recognition Systems, Text-To-Speech, Speech Recognition Systems, Speech-To-Text etc. are either in the early stages of development or totally new for the Nepali language. There are several reasons for the low work profile of the Nepali Language in Computational Linguistics, the first one primarily being the lack of expertise and among several others, the lack of a sound research work required in the above acitivities. Other issues related to funds for the research and development support, the computer scientists and the linguists limiting themselves to their respective domains of interest thus creating a vacuum in the required collaboration are equally vital for the lagging behind of the Nepali language in producing the invaluable resources of computational linguistics.

This report is an attempt from the side of a computer scientist to get into the study of the basic structure of the Nepali Grammar. The results or findings of the study are believed to be very much substantial in the Spell Checker, Thesaurus, Grammar Checker, Machine Translation Systems, Optical Character Recognition Systems development for Nepali. Various resources available on the Nepali Grammar have been duly consulted while preparing the report. The resources consulted have been listed in the bibliography section of this report.

## 2. Introduction

Nepali is an Indo-Aryan language. It takes it's root from Sanskrit, the classicial language of India. Nepali was previously known as Khas Kura and the language of the Khasa kingdom, which ruled over the foothills of current Nepal during the 13th and 14th centuries. The history of the usage of Nepali in writing dates as back as the 12 th century AD. Nepali is written with the Devanagari alphabet, which developed from the Brahmi script in the 11 th century AD. Linguistically, Nepali is most closely related to Hindi. A large proportion of the technical vocabulary is shared by Hindi and Nepali. Even the script is more or less the same for both languages and differing with each other in only a few minor details. [2, 3, 6, 7].

### 2.1. Writing System of the Nepali

Nepali is written in the Devanagari script. The same script is used for Hindi, Marathi and Sanskrit. There are 11 vowels and 33 consonants in the Nepali language. The script being phonetic in nature, and hence the pronunciation closely resembles the writing system. The script is written from left to right. There is no provision of capital and small letters in the script $[1,6,7]$. The alphabets are written in two separate groups, namely the vowels and the consonants, as shown in the table below.

Table 1. Alphabets of the Nepali Writing System

| Vowels | अ,आ,इ,ई,उ,ऊ,ॠ,ए,ऐ,ओ,औ |
| :---: | :---: |
| Consonants | क,ख,ग,घ,ए,च,छ,ज,झ,ञ,ट,ठ,ड,ढ,ण,त,थ, |

The three letters क्ष, त्र and ज are regarded as special clusters and are dealt with separately from the consonants. We would deal with their formation in a later section.

In addition to the alphabets and letters mentioned above, the following signs and symbols exist in the written Nepali as shown in the table below. A brief description on each othe symbol follows.

Table 2. Additional symbols in the Nepali language

| Candrabindu | ![](https://cdn.mathpix.com/cropped/2024_06_19_25e3135b36d426f3f99bg-02.jpg?height=60&width=370&top_left_y=1658&top_left_x=605) |
| :---: | :---: |
| Anusvar or Cirabindu | $\dot{\alpha}$ |
| Vowel signs | ा, ि, , , ठ, ओ, , |
| Visarga | : |
| Viram or halanta | व |

### 2.1.1. Candrabindu and Anusvar or Sirabindu

These two signs are the marks of nasalization in the Devanagari Script. Anusvar or Candrabindu is generally used to indicate the nasalization of a vowel [7], e.g.

सँग, pronounced as "saga" and meaning "with"
गाएँ, pronounced as "gaau" and meaning "village"

In Nepali, sirabindu is often used interchangeably with the anusvar, e.g.

सँग, pronounced as "saga" or संग, pronounced as "sanga", both meaning "with"

गाऊँ, pronounced as "gaau" or गाउं, pronounced as "gaaun", both meaning "village"

The Sirabindu in Nepali is inconsistently used to represent the nasal stops that are homoorganic with the adjacent stops, eg.

अङ्क, pronounced as "angka" or अंक, pronounced as "anka", both meaning "number".

अञ्चल, pronounced as "anchal" or अंचल, pronounced as "anchal", both meaning "zone"

### 2.1.2. Vowel Signs

The vowels in Table 1 and the vowel signs listed in Table 2 are often called the free forms of vowels and the conjunct forms of vowels respectively.

The free forms of the vowels are written when the single vowels constitute the syllables. On the other hand, the conjunct forms of vowels or the vowel signs are written when the vowels are preceded by consonants to constitute Consonant Vowel (CV) syllabic structure [7].

The association between free forms and conjunct forms of the vowels is shown in the table below:

Table 3. Association between free form of vowels and vowel signs or conjunct forms

| Free <br> Forms | अ आ | इ | ई | उ | ऊ | ॠ | ए | ऐ | ओ | औ |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| Vowel <br> Signs | ा | ि | ऊ | 久 | ओ | ओ | ो |  |  |  |

Note that the vowel symbol अ, has no corresponding conjunct form, which means its presence is indicated by nothing but the shape of a bare constant symbol [7].

The text below illustrates the order of the writing system of some of the vowel signs.

The vowel sign $\mathrm{P}$ is written before the consonant after which it is pronounced:

$$
\begin{aligned}
& \text { बि }=\text { ि before the consonant ब } \\
& \text { गि }=\text { ि before the consonant ग }
\end{aligned}
$$

The vowel sign ol follows the consonant:

$$
\text { सी = ी after the consonant स }
$$

The vowel signs and $\Omega$ are written at the foot of the consonant:

$$
\text { लु=ल+ু }
$$

नू $=$ न + 久

When joined to र, the vowels $\mathrm{K}$ and are written as: रु and रू. The use of the vowel signs in word formation is illustrated below:

द+ि+द + ी दिदी, pronounced as "Didi" and meaning "Elder sister"

### 2.1.3. Visarga

The symbol : known as visarga occurs only in a few loanwords from Sanskrit. In most cases, it is disregarded in pronunciation [6]. Examples include,

प्राय:, pronounced "praya" and meaning "usually or mostly"

दु:ख, pronounced "dukkha" and meaning "pain"

### 2.1.4. Viram or halanta

Before we try to explain about viram or halanta, we need to briefly throw light on the background of it's usage. Simple consonant characters represent not "letters" but syllables containing the vowel अ. This vowel is known as the inherent vowel. Thus the character ग represents the syllable "ga" and not merely the consonant "g".
The inherent vowel अ is cancelled by placing the sign "्", known as viram or halanta at the foot of the consonant character. Thus बस् is pronounced "bas" as opposite to बस "basa". The viram indicates that the inherent vowel in the consonant is not to be pronounced [6].

With the viram or halanta discussed, it would be appropriate to discuss on the formation of the special clusters, क्ष, त्र and ज. The three special clusters are formed by the combination of the other consonants with the viram or halanta playing a significant role in the combination as shown below:

$$
\begin{aligned}
& \text { क्ष=क+णष्र } \\
& \text { त्र=त+ःर } \\
& \text { ज=ज+़ न }
\end{aligned}
$$

There are some other clusters as well like श्र and य but right now have not been considered as clusters officially, though their formation follows the same procedure as above:

$$
\begin{aligned}
& \text { श्र=श+्र } \\
& \text { घ=द+्+य }
\end{aligned}
$$

### 2.1.5. Vowels

Vowels, with one exception, each have two symbols $[6]:$

- vowel character - used in initial position and after other vowels, or when the vowel is isolated.
- vowel signs - used after consonants

The vowel character आ, aa has the corresponding vowel sign ा

The word aama is then written आमा,the initial vowel being represented by the vowel character आ, and the second vowel by the vowel sign , because it occurs after the consonant character म. The addition of
the vowel sign cancels the inherent vowel of the consonant.

### 2.1.6. Conjunct Consonants

When two or more consonants occur together without an intervening vowel, e.g. स्छ in बस्छ, baschha (sits) or न्छ in मान्छे, manchhe (man), the combination is written as a single unit, known as a conjunct consonant.

In these two conjunct consonants, the elements (half characters preceeding the full characters) are easily recognizable as parts of the consonant characters स and न respectively.

However, the various elements of some conjunct consonants are not so easily recognizable. When $\square$ precedes another consonant, the 'ref' sign is placed directly over the consonant character to which it is joined. If part of that character extends above the top line, the sign is placed to the right of it [6].

For eg. गई, गर्देन

Some consonants have no special conjunct form. The junction is then effected by means of the viram, छोड्नु, the inherent vowel in 5 being cancelled by the viram. In a compound word like (सगरमाथा) comprising of सगर and माथा, the consonant junction is again effected by the viram.

The consonants are divided into three groups depending upon their formation:

### 2.1.6.1. Regular conjunct forms of the consonant

 symbolsThe regular conjunct forms of the consonant symbols are written in three ways [7]:

- The first way of writing a conjunct consonant symbol is the one in which the first consonant's symbol is written in half-shape, and the second consonant's symbol is written in full-shape.

For e.g.

$$
\text { पक्का,मुख्य,योग्य,नाघ्यो,बच्चा,मज्जा,ज्याला }
$$

- The second way of writing a conjunct consonant symbol is the one in which the first consonant symbol is written full-shape, and the second consonant symbol is written halfshape, or is at least modified.

For e.g

ङ्याउ,छयाप्नु, ट्याम्को,ठ्याम्म,जँड्याहा, ढ्याम्म etc.

- The third way of writing a consonant conjunct symbol is the one in which the second consonant symbol in the (Consonant Consonant CC clusters is written half.

For e.g.

गाग्रो, तिघ्रा,प्रश्न,ब्राम्हण etc.

2.1.6.2. Irregular conjunct forms of the consonant symbols

Following are the irregular conjunct forms of different consonant symbols; they are listed in the Devanagari alphabetical order [7]:

$$
\text { भक्त,अक्षर,मज्जा,ज्ञान etc. }
$$

Additional symbols: bindu, anusvar and visarga. The Devanagari writing system also uses additional symbols which are called bindu, anusvar and visarga(all Sanskrit names).

With the above discussion on the basic writing system of Nepali, we now move to the form classes (lexicon) and the phrase, clause and sentence structures (grammar).

## 3. Form Classes (Lexicon)

The Nepali Grammar consists of both the inflected and the uninflected forms, sometimes also called as open and closed classes as well. These constitute the parts of speech of the Nepali Grammar. The open class include noun, adjective, verb and adverb whereas pronoun, coordinating conjunction, subordinating conjunction, postposition, interjection, vocative and nuance particle come under the closed class.

### 3.1. Nouns

Nouns inflect for number (singular and plural) and for the seven cases as listed in the table 4 below. They do not inflect for gender (masculine vs. Feminine). Nepali nouns show inflectional contrasts for singular vs. Plural, e.g. मानिस(man -singular), मानिसहरू (menplural) [7].

Table 4. The number and case suffixes of nouns

| Cases | Singular | Plural |
| :---: | :---: | :---: |
| Nominative (Nm) | - | हरू |
| Accusative (Ac) | लाई | हरूलाई |
| Instrumental (In) | ले | हरूले |
| Dative(Dt) | लाई | हरूलाई |
| Ablative(Ab) | बाट | हरूबाट |
| Genitive (Gn) | को | हरूको |
| Locative(Lc) | मा | हरूमा |

### 3.1.1. Function of noun

The nouns function as the heads in the noun phrase (NP) structures. They also function as dependents of postpositions ( $\mathrm{pp}$ ) in the postpositional phrases (pp) [7].

### 3.1.2. Dependents of noun

The dependents of noun are determiners, i.e. demonstratives, specifiers, and modifiers, i.e. adjectives, numerals and the dependent nominals [7].

### 3.1.3. Lexical morphology of nouns

The most frequent noun-forming derivational suffixes are याइ,आइ. [7] .For eg. मूख्याइ,हसाँइ, हिडाइ.

### 3.1.4. Special characteristics of Nepali nouns

Here we deal with some of the special characteristics of Nepali nouns [6].

i) The plural suffix -हरू when added to nouns, a plural of the noun is formed. For eg., राजा, king(sing.), राजाहरू, kings(pl.)

ii) The demonstratives यो and त्यो change to यी and ती for plural nouns.

iii) When preceded by a numeral, the noun usually remains singular.

iv) When the noun is qualified by धेरै 'much, many' the addition of the extra suffix -हरू is optional and in spoken Nepali is often ommited.

v) In written and sometimes in spoken Nepali -को changes to का before plural nouns. In this respect it behaves like an adjective.

### 3.2. Adjectives

Adjectives end in -o and inflect for gender (masculine vs. feminine), and number (singular vs. plural). Inflections of adjectives is illustrated in the table 5 below [7]:

Table 5. Inflections of adjectives

| Singular number <br> Masculine | Feminine | Plural number <br> Masculine/Feminine |
| :---: | :---: | :---: |
| राम्रो | रामी | राम्रा |
| बाठो | बाठी | बाठा |
| लाटो | लाटी | लाटा |
| कालो | काली | काला |
| मोटो | मोटी | मोटा |


| Singular number <br> Masculine | Feminine | Plural number <br> Masculine/Feminine |
| :---: | :---: | :---: |
| सानो | सानी | साना |
| ठुलो | ठुली | ठुला |
| बुढो | बुढी | बुढा |
| तरूनो | तरूनी | तरूना |

Nepali also includes a set of uninflected adjectival forms borrowed from Hindi or Sanskrit, which show the same distribution and functions as adjectives, e.g.

$$
\begin{array}{cc}
\text { असल केटो } & \text { असल केटी } \\
\text { असल केटाहरू } & \text { असल केटीहरू }
\end{array}
$$

### 3.2.1. Function of adjectives

The adjectives function as the heads of the adjective phrase (AdjP) structures. The AdjP's also function as pre-head modifiers in the noun phrases (NP) structures [7], e.g. बिरामी मानिस ।

### 3.2.2. Dependents of adjectives

The dependents of the adjectives are quantifiers which quantify the adjectives, by showing degrees of intensity including the comparative and superlative forms [7].

### 3.2.3. Lexical Morphology

There are several derivational suffixes that mark the adjectives in Nepali. The suffix इलो derives adjectives from nouns and verbs [7], for eg.

$$
\begin{aligned}
& \text { रस+इलो=रसिलो } \\
& \text { हाँस सइलो=हँसिलो } \\
& \text { मल+इलो=मलिलो }
\end{aligned}
$$

### 3.2.4. Special characteristics of Nepali adjectives

Here we deal with some of the special characteristics of Nepali adjectives [6]. i) Adjectives always precede the noun they qualify.

ii) The demonstrative adjectives are: यो 'this' and त्यो 'that'.

iii) The possessive adjectives मेरो 'my', तिम्रो 'timro',हाम्रो 'our', like all other adjectives precede the noun they qualify.

iv) In written and occasionally in the spoken language, adjectives ending in -o change their endings to -a before a plural noun.

v) In Nepali there are a number of words for 'good'.

- राम्रो, though strictly speaking means 'pleasing to the eye', 'beautiful', is now used in most senses of the English 'good'.
- मीठो means 'good to the taste' and is only used for food and drink.
- असल means 'of good quality' or 'morally good'. 
- बेस and its emphatic form, i.e. stressing on the emphasis बेसै again refers to quality. 
vi) Repetition of an adjective indicates plurality. It should be, however, noted that especially the reduplicated forms सानसाना 'small', and ठूलठूला 'big' which always have the plural ending.

vii) Comparison of adjectives is effected by means of the postpositions -भन्दा 'than'.

- Comparative

- Superlative

This is effected by means of the phrase सब भन्दा 'than all'.

The adjective सब 'all', 'every' usually takes a singular noun:

viii) Questions may be asked by using an interrogative word like कहाँ 'where?', के 'what?', को 'Who?' कुन 'Which?'. Note that कुन is an adjective.

ix) Adjectives ending in ओ and the postposition -को have a feminine singular form in -ई (e.g. बूढी, मेरी,-की), which is occasionally used with nouns denoting females.

The use of a feminine verb with a feminine noun is obligatory.

Note: तपाईकी 'of you', 'your'

Feminine forms, though occasionally employed in spoken Nepali, are largely a feature of the written language.

### 3.3. Verbs

Verbs in Nepali inflect to show contrasts for the first, second and third persons, singular and plural numbers, masculine and feminine gender of a subject in third person singular and tense (present, past and future), for person:

$$
\text { जान्छु, जान्छ, जान्छ, , जान्छे, जानेछु }
$$

The verbs also inflect to show contrasts of the grades of honorofics in second and third persons, e.g.

जान्छस्(LGH), जान्छौं(MGH), जानुहुन्छ(HGH).

The verbs also inflect for infinitive, e.g. जानु, जान for perfective participle, e.g. गएको, जाने, जादा, गएर

The verbal inflections or verbal inflectional suffixes indicate that there are at least three levels of honorifics reflected in everyday spoken Nepali [7].

### 3.3.1. Function of verbs

The verbs function as the head of the clause structure. As heads of the clause structure, verbs stand either alone or in construction with various types of complements, e.g. Direct object, object complement and subject complements, adverbial complements, and optional adverbial adjuncts [7].

### 3.3.2. Dependents of verbs

Verbs show various dependents called complements which subclassify them into three main types: (transitive, equational and intransitive). Transitive verbs take direct objects as complements, equational verbs take subject complements as dependents; and intransitive verbs are marked by the absence of either direct object or subject complements.

Verbs,as heads of the clausal structures, also cooccur with indirect dative complements(dependents) such as adverbial complements, adverbial adjuncts and adverbial disjuncts [7].

### 3.3.3. Lexical Morphology

The verbs have simple or compound stems, marked by the infinitive suffix -नु when they are cited in the dictionary, e.g. खानु, लाउनु,सुत्रु, रूनु,कराउनु etc. The forms खा,ला,सुत्रू are simple stems and नु marks their citation forms. In compound verb stems, the first stem is suffixed with इ and the second verb stem दि. Then follows the citation form marker नु. Verbs derived from nouns and adjectives are marked by the derivational suffix -आउ,e.g. रोग (ना), रोगाउनु(क्कि). The derivational suffix आउ also marks the causative verb stems [7], e.g. गर्नु/गराउनु

### 3.3.4. Special Characteristics of Nepali Verbs

Here we deal with some of the special characteristics of Nepali verbs [6].

i) The third person singular forms छ and हो both mean 'is'. The difference between them is that, generally speaking, छ locates (i.e. indicates where someone or something is) and हो defines (i.e. indicates how. Who or what someone or something is). The verb usually comes at the end of the sentence.

ii) छ is often used in contexts where according to the above rule हो would be expected. For instance, it would be quite correct to say कलम राम्रो छ without any real difference being made to the sense. In certain idiomatic expressions like ठीक छ 'it's all right',हो would infact be incorrect. In statements, therefore, छ is often used in place of हो to define. In questions asking for a definition (usually with के 'what?' and को 'Who?') हो is invariably used. Thus in the question तिम्रो नाउँ के हो? 'What is your name?' छ would be incorrect.

In spoken Nepali, the same sentence may be expressed:

## पुस्तकालयमा धेरै किताब छ।

iii) Nepali verbs have special negative forms. The negative forms corresponding to छ, and हो are छैन and होइन respectively. The plural negative forms are छैनन् and होइनन् respectively.

iv) The third person singular verb रहेछ is used in place of छand हो implying that a fact has just been discovered or that it was contrary to what had been expected. It may often be translated 'Oh, I see that ...is'. रहेछ is frequently used with the particle पो

v) The Nepali verb has several infinitives. The infinitive by which the verb is referred to in dictionaries ends in the suffix -नु. Thus गर्नु 'to do', आउनु 'to come', जानु 'to go'. As noted earlier, the verbs $छ$ and हो share a common infinitive हुनु 'to be'. vi) The Nepali verb has several infinitives. The infinitive by which the verb is referred to in dictionaries ends in the suffix -नु. Thus गर्नु 'to do', आउनु 'to come', जानु 'to go'. As noted earlier, the verbs छ and हो share a common infinitive हुनु 'to be'.

vii) The Primary Base of the verb, to which suffixes are added to form certain tenses and participles, is obtained from the infinitive by dropping the suffix

| Group Infinitive <br> a) गर्नु <br> बस्नु | Primary Base <br> बस् to sit, to stay |
| :---: | :---: |
| b) खानु | खा to eat |
| जानु | जा to go |
| दिनु | दि to give |
| उभिनु | उभि to stand |
| c) धुनु | धु to wash |
| रूनु | रू to weep |
| d) बिर्सनु | बिर्स to forget |
| दुहुनु | दुहु to milk |
| e) आउनु | आउ to come |
| पठाउनु | पठाउ to send |
| पिउनु | पिउ to drink |

-नु as shown below:

Nepali verbs are then divided into five groups according to the nature of their primary base:

a) Base ending in a consonant: गर, बस्

b) Base ending in the vowels-आ, इ: खा, जा, दि

c) Base of one syllable ending in the vowel -उ: धु,रू

d) Base of more than one syllable ending in the vowels -अ,उ: बिर्स,दुहु

e) Base ending in the vowels आउ,इउ: पठाउ, पिउ

Verbs belonging to the last three groups $\mathrm{c}, \mathrm{d}$ and $\mathrm{e}$ also have a secondary base.

The Secondary Base of the verbs belonging to group (c) is formed by changing the Primary Base vowel -u to -o. That of verbs belonging to groups (d and (e) is formed by dropping the final vowel of the Primary Base. Thus:

Table 8. Formation of the Secondary Base of verbs

| Infinitive | Primary <br> Base | Secondary Base |
| :---: | :---: | :---: |
| c) धुनु | धु | धो |
| d) बिर्सनु | बिर्स | विर्स् |
| दुहुनु | दुहु | दुह् |
| e) आउनु | आउ | आ |
| पिउनु | पिउ | पि |

The group (b) verb जानु (Primary Base जा) has an irregular Secondary Base ग. The personal suffixes of the Simple Past Tense, which are added to the

Primary Base of Verbs belonging to groups (a) and (b) and to the Secondary Base of Verbs belonging to groups (c),(d) and (e) are as follows:

Table 9. Personal suffixes of the Simple Past Tense

| Pronoun | Affirmative | Negative |
| :---: | :---: | :---: |
| म | - एँ | - इँन |
| तँ | - इस् | - इनस् |
| उ,त्यो,यो | -यो | -एन |
| हामी (-हरू) | -यौं | एनौं |
| तिमी (-हरू) | -यौं | एनौं |
| उनी (-हरू) | -ए | एनन् |

The HGH forms of the Simple Past Tense have

| Pronoun | Affirmative | Negative |
| :--- | :--- | :--- |
| ऊ | -ई | इन |
| उनी | -इन् | इनन् |

m.) and भएन(neg.) added to the infinitive. The subject of a transitive verb in the imple Past Tense always takes the postposition-ले. The Simple Past Tenses of गर्नु (transitive) and आउनु (intransitive) are thus:

Table 10. Simple Past Tenses of गर्नु (transitive) and आउनु (intransitive)

| a) गर्नु | Affirmative | Negative |
| :---: | :---: | :---: |
| मैले | गरें | गरिंन |
| तैंले | गरिस् | गरिनस् |
| उसले | गर्यो | गरेन |
| हामीले | गर्यौं | गरेनौं |
| तिमीले | गर्यौं | गरेनौं |
| उनले, उनीहरूले | गरे | गरेनन् |
| तपाइंले, वहाँले | गर्नुभयो | गर्नुभएन |


| (b) आउनु | Affirmative | Negative |
| :---: | :---: | :---: |
| म | आएँ | आइनँ |
| तँ | आइस् | आइनस् |
| उ | आयो | आएन |
| हामी | आयौं | आएनौं |
| तिमी | आयौं | आएनौं |
| उनी (-हरू) | आए | आएनन् |
| तपाइँ, वहाँ | आउनुभयो | आउनुभएन |

It should be noted that when the verb is transitive, the pronouns take the postposition-ले. Note that म and तँ with -ले become मैले and तैले

Third person forms have the following optional feminine suffixes.

## Table 11. Third Personal forms and the feminine suffixes


The Simple Past Tense denotes action completed at some time in the past.

Note: पोहोर साल or simply पोहोर 'last year'

तपाइंको छोरा कहिले आयो? अस्ति आयो।

When did your son come?

He came the other day. अस्ति strictly means 'the day before yesterday', but is frequently used loosely in the sense of 'the other day'. अस्तिको preceding the days of the week means 'last' अस्तिको विहिबार म घंरै बसें।

Last Thursday, I stayed home. गएको means 'last' in all contexts.

In written Nepali गत is used for 'last'. Thus गत बिहिबार 'last Thursday', गत वर्ष 'last year' (वर्ष is an alternative spelling for बर्ष) । the past tense of the verbs छ and हो (corresponding to English 'was' and 'were' is formed from the base थि- to which the suffixes are added regularly.

| Pronoun | Affirmative | Negative |
| :---: | :---: | :---: |
| म | थिएँ | थिइनँ |
| तँ | थिइस् | थिइनस् |
| उ | थियो | थिएन |
| हामी | थियौं | थिएननों |
| तिमी | थियौ | थिएननंं |
| उनी (-हरू) | थिए | थिएनौं |
| F. उ | थिइन् | थिइनन् |
| उनी(-हरू) | थिइन् | थिइनन् |
| HGH तपाइं, <br> वहाँ | हुनुहुन्थ्यो | हुनुहुन्नथ्यो |

Note that the HGH suffixes -हुन्थ्यो (affirmative) and -हुन्नथ्यो (neg.) are added to the infinitive. थियो is used both to locate and define

The base भ is used only with past tense and past participle suffixes. Strictly speaking भ- functions as the Secondary Base of the verb हुनु though usage of the tenses and participles formed from this base should be carefully noted. The Simple Past Tense is formed from the base भ - regularly:

भयो may literally be rendered in English as 'has become', "became'. The alternative translations in the following examples should, however, be carefully noted:

Table 12. Past Tense of the verbs छ and हो

The affirmative suffixes of the Simple Indefinite Tense are as follows:

1 sing. (म) -छु

1 plur. (हामी etc.) -छौंं

2 sing. (तँ) -छस्

$2 \mathrm{MGH}$ (तिमी etc.) - छौ

3 sing. LGH (ऊ etc.) -छ

$3 \mathrm{MGH}$. Plur. (उनी,उनीहरू) -छन्

There are also four special feminine suffixes:

2 LGH -छेस् $3 \mathrm{LGH}$-छे, $2 \mathrm{MGH}$-छयौं $3 \mathrm{MGH}$ - छिन्

It should be noted that the suffixes of the Simple Indefinite are identical to the forms of छ.

The suffixes are added directly to the Primary Base of the verbs belonging to Group (a).

1 (b), (c), (d) have नinfixed between the vowels of the Primary Base and the suffix:

Verbs belonging to Group

(e) have the second vowel of the Primary Base nasalised before the suffix:

$\mathrm{HGH}$ (तपाई, वहाँ etc.) forms of all groups have the suffix -हुन्छadded to the infinitive:

The full conjugation of the Simple Indefinite Tense of गर्नु is as follows:

Table 13. Full conjugation of the Simple Indefinite Tense of गर्नु

| 1 sing. | म | गई्छु |
| :--- | :--- | :--- |
| 2 sing. LGH | तँ | गर्छस् (गर्छेस्) |
| 3 sing. LGH | उ, त्यो, यो | गई्छ |
| 1 plur. | हामी (-हरू) | गई्छौं |
| 2 sing. pl. MGH | तिमी (-हरू) | गछ्छौ, गछर्यौं |
| 3 sing. MGH | उनी, तिनी, यिनी | गर्छन् (गर्छिन्) |
| 3 plur. LGH, MGH | उनीहरू | गर्छन् |
| 2 sing. pl. HGH | तपाईँ(-हरू) | गर्नुहुन्छ |
| 3 sing. pl. HGH | वहाँ(-हरू) | गर्नुहुन्छ |

Similarly:

$$
\begin{aligned}
& \text { म खान्छु } \\
& \text { तँ खान्छस् } \\
& \text { म धुन्छु } \\
& \text { तँ धुन्छस् } \\
& \text { मबिर्बन्छु } \\
& \text { तँबिर्सन्छछस् } \\
& \text { म आउँछछ } \\
& \text { तँ आउँछस् }
\end{aligned}
$$

The Simple Indefinite Tense refers to action performed at regular intervals or as a matter of habit. It can often be translated by the English simple present tense. 'I do, I eat, I go' etc.

Note that बस्नु means both 'to sit down' and 'to reside':

Note the expression चुरोट खानु 'to consume cigarettes', i.e. 'to smoke', खानु means both to eat and to drink:

The verb पिउनु 'to drink', though it may be used for any liquid, is frequently used in the context of alcohol.

viii) The Simple Indefinite Tense is also used with reference to future time and in some contexts may be translated. 'I shall do, I am doing', etc. For eg.,

ix) A Present Continuous Tense (corresponding to the
English 'I am doing') is formed with the Imperfect participle in -दै followed by the auxiliary verb छ.

x) The Imperfect Participle is formed by adding the suffix -दै directly to the base of verbs belonging to group (a). The final vowel of the Primary Base of verbs belonging to other groups is nasalised before the addition of the suffix. For eg.,

$$
\text { गर्दे, बस्दै,खाँदै,जाँदै, दिंदै, धुँदैद,आउँॅै, पिउँदै, etc. }
$$

The present continuous tense is then formed as follows:

Sometimes, it also may be used with reference to future time.

xi) The negative suffixes of the Simple Indefinite Tense are as follows:

$$
\begin{aligned}
& \text {-दिन } \\
& \text {-दैनस् } \\
& \text {-दैन } \\
& \text {-दैनौं } \\
& \text {-दैनौं } \\
& \text {-दैनन् }
\end{aligned}
$$

The final vowel of the 1 'st person singular suffix is sometimes nasalized दिंन.

The negative suffixes are added directly to the base of the verbs belonging to the group (a):

गर्दिन, गर्देंनस्, गदैनेंन, गर्दैनों, गदैनेनौ, गदैंनन्

When the base ends in an unvoiced consonant, i.e. क,ख,च,ट,ठ,त,थ,प,फ,स, the द of the suffix may be 'devoiced' to त, i.e. -दिन becomes तिन. Thus म बस्तिन 'I do not sit', उ सुत्तैन 'he does not sleep'. There is however, a growing tendency to use the suffix in -द-, whatever the nature of the base and बस्दैन is now commonly written and spoken.

Verbs belonging to all other groups (i.e. with primary bases ending in a vowel) have the final vowel nasalized before the suffix is added:

For eg.,

HGH forms have the suffix -हुन्र added to the infinitive in -नु

The negative of the Simple Indefinite Tense has the following feminine forms:

3 sing. LGH उ गर्दिन, 3 sing. MGH उनी गर्दिनन्

Verbs belonging to the groups (b), (c), (d) and (e) have alternative negative forms of which the suffixes are:

$$
\begin{aligned}
& \text { म-न्न } \\
& \text { तँ-न्नस् }
\end{aligned}
$$

$$
\begin{aligned}
& \text { उ-ন्र } \\
& \text { हामी-न्रौं } \\
& \text { तिमी -न्रौ } \\
& \text { उनी (हरू) -न्न्त् }
\end{aligned}
$$

These suffixes are added directly to the Primary Base.

$$
\begin{aligned}
& \text { म जान्न । } \\
& \text { तँ आउन्नस् । } \\
& \text { उ खान्न । } \\
& \text { उनी पिउन्नन् । } \\
& \text { हामी धुन्नौं । } \\
& \text { तिमी बिर्सन्नौं । } \\
& \text { उनीहरू जान्नन् । }
\end{aligned}
$$

Verbs which may take a direct object are known as transitive verbs.

दुहुनु are all transitive verbs.

Verbs which cannot take a direct object, such as जानु, आउनु, बस्नु, are known as intransitive verbs.

When the object of a transitive verb is:

(1) a proper noun (राम,गणेश etc.) or

(2) a noun or pronoun referring to the person (मान्छे,बहिनी,म,उ,त्यो,etc), the postposition -लाई must be added to the object of the verb.

xii) A Simple Indefinite Tense is also regularly formed from the Primary Base हु as shown in the table below:

Table 14. Simple Indefinite Tense from the primar base हु

| Affirmative | Negative |
| :---: | :---: |
| म हुन्छु | हँदिन |
| तँ हुन्छस् | हुँदैनस् |
| उ हुन्छ | हुँदैन |
| हामी हुन्छौं | हुँदैनौं |
| तिमी हुन्छौं | हुँदैनौ |
| उनी(हरू) हुन्छन् | हुँदैनन् |
| तपाइँ हुनुहुन्छ | हुनुहुन्न |
| वहाँ हुनुहुन्छ, | हुनुहुन्न |

The alternative negative forms are:

$$
\begin{aligned}
& \text { हुन्र हुन्नौं } \\
& \text { हुन्नस् हुन्नौं } \\
& \text { हुन्न हुन्तन् }
\end{aligned}
$$

हुन्छ, though usually translated as 'is' differs from छ, and हो in that it is used to denote a general fact or occurrence. For this reason हुन्छ is frequently used with adverbs like अक्सर 'often', सधैं 'always', and धैरैजसो 'mostly, usually'. For example, the sentence 'mangoes are sweet' states a general fact. They are sweet by nature. This is rendered in Nepali as आँप गुलियो हुन्छ. In the sentence 'This mango is sweet', a particular instance is referred to: यो आँप गुलियो छ or हो।

The Simple Indefinite Tense हुन्छ is also used with reference to future time.

The four verbs which can be translated by the English verb 'to be':

a) हो used only to define and obligatory in questions of the type: के हो?, को हो?, 'What is?', 'Who is?'

b) छ used mainly to locate, but also frequently in statements in place of हो to define;

c) हुन्छ used to denote a generality or a regular occurrence, and also with reference to future time.

d) रहेछ used in place of छ and हो indicating surprise.

xiii) The HGH imperative is formed by adding -होस् to the infinitive of the verb:

$$
\begin{gathered}
\text { गर्नुहोस् -> do } \\
\text { बस्नुहोस् -> sit } \\
\text { आउनुहोस् -> come } \\
\end{gathered}
$$

Note that भित्र is used both as an adverb and a postposition "in", "inside"

xiv) The negative of the HGH imperative is formed by adding the prefix न to the positive form.

The ending -नुहोस् is often pronounced and sometimes written as -नोस्:

पाल्नुहोस् or पाल्नोस् come, go नआउनुहोस् or नआउनोस् do not come गर्नुहोस् or गर्नोस् do
xv) Many Nepali verbs have passive or impersonal counterparts which are formed by adding the suffix इ to the base of verbs belonging to groups (a) and (b) and to the secondary base of the verbs belonging to groups (c), (d) and (e). Thus the active verb गर्नु 'to do' is made passive by extending the base with the suffix -इ; गरिनु 'to be done'. Such verbs are often referred to as 'I-stem' verbs.

In general only the infinitive, 3'rd person forms and certain participles of such verbs are used.

I-stem verbs are conjugated like other verbs belonging to group (b) with a base ending in इ, e.g. दिनु, and have the full range of tenses and participles. The I-stem forms of गर्नु are considered below.

Table 15. Formation of verbal conjugates from Istem base verbs

| I-Stem base | गरि- | To be done |
| :--- | :--- | :--- |
| Infinitive | गरिनु | It is done |
| Simp. Indef. 3 s. <br> aff. | गरिन्छ | It is not done |
| Simp. Indef. 3 s. <br> neg. | गरिदैन | They are done. |
|  | गरिन्न | They are not <br> done. |
| Simp. Indef. 3 <br> pl. aff. | गरिन्छन् | It was done |
| Simp. Indef. 3 <br> pl. neg. | गरिदैनन् | It was not done, <br> etc. |
| गरिन्नन् |  |  |
| Simp. Past 3 s. <br> aff | गरियो |  |
| Simp. Past 3 s. <br> neg. | गरिएन |  |

The above applies to other verbs like: भन्नु' 'to say', सुन्तु 'to hear',देख्रु 'to see'

Note that all I-Stem verbs may have the alternative Simple Indefinite negative forms:

गरिन्न, देखिन्न, चाहिन्न, पाइन्न
The transitive verb पाउनु means 'to find', 'to receive', 'to get', 'to earn money' etc.

Thus:

The Simple Past forms of the transitive verb पायो, पाएन 'he got', 'he did not get' must be carefully distinguished from the impersonal forms, पाइयो 'it was found', पाइएन 'it was not found'.

The Simple Past forms of the transitive verb पायो, पाएन 'he got', 'he did not get' must be carefully distinguished from the impersonal forms, पाइयो 'it was found', पाइएन 'it was not found'.

In sentences as shown below, the 3'rd person singular of the transitive verb भन्तु may also be used:

प्रयोग गर्नु 'to use' प्रयोग गरिनु 'to be used'

The I-Stem verb चाहिनु 'to be required', 'to be needed is' formed from the comparatively rarely used transitive verb चाहनु 'to want'

The Simple Indefinite form चाहिन्छ is mainly used to express 'it is generally required' or 'it will be required'. Thus:

Note the use of लाई in this construction.

In practice the Simple Indefinite चाहिन्छ is sometimes used where according to the above rule चाहियो would be expected. Thus चिया चाहिन्छ ... is also correct, but less common.

बा is an exclamation of disgust.

In general, only transitive verbs possess I-Stem counterparts. There are, however, a few intransitive verbs which also possess them. One common example is पुगिनु 'to be reached', formed from the intransitive verb पुग्नु 'to arrive'.

In the above examples the verb is used impersonally. However, if a subject word is expressed, the transitive verb पुग्नु must be used:

The verb पुग्नु may also mean 'to suffice', 'to be enough'. In this case the postposition ले is always added to the subject word:

In spoken Nepali पुग्छ and पुग्दैन are often used impersonally instead of their I-Stem counterparts:

Strictly speaking पुगिन्छ and पुगिदैंन would be correct. In the same way, पाउँछ is often used in place of पाइन्छ।

The transitive verb खोल्नु 'to open' has an intransitive counterpart खुल्नु 'to be opened', 'to come open'

But the adjective खुला means 'open'.बाटो अहिले खुला छ

रे। they say the road is now open.

xvi) The imperative forms of the Nepali verbs also require special attention:

1) The LGH (तँ) imperative is formed as follows:

a) Verbs belonging to groups (a) and (b) - the LGH imperative is identical with the base of the verb: For eg.

$$
\begin{aligned}
& \text { गर do बस् sit down } \\
& \text { खा eat उभि stand }
\end{aligned}
$$

b) Verbs belonging to groups (c) and (e) -the LGH imperative is identical with the Secondary Base of the Verb. For eg.,

$$
\begin{aligned}
& \text { धो wash पठा send } \\
& \text { पि drink आ come }
\end{aligned}
$$

c) Verbs belonging to the group (d) in most cases have the suffix ई इई added to the secondary base of the verb: For eg.

$$
\begin{gathered}
\text { दुही milk बिर्सिई forget } \\
\text { सम्झी remember }
\end{gathered}
$$

दिनु and लिनु have irregular LGH imperatives: दे 'give', ले 'take'.The LGH imperative of आउनु is sometimes आइज as well as आ

2) The MGH (तिमी) imperative is formed as follows.

a) Verbs belonging to group (a) have the suffix -a added to the base: गर do बस sit down

b) Verbs belonging to group (b) have the suffix -u and sometimes the suffix -o added to the base: खाऊ eat जाऊ go उभिऊ or उभिओ stand up

c) Verbs belonging to the groups(c) and (e) have the suffix -u added to the

secondary base: धोऊ wash आऊ come ल्याऊ bring

3) Verbs belonging to group (d) have the suffix -a added to the secondary base: दुह milk बिर्स forget सम्झ remember

दिनु and लिनु have irregular imperative forms for the MGH: देऊ give लेऊ take

The verb हो has the imperative forms:

$\mathrm{LGH}$ हो $\mathrm{MGH}$ होऊ be

The negative of the imperative is formed by adding the prefix न:

नगर नखाऊ नदेऊ नआ नहोऊ नबिर्सिई

Examples of the imperative

## LGH

## MGH

## $\mathrm{HGH}$

xvii) The conjunctive participles are formed by adding one of the three suffixes:

-एर ,-ई, ईकन to the Base of the verbs belonging to groups (a) and (b) and to the Secondary Base of the verbs belonging to the groups(c), (d),(e) respectively. In the table below, we look at the three forms for the five different categories of verbs:

Table 16. Formation of the conjunctive participles

| -एर | -ई | -ईकन |
| :---: | :---: | :---: |
| (a)गरेर | गरी | गरीकन |
| बसेर | बसी | बसीकन |
| (b)खाएर | खाई | खाईकन |
| दिएर | दिई | दिईकन |
| (c) धोएर | धोई | धोईकन |
| (d) बिर्सेर | बिर्सी | बिर्सीकन |
| दुहेर | दुही | दुहीकन |
| e) आएर | आई | आईकन |
| पिएर | पिई | पिईकन |
| जाने / गएर | गई | गईकन |
| हननु/भएर | भई | भईकन |

Of the three forms, the participle in -एर is by far the most common. The other two forms are by and large stylistic alternatives. The form of the participle is invariable.

The negative of the conjunctive participle is formed by prefixing the negative participle -न to the positive form:

## नगरेर नगरी नगरीकन <br> नआएर नआई नआईकन

In sentences where the subject of the conjunctive participle is the same as the subject of the main verb,
the participle may literally be translated 'having done', 'having come' etc.

The conjuctive participle in ई may be used in exactly the same way.

When a long narrative contains several conjunctive participles, the participle in -ई is often used to avoid the monotonous repetition of the syllable -एर.

The particle in -ईकन is more emphatic than the other two forms and is used rather less frequently: For eg.,

### 3.4. Adverbs

Adverbs in Nepali are uninflected forms. Adverbs show the gradation of comparative and superlative degrees by syntactic means of their dependents (quantifiers or adverbs of quantity).

### 3.4.1. Function of adverbs

Adverbs occur as independent of or as the head of an adverbial phrase (AdvP) structure, and function as dependents of the verb, i.e. As complements or adjuncts, e.g राम्ररी खाउँ. Adverbs also function as quantifiers (or intensifiers) of adjectives, e.g. साहै राम्रो, or other adverbs, e.g.साहै छिटो. The adverbs which function as quantifiers of adjectives or quantifiers of other adverbs are "adverbs of quantity" [7].

The comparative and superlative formations of the adverbs are syntactic, not morphological, e.g.
Comparative: अलि विस्तारी वा झन् विस्तारी

Superlative: ज्यादै विस्तारी

### 3.4.2. Dependents of adverbs

The dependents of the adverb are quantifiers that indicate the gradation of adverbs, e.g. विस्तारै वा झन् विस्तारै. Such constructions with adverbs as heads and their dependent adverbs (quantifiers) are called analytic comparative and superlative constructions [7].

### 3.4.3. Lexical Morphology

Adverbs are marked by the derivational suffixes अरी,-साथ,-वित्तिकै,-पूर्वक, (जस्तै

राम्ररी,खुशीसाथ,जानेवित्तिकै,आनन्दपूर्वक).Those adverbs, which are not so marked by derivational suffixes are adverbials. Adverbials function and distribute in the same way as adverbs in phrasal and clausal constructions [7].

### 3.4.4. Special Characteristics of Nepali Adverbs

Below, we present some of the special characteristics of Nepali Adverbs [6] :

i) The interrogative adverb कहिले means 'when?' For eg.

The phrase कहिले कहीं means 'sometimes'

कहिले पनि followed by a negative verb means 'never', 'not ever':

Similarly, the adverb कतै 'somewhere' followed by a negative verb may be translated nowhere', 'not anywhere'

ii) The interrogative adverb कसरी 'how?', 'by what means?' must be distinguished from the adjective कस्तो 'how?', 'of how quality?' 'in what state'.

Compare the following:

Note that the adverbs and adverbial phrases often directly precede the verb they qualify:

iii) जस्तो 'like', 'such as' may be used as an adjective and an adverb.

When used adverbially जस्तो immediately precedes the verb:

Note that कुरा may mean 'a thing' in the general sense, but often refers to something said. Thus तपाइंका कुरा may be translated ' what you said'. The expression कुरा गर्नु means 'to talk', 'to have a word':

### 3.5. Pronouns

Pronouns constitute a small closed class of forms that inflect for case and number in a way analogous to nouns. Pronouns belong indirectly to the gender of nouns to which they anaphorically refer. The gender of pronoun, like the gender of a noun, is shown syntactically in the third person by its cross reference tie to verb for which they function as subject [7].

### 3.5.1. Function of pronouns

Pronouns, as heads of the Pronoun phrase (ProP), and function as subject, or (direct or indirect) object complements, and adjuncts of verbs [7].

### 3.5.2. Dependents

Prononuns, as heads of the Pronoun phrases (ProP), do not occur with dependents such as determiners since the pronouns are inherently definite or determined. It should be noted, however, that in contrast, the common nouns as the heads of the common noun phrases (CNPs) do take the determiners as their dependents [7].

### 3.5.3. Lexical Morphology

Pronouns are marked by their simple (underived) forms that distinguish them from other form classes. The traditional grammars sometimes speak about pronomial adjectives as if they were pronouns [7], e.g. त्यो,यो,कुन.

### 3.5.4. Special Characteristics of Nepali Pronouns

Here we deal with some of the special characteristics of Nepali pronouns [6].

i) यो and त्यो are used as third person singular pronouns 'he', 'she', 'it'. यो refers to the person or thing nearer the speaker, and त्यो to the person or thing farther away. When no such distinction is implied, त्यो is usually employed. For eg.,

Obviously the translation he, she, it will depend on the context.

Unless ambiguity is likely to arise, the pronomial subject of the verb may be omitted. Thus छ, हो could mean "he/she/it is". The translation will be decided by the context.

ii) The interrogative pronouns को 'who?' and के 'what?' have no separate plural forms. Plurality is indicated by repeating the pronoun. For eg.,

iii)

The Nepali Pronomial System with its three honorific grades and special forms

The Nepali Pronomial System with its three honorific grades and special forms requires special attention. Second person pronouns ('you') and third person pronouns ('he', 'she', 'it', 'they') may be grouped into three major honorific grades:

## a) Low Grade Honorific (LGH) pronouns;

This form is used mainly for children in one's own family, family retainers and animals.

b) Middle Grade Honorific (MGH) pronouns;

This form is used mainly for other children, social inferiors, younger relations and intimate friends.

c) High Grade Honorific (HGH) pronouns;

This form is used mainly for older relations, acquaintances of equal status, and people to whom one owes a measure of respect.

For example, a family servant, one's own daughter might be addressed as 'สঁ' you' (LGH). The pronoun can equally be used to insult or to express endearment. A child belonging to someone else, a waiter in the hotel or a taxi driver might be addressed as तिमी 'you' (MGH). An elder relation, one's father, teacher or any other older acquaintance would be addressed as "तपाईँ" 'you' (HGH).

The honorific scale also extends to third person pronouns. Thus उ 'he/she' is LGH, उनी is MGH, and वहाँ and यहाँ are HGH.Whereas in third person pronouns there is no distinction of gender (उ,उनी mean both 'he' and 'she'), a distinction of nearness and farness is maintained.

In most cases, plural pronouns are formed by adding the plural suffix -हरू to the singular form. Thus तपाई sing HGH, तपाईहरू plur. HGH.

The following is a complete list of the personal pronouns:

| Singular |  |  |  |
| :--- | :--- | :--- | :--- |
| 1'st person |  | म |  |
| 2'nd person | LGH | तँ | you |
| 2'nd person | MGH | तिमी | you |
| 2'nd person | HGH | तपाईं | you |
| 3'rd person | LGH | ऊ | he/she |
| 3'rd person | LGH | यो, त्यो | he/she/it |

3'rd person MGH यिनी, तिनी,उनी he/she

3'rd person HGH यहाँ, वहाँ he/she

Plural

1'st person हामी,हामीहरू $\mathrm{We}$

2'nd person LGH/MGH तिमी,तिमीहरू You

2'nd person HGH तपाईहरू You

3'rd person LGH/MGH यिनीहरू,तिनीहरू,उनीहरू They

3'rd person HGH यहाँहरू, वहाँहरू They

The 2'nd person LGH pronoun สँ has no plural form. Instead, the MGH form is used. The 3'rd person LGH pronoun उ and the 3'rd person plural pronouns refer only to persons and not to things.

The affirmative and negative forms of Nepali verbs are greatly influenced and dependent on the Nepali pronomial system involving three different honorific grades. Given below in the tables 17 and 18 , we will see the illustrations for the two verbs "छ" and "हो" , both meaning "is".

| Personal pronoun | Affirmative | Negative |
| :---: | :---: | :---: |
| म | छु | छैन |
| तँ | छस् | छैनस् |
| यो, त्यो, उ | छ | छैन |
| उनी, यिनी, तिनी | छन् | छैनन् |
| तपाईँ, तपाइंहरू | हुनुहुन्छ, | हुनुहुन्न |
| हामी, हामीहरू | छौं | छैनौं |
| तिमी, तिमीहरू | छौं | छैनौं |
| उनीहरू, यिनीहरू, तिनीहरू | छन् | छैनन् |
| यहाँ, वहाँ | हुनुहुन्छ | हुनुहुन्न |
| यहाँहरू, वहाँहरू | हुनुहुन्छ, | हुनुहुन्न |

Table 17. Affirmative and Negative forms of the verb "छ"

| Personal pronoun | Affirmative | Negative |
| :--- | :--- | :--- |


| Personal pronoun | Affirmative | Negative |
| :---: | :---: | :---: |
| म | हुँ | होइन |
| तँ | होस् | होइनस् |
| उ | हो | होइन |
| उनी | हुन् | होइनन् |
| तपाई | हुनुहुन्छ | हुनुहुन्न |
| हामी | हौं | होइनौं |
| तिमी | हौं | होइनौं |
| उनीहरू | हुन् | होइनन् |
| वहाँ | हुनुहुन्छ | हुनुहुन्र |
| वहाँहरू | हुनुहुन्छ | हुनुहुन्न |

From the above tables it will be clear that the 3'rd person MGH pronouns (उनी,तिनी,यिनी) require the 3 'rd person plural verb forms छन् and हुन् and that all the HGH pronouns (तपाइं,वहाँ etc.) take the same forms. It will also be noted that the $\mathrm{HGH}$ forms of छ, and हो are identical.

The two verbs also share a common infinitive हुनु 'to be'. In English both verbs are translated as 'I am', 'you are', 'he/she is' etc., but as we have already seen, the function of छ is to locate and that of हो is to define.

The personal pronoun may be omitted in cases where confusion is not likely to arise as evident from the following example.

2'nd singular LGH तँ 'you' is reserved for social inferiors usually in the family. Children and servants of the speaker's family are often addressed as สँ. It is also used when speaking to animals and often used in poetry, something like English "thou". For eg.,

2'nd Singular MGH तिमी 'you' is reserved for social inferiors and for children not of the speaker's family. It may be used to address younger members of the family (sisters, brothers etc.). A man may address his wife as तिमी but she would not generally use it for the husband. A foreigner would do well not to use तिमी when addressing adult strangers.

2'nd Singular HGH तपाईं 'you' is used for anyone to whom respect is due. It is becoming customary to use 'तपाई' for any adult stranger regardless of his/her social status. A woman usually addresses her husband as तपाई

2'nd Plural MGH and HGH तिमीहरू,तपाईंहरू 'you' are used to address several people who would individually be addressed as तिमी and तपाईं. Occasionally in books and speeches, when a number of people are addressed as a group, the singular forms are used.

Note that the noun in predicative position remains singular.

1' st Plural हामी 'we' and the form हामीहरू are in most respects synonymous and interchangeable. If there is any difference हामी means 'we as a group'; हामीहरू 'we as individuals'. Occasionally हामी may be used by the speaker to refer to himself, in which case it would be translated as 'I'.

3'rd singular LGH उ 'he/she', यो, त्यो 'he/she/it'. We have already seen that the demonstratives may be used as 3'rd person singular pronouns. When proximity or distance is not implied त्यो is used rather than यो. These pronouns refer to persons, to whom no particular respect is due, and to things. उ is only used for persons.

3'rd singular MGH यिनी, तिनी, उनी 'he/she' are used for persons to whom a certain measure of respect is due. They are frequently used to refer to persons in novels and historical narrative, but not usually to refer to the royalty of Nepal or their ancestors. यिनी refers to the person nearer the speaker and तिनी to the person farther away. उनी is more or less synonymous with तिनी and perhaps used more frequently in speech.

Nouns denoting persons who would be referred to with a MGH pronoun take a 3'rd person plural verb:

The plural verb in the question and the use of उनी in the answer makes the sentences more polite than if the singular छ, and त्यो had been used.

3'rd singular HGH यहाँ वहाँ (sometimes written उहाँ) 'he,she' are used to refer to people who would be addressed as तपाईँ in the second person. The difference between यहाँ and वहाँ is again one of proximity. ${ }^{1}$

Nouns denoting persons referred to with a $\mathrm{HGH}$ pronoun require the homorific form of the verb.

When such a noun is preceded by the postposition -को in written and occasionally in spoken Nepali, -को becomes का (the plural concord denotes respect).

3'rd plural LGH/MGHयिनीहरू, तिनीहरू, उनीहरू 'they' are used only for persons:

Note that 'they' referring to things is left unexpressed.

In colloquial speech the singular forms of the adjectives and verbs may be used:

$$
\begin{aligned}
& \text { तिनीहरू कहाँ छ? } \\
& \text { मेरो किताबहरू कहाँ छ? }
\end{aligned}
$$

3'rd plural $\mathrm{HGH}$ यहाँहरू, वहाँहरू correspond to their singular counterparts.

$$
\text { वहाँहरू दरबारमा हुनुहुन्छ। }
$$

iv) कोही 'someone' and केही 'something' are 3'rd person singular indefinite pronouns. In English they may be translated 'anyone', 'anything', and in negative sentences 'no one', 'nothing'.

In negative sentences, the indefinite pronouns are often emphasized with the adverb पनि 'at all', 'also':

v) The oblique case of the 3'rd person pronouns is used before -लाई: For eg.

Note the postposition -तिर 'towards', 'about', 'approximately'.

vi) The oblique forms of को? 'Who?' कोको 'who?' (Plural), and कोही 'someone' are कसकस and कसै respectively.

vii) The oblique forms are used before postpositions: For eg.,

के “what?" And केही 'anything' have no oblique forms.

### 3.6. Coordinating conjunctions

The co-ordinating conjunctions are a closed class of uninflected forms. They are the following [7]:
अनि, कि,किन्तु,नकि,र, तर, वा, अथवा,कि...कि, न...न, परन्तु,

तैपनि,यद्जपि,तथा,या.

### 3.6.1. Function of co-ordinating conjunctions

The co-ordinating conjunctions function as connectors of equal level constituents at all levels.word,phrase, and clause level. The items which precede coordinating conjunctions and those that follow them need not both be of the same filler class, but both fill the same functional slot [7].

### 3.6.2. Dependents of co-ordinating conjunctions

The words, phrases and clauses connected by the co-ordinating conjunctions are not dependents since the coordinating conjunctions are not the heads of such constructions, but connect coordinate structures [7].

### 3.6.3. Lexical Morphology

As uninflected and underived class, the coordinating conjunctions are marked by their simple stems or complex stems (e.g. अथवा,तैपनि) and lack of lexical morphology [7].

### 3.7. Subordinating conjunctions

Subordinating conjunctions are a closed uninflected class. The closed list is: कि,भने, पछि,अघि,पनि,यदि etc [7].

### 3.7.1. Function of subordinating conjunctions

The function of subordinating conjunctions is to mark dependent (adverbial or noun) clauses as subordinate to the principal clause in sentential structures [7].

कि marks noun clause;

अगाडि marks adverbial clause;

पछाडि marks adverbial clause;

भने marks adverbial clause;

पछि, marks adverbial clause;

अघि marks adverbial clause;

पनि marks adverbial clause; यद्यपि marks adverbial clause.

### 3.7.2. Dependents of subordinating conjunctions

The dependent of a subordinating conjunction is a subordinate clause. The subordinate clause may be a relative adjectival clause, relative adverbial clause, adverbial clause or a noun clause [7].

### 3.8. Postpositions

Postpositions (comparable to prepositions in English) are called postpositions ( $\mathrm{pp}$ ) in Nepali since they occur after the nouns or noun phrases ( $\mathrm{Nps}$ ) with which they stand in construction. Postpositions are an uninflected, simple, or complex closed class of forms which function as the head of adverbial postpositional phrases (PP) which function as adverbial complements or adjuncts to the verbs in clausal structures [7].

### 3.8.1. Function of postpositions

The postpositions (pps) function as head in the postpositional adverbial phrase (Pps) structure. The Pps are dependent on verbs since they stand in the clausal construction as adverbial adjuncts, e.g. अगाडि"घर अगाडि बगैंचा छ," [7].

### 3.8.2. Dependents of postpositions

The dependents of the postpositions are nouns or noun phrases ( $\mathrm{Nps}$ ) or pronoun phrases (ProPs) of which the postpositions are heads [7].

### 3.8.3. Lexical Morphology

Postpositions are simple, or complex closed class without inflectional morphology [7].

### 3.8.4. Special characteristics of Postpositions in Nepali

Below, we try to present some special characteristics of Postpositions in Nepali [6].

i) Words like -मा 'in, at, on', -सित 'with', -सँग 'with', follow the word they govern and are

known as postpositions. In writing they are joined to the word they follow. For eg.,

The translation of -मा 'in, at, on' is decided by the context, -सँगand -सित are largely synonymous. In certain idiomatic phrases, one may be preferred to the other.

ii) The postposition -को 'of' deserves special attention. 'The book of the son' or 'the son's book' is expressed छोराको किताब 'boy of book'. Compare the following sentences.

In written and sometimes in spoken Nepali -को changes to का before plural nouns. In this respect it behaves like an adjective:

iii) The postpositions -बाट and -देखि both mean 'from'.

(Note the use of the adjective टाढा 'far' in the second sentence.) In sentences like the following only -देखि may be used:

iv) Postpositions may be added to adverbs like यहाँ, त्यहाँ, कहाँ For eg.,

v) Postpositions may be added directly to the personal pronouns, with a few exceptions: For eg.,

मसित 'with me', तँलाई 'to/for you', (-लाई 'to', 'for'), तिमीसँग 'with you', तपाइंको 'of you, your'. हामीकहाँ 'at our house' (-कहाँ 'at the house of'), केमा 'in

what?', उनीहरूको 'of them, their'.

vi) -को may not be added to the pronouns म, तँ, हामी, तिमी. Instead, the possessive adjectives मेरो 'of me, my'; तेरो 'of you, your' (LGH); हाम्रो 'of us, our'; तिम्रो 'of you, your' (MGH) are used.

vii) Before the majority of postpositions, यो and त्यो change to यस and त्यस respectively. Similarly, before postpositions, ऊ changes to उस, तिनी to तिन, यिनी to यिन, and उनी to उन. Thus:

$$
\begin{aligned}
& \text { यसको of him/her, his/her } \\
& \text { त्यससँग with him/her } \\
& \text { उसको of him/her, his/her } \\
& \text { उनलाई to him/her (MGH) } \\
& \text { त्यसपछि, after that, afterwards }
\end{aligned}
$$

viii) The postposition -लाई 'to/for' is used idiomaticallyin expressions like:

निश्चितता 'Certainty'

Note also the following expressions:

ix) The postposition - सम्मmeans 'up to', 'as far as', 'until'; for eg.

x) When the object of a verb is a noun denoting a thing or an animal, the postposition -लाई is not usually required: For eg.

xi) The postposition -ले deserves special attention. It may be translated 'by', 'with', 'from', 'of', 'in' etc. according to the context in which it occurs. It is encountered in many idiomatic expressions. Note the following:

The postposition -ले is often added to the third person subject of a transitive verb in the Simple Indefinite: For eg.

When the 3'rd person singular pronouns are used -ले requires the oblique case: उसले, यसले, उनले, तिनले, यिनले.

When -ले is added to the pronouns म and तँ, their forms are मैले and तैले respectively.

xii) The indirect object of a transitive verb is indicated by the postposition लाई 'to', 'for'. For eg.,

xiii) The postposition -तिर 'towards, about' is used in expressions of time for a rough approximation:

xiv) The postposition -मा is used in the following expressions:

## बस दुई दुई घण्टामा आउँछ।

The repetition of the numeral implies that the bus comes at regular intervals:

Note: हरेक 'every': हरेक मान्छे, 'every man', हरेक किसिम 'every kind' हरेक दिन 'every day'

$\mathrm{xv}$ ) Certain postpositions or postpositional phrases consist of two or more words, the first of which is

-को

-को लागि for, the sake of -को बारेमा about, concerning

-को निम्ति for, for the sake of -को निमित्त for ( a literary synonym of -को निम्ति) -को बाद म पन्ध्र दिनका लागि भारत जाँदै छु। I'm going to India for a fortnight. नेपालको बारेमा के थाहाँ छ? What do you know about Nepal?

$\mathrm{xvi}$ When a postpositional phrase with -को as the first element follows one of the pronouns म,तँ,हामी,तिमी, the possessive adjective is used.

xvii) Certain postpositional expressions consist of को and a noun followed by -मा -को उपलक्षमा on the occasion of -को विषयमा on the subject of, about

xviii) In written Nepali, the first element -को in compound postpositional phrases, is often changed to का, which is the oblique form of the postposition:

## -का लागि -का निमित्त

Similarly, adjectives ending in -o has the ending changed to -a if they qualify a noun which is governed by a postposition (i.e. They become oblique):

This, however, is entirely restricted to the written language and consistency is not always observed.

xix) The postposition -बाट is used idiomatically in certain expressions like:

-बाट is also used with adverbs like बाहिर 'outside', नजीक 'nearby'

नजीक may also be used as a postposition:

### 3.9. Interjections

Interjections constitute a small closed class of forms which show no inflection, dependents or lexical morphology. They function as syntactically independent parenthetical minor sentences, semantically complete but structurally reduced. Thus the interjections are in a way syntactically complete and syntactically independent of other elements in phrasal or clausal structures. The most frequent interjections in Nepali are [7]:

$$
\begin{gathered}
\text { अँ,अहँ,ओहो,अबुइ,लौं,छि::,धत्तेरिका,ला,अय्या, लौखा, धत्, जा, } \\
\text { ला. }
\end{gathered}
$$

### 3.9.1. Special characteristics of Nepali interjections

Below, we try to list down some special characteristics of Nepali interjections [6]:

भयो, which is a past tense form of the verb हुनु (to be) is also used as an interjection, meaning 'enough', 'stop'. In this case it is usually pronounced भो

### 3.10. Vocatives

Vocatives are also uninflected forms. They differ from interjections in that the vocatives, e.g. एइ,हे,ओइ may stand in construction with the nouns, e.g.ओइ गोपाल, हे इश्वर to form independent parenthetical minor sentence types. The forms सरकार!,सर! are also used as vocatives. Noun stems without inflectional or derivational suffixes (i.e. Nominative forms) also function as vocatives [7], as गोपाल!

### 3.11. Nuance particles

Nuance particles belong to a small closed set of uninflected forms, showing no characteristic lexical morphology and occur in a syntactically independent way in phrases and statements. They are characterized by their having no dependents. The nuance particles in Nepali are [7]: अरे, चाहि,है, कि, क्यारे, लौ,ना,नै,नि,पो,र, त .

### 3.11.1. Special Characteristics of Nuance particles

Below, we try to list down the characteristics of Nuance particles[6]:

i) Nepali possesses a number of particles, which are mostly monosyllabic words like पो, नि,है,त etc. The meaning given to these particles depends very much on the context in which they are used, and may often be rendered in English merely by a change of tone.

a) पो, usually precedes the main verb of the sentence and implies a contradiction of

something that has already been said. For example, if someone says त्यो होटेल राम्रो छ, 'that hotel is good', when you have found that it is not, you may contradict the statement by replying नराम्रो पो छ । 'it's not, I tell you'. The pitch on which पो is uttered is higher than that of the other words in the sentence. The sentence तपाई ब्राह्मण पो हुनुहुन्छ might be translated as 'Oh, I see you are a Brahmin (whereas I thought you were something else). Note that ब्राह्मण is a literary form of बाहुन 'a Brahmin'.)

b) The particle नि usually comes at the end of the sentence. In statements it implies that the information given is common knowledge and may be translated 'you know'.

In short interrogative phrases, it may be translated 'what about ...'

यो होटेल राम्रो छैन। त्यो होटेल नि।

c) The particle त, which never stands as the first word in the sentence, has a number of functions. One is to emphasize the word or phrase it follows.

When linking two sentences, त may be translated 'but' तपाईँ धनी हुनुहुन्छ, म त गरीब छु।

You are rich but I am poor.

होइन त? (Or simply होइन?), standing at the end of $\mathrm{a}$ sentence turns the statement into a question.

The affirmative answer to such a question is हो 'yes'.

त and पो may occur in the same sentence, giving emphasis to an assertion:

d) The particle है is interrogative, often used on polite requests.

ii) The particle नै emphasises the word it follows. It may often be translated 'only' when it follows a noun.

Most Nepali words have emphatic forms. They are formed thus:

1. When a word ends in a vowel, the final vowel is changed to ऐ thus:

$$
\begin{gathered}
\text { विहान -> विहानै } \\
\text { गर्नु -> गारने } \\
\text { म -> मै }
\end{gathered}
$$

2. When a word ends in a consonant, the syllable ऐ is added to the word:

$$
\begin{aligned}
& \text { घर -> घरै } \\
& \text { त्यस-> त्यसै } \\
& \text { सब-> सबै }
\end{aligned}
$$

Many emphatic forms have special or modified meanings, which cannot be explained simply in terms of emphasis. For eg.,

घरै 'at home', बिस्तारै 'slowly', एकाबिहानै 'early in the morning', बिहान बेलुकै 'morning and evening'.

The emphatic form मात्रैis used in preference to the ordinary form मात्र 'only'.

The particle नै, itself an emphatic form, adds further emphasis.

In some cases, the final consonant of a word may be doubled before the emphatic suffix ऐ. For example, निको 'good', 'well' निकै' 'extremely well', 'very much'.

iii) The particles न and त, following the imperative, have the effect of making the command less brusque. They may be rendered in English as 'won't you?', 'please' etc.

iv) The particle रे (always coming at the end of the sentence) indicates that the words which precede it are reported or that the information is at the second hand. It may be translated: 'they say that ...', 'he says that...', I hear that ...etc

### 3.12. Numerals

The numerals in Nepali may be divided into [7]:

1) cardinal adjectives or adjectivals,answering how many'
2) ordinal adjectives answering "which one of a series"
3) distributive adjectives answering how many each
4) ordinal adverbials answering which time of a series.

All the instances for all the four cases mentioned above is illustrated for number "1" in the table 19 below:

## Table 19. Four different numeral cases of the

 number "1"| Cardinal <br> adjectives | Ordinal <br> adjectives | Distributive <br> adjectives | Ordinal <br> adverbials |
| :--- | :--- | :--- | :--- |
| एक | पहिलो | एक-एक | एक पल्ट |

The numbers multiplied by ten are written in the following way:

1 एक

10 दश

100 सय

1,000 हजार

10,000 दश हजार

$1,00,000$ एक लाख

$10,00,000$ दश लाख

$1,00,00,000$ करोड

$10,00,00,000$ दश करोड $\qquad$
Note: The adverbial marker पल्ट has several dialectal variants: पटक,चोटी,ताली,बार

### 3.12.1. Special Characteristics of numerals

Here, we try to list down the special characteristics of numerals [6]:

i) All numerals take the classifiers -जना and -वटा For eg.

ii) The most important fractions are:

$$
\begin{aligned}
& \text { पाउ -> a quarter } \\
& \text { तिहाई -> a third } \\
& \text { आधा -> half }
\end{aligned}
$$

डेढ -> one and half अढाई ->two and a half

These function in the same way as other numerals:

The word रूपियाँ may also be written and pronounced रूपैया

iii) The words सवा 'plus one quarter', साढे, 'plus one half', पौंने 'less one quarter' are always followed by another numeral.

सवा चार ->'four plus one quarter' or four and a quarter साढे चार ->'four plus one half' or four and a half पौंने पाँच ->'five less one quarter' or four and three quarters

Occasionally साढे एक and साढे दुई are used in place of डेढ $\left(1 \frac{1}{2}\right)$ and अढाई ( $\left.2 \frac{1}{2}\right)$

In telling time, divisions of the hour are expressed as follows:

चार बजे at four o'clock

सवा चार बजे at a quarter past four

साढे चार बजे at half past four

पौंने पाँच बजे at a quarter to five

In other words, one says 'at four and a quarter o'clock' etc. Note in particular:

डेढ बजे or साढे एक बजे at half past one अढाई बजे or साढे दुई बजे at half past two

Minutes to and past the hour are expressed as follows:

$$
\begin{aligned}
& \text { चार बज्नलाई पाँच मिनेट बाँकी छ। } \\
& \text { It is five to four. } \\
& \text { बाह्न बज्नलाई पच्चीस मिनेट बाँकि हुँदा । }
\end{aligned}
$$

At twenty-five to twelve.

Note that बाँकी is an adjective meaning "left over, remaining":

iv) Some more points with regards to time:

a) ठीक with expressions of time means 'exactly, precisely' For eg.,

ठीक छ बजे at exactly six o'clock.

b) The adverbs बिहान 'in the morning', दिउँसो 'in the afternoon', भरे 'this evening', बेलुका 'in the early evening', राति 'at night' precede the expression of time: For eg.

### 3.13. Prefixes and suffixes

The prefixes precede the forms to which they are attached, e.g.बे,निर् अन् as in बेकारी, निर्दोष,अनपढ. The suffixes follow the forms to which they are attached, e.g. ली as in गोर्खाली. Prefixes and suffixes are not treated as separate class of forms since they are bound to one or other of the major form classes or parts of speech [7].

### 3.13.1. Special Characteristics of Nepali

 Prefixes and SuffixesHere, we list down the special characteristics of Nepali Prefixes and Suffixes [6]:

i) The suffix चाँहि may be added to adjectives, nouns and pronouns.

a) When added to adjectives, चाँहि has the effect of turning them

into nouns, and may usually be rendered into English as 'the ... one'


In the same way चाँहि may be added to the demonstrative and pronomial adjectives, and to a possessive formed with the postposition -को

b) When added to nouns and pronouns, चाँहि has the effect of emphasizing them and may be translated in English as 'as for', or simply by a change of tone.

Note the use of चाँहि in the following sentences:

Note that त्यत्ति is an adverb which modifies an adjective: त्यत्ति ठूलो 'so big', त्यत्ति राम्रो 'so nice'

ii) The suffix -होला instead of -होस् may be used to convey extra politeness.

iii) The days of the week

आइतबार Sunday

सोमबार Monday

मङ्लबबार Tuesday

```
बुधबार Wednesday
बिहिबार Thursday
शुकबार Friday
सञ्चरबार/शनिबार Saturday
```

The suffix -बार is often written वार. Note the expression: आज के बार? What day of the week is it today?

Three days have alternative literary forms, which are often used in newspapers and the other official contexts:

$$
\begin{aligned}
& \text { रविवार Sunday } \\
& \text { वृहस्पतिवार Thursday } \\
& \text { शनिवार Saturday }
\end{aligned}
$$

## 4. Nominal Structures

After having dealt with the form classes (lexicon) in considerable detail, we now move to the phrase structure of the Nepali Grammar. We start with nominal structures which includes the common-noun phrase, proper noun phrase, pronoun phrase and dependent nominials functioning as modifiers in large nominals.

### 4.1. Common-noun phrase

The internal structure of the common-noun phrase follows the following formula [7]:

Common-noun phrase (CNP) = Optional Determiner (Det.) + Optional Modifier (Mod.) + Obligatory Head

The structural formula of the CNP is illustrated by the following examples:

Det. + Mod. + Head

### 4.1.1. Common nouns as heads

The common nouns as heads have further internal structure as shown in the formula below:

Head $=$ Obligatory common noun stem + Optional plural marker हरू + Optional inflectional suffix for cases
This implies that the common noun head is either singular or plural and that the plural suffix is occurrent in the environment of some heads, nonoccurrent in that of other heads. The inflectional suffix is required to convey the semantic meaning, e.g.

## मानिस, मानिसहरू, मानिसहरूलाई

The common nouns ending in -o like डोको,बोको,छोरो etc. have their allomorphs ending in -a such as डोका,बोका,छोरा etc.

When they are followed by the optional plural marker, or by a case inflection, they follow the pattern as shown below in the table.

Table 20. Inflectional forms of common nouns ending in -o

| Singular | Plural | Inflectional <br> forms |
| :--- | :--- | :--- |
| डोको | डोका | डोकामा |
| बोको | बोका | बोकाले |
| छोरो | छोरा | छोरालाई |

### 4.1.2. Gender as nouns

Every noun (proper or common) in Nepali belongs to either masculine or feminine gender. Only these two genders (masculine and feminine) as reflected morphologically in the verbs, although traditional grammars talk about masculine, feminine, neuter and common genders [7].

In other words, the gender of nouns is indicated morphologically by the form of verbs, not by the form of nouns, e.g.

$$
\text { दुर्गा गयो(m) दुर्गा गई(f) लक्ष्मी गयो(m) लक्ष्मी गई(f) }
$$

Thus in the above case, दुर्गा and लक्ष्मी may be the names of both men or women and is distinguished only after looking at the form of the verbs they take.

Exceptions hold professional titles and persons belonging to a certain caste, in which case the males
and femailes would be differentiated by means of the derivational suffixes as shown in the table below:

## Table 21. Derivational suffixes applicable to males to form female titles

| Male | Female |
| :--- | :--- |
| घर्ती | घर्तिनी |
| नेवार | नेवार्नी |
| सार्की | सर्किनी |
| डाक्टर | डाक्टर्नी |
| चाकर | चाकर्नी |

### 4.1.3. Determiners in the CNP

The determiners in the CNP generally follow the linear order as presented below [7]:

a) demonstratives (pronomial adjectives);

b) limiters;

c) quantifiers which are the numerals (cardinal or ordinal);

d) Optional classifiers (human or non human).

Hence determiner has the following formula [7]:

Determiner $=$ Optional demonstratives + Optional limiters+ Optional quantifiers + Optional classifiers

Let us look at the following example:

$$
\text { यी+ मेरा+ चार+ जना +(साहै प्रिय मित्रहरू })
$$

These + my $+\mathrm{f}$ our + human + (very + dear + friends $)$

Demonstrative+ limiter+quantifier+classfier

### 4.1.3.1. Demonstratives

Demonstratives form a small closed subset of determiners which are inflected for number. They are (proximate): यो,यी,त्यो,ती

### 4.1.3.2. Limiters

Limiters are a closed set of forms which, as determiners follow the demonstratives in the liner order of occurrence. The limiters are either definite such as: हरेक 'each',प्रत्येक 'each' or indefinite such as:केही 'some',केवल 'only',एकै 'same',उही 'same',अरू 'other', कुनै'certain',अघिल्लो, 'first', पछिल्लो 'last',अन्तिम 'final',अलिकति 'a little', थौरै, 'a little',सबै 'all'.The nouns and pronouns in possessive forms also function as limiters.

### 4.1.3.3. Quantifiers (numbers) and classifiers

The quantifiers are cardinal numbers such as एक,दुई,तीन followed by one of the two classifiers (human classifier, non human classifier). The quantifiers followed by the classifiers distribute like adjectives when they stand in construction with the head nouns in the common-noun phrase.

The classifier जना occurs with countable human nouns; the classifier वटा occurs with countable non human nouns e.g.

Table 22. Classifiers जना and वटा

| human classifier | Non human classifier |
| :--- | :--- |
| पाँच जना मानिस | पाँच वटा कलम |

Note that the form of एक of non human classifier is एउटा. Other forms show two free variants each, e.g.

$$
\begin{gathered}
\text { दुई वटा दुइटा } \\
\ldots \ldots \ldots \ldots . . . . . . . . . \\
\text { दश वटा दशोटा }
\end{gathered}
$$

Classifiers do not occur with expressions of telling time or with nouns which denote periods of time, e.g. एक बजे; दश दिन

### 4.1.3.4. CNP's functioning as quantifying determiner

Noun-phrases denoting units of quantity or measure occur as quantifying determiners and are embedded CNP's in higher level CNP [7]. For instance,

Note that the common noun phrase (CNP) एक किलो occurs as a quantifying determiner to the higher level common noun phrase (CNP) राम्रो आलु .

### 4.1.3.5. Modifiers in the CNP

The modifiers in the CNP are expansions of the basic CNP structure. These expansions are dependent on a higher level CNP, e.g. दु:खको सागर 'ocean of pain'. A common-noun phrase stands in conjunction with optional modifiers. These optional modifiers are either nouns or noun phrases subsumed as 'nominals', adjectives or adjective phrases subsumed as 'adjectivals', postpositional phrases or clauses [7].

### 4.1.3.6. Nouns or noun phrases as modifiers in CNP

Nouns (common or proper) or noun phrases function as modifiers in the CNP when they cooccur with a common noun.In such constructions, the first noun is the modifier, and the final noun is the head of the CNP [7], e.g.

### 4.1.3.7. Adjectives or adjective phrases as modifiers

Adjectives as modifiers occur after the determiners and before the head of the CNP, e.g.

Besides the adjectives and the adjective phrases, dependent adjectivals also modify nouns and noun phrases [7].

### 4.1.3.8. Clauses as modifiers

The clauses that function as adjectives are dependent modifiers of the noun. For instance,

Here the clause सुभद्रा दुलही भएर आउँदाको modifies the item बखत.

### 4.2. Proper-noun phrase

The proper-noun phrase has the following internal structure [7]:

Proper-noun Phrase (PNP) $=$ Optional Modifier + Obligatory Proper noun head

The modifier is optional, and is filled by adjectives or adjectivals. The head is obligatory and is filled by the place and person names (person names are personal names given by parents).

Person and place names in Nepali do not cooccur with determiners (demonstratives, limiters, quantifiers), e.g.

Proper names as such are inherently determined as definite, and thus do not cooccur with any of the determiners that the common nouns cooccur with. However, the person names do occur with the modifiers (adjectives or adjectivals). The formula for PNP is exemplified by the following instances:

### 4.2.1. Person names as heads

When functioning as heads, person names consist of an obligatory person name with optional modifiers but without plural number. In other words a person name does not inflect for number since the person name is inherently singular as it refers to an individual (who has been given the name) is inherently singular. When the plural number suffix -हरू occurs with a person name, it does not stand as plural number marker; it stands for the other (unspecified) names
semantically associated with the person name with which it cooccurs [7].

For instance,

Person names, like common nouns, have a syntactic property of gender which is in one-to-one correspondence with the sex of the individual that is referred to by the name. The gender of the person names is reflected in the gender concord they have with the forms of verbs, e.g.

When the person names of masculine gender such as शारदा प्रसाद and दुर्गा प्रसाद are reduced as शारदा and दुर्गा , their gender is ambiguous as they can refer to females of the same names. Their gender is disambiguated by the finite form of the verb in the clausal structure.

Person names are chosen by the parents based on such factors as caste, position in the family, and sex of the child. So it may be sometimes possible to guess the caste of a person from the name if the person's first name is a typical one. However, there is not much rigidity in caste adherance in Nepal. Moreover, the names given to men and women cut across caste distinctions. So one cannot always be right in one's guess.

The family names indicate the caste of the person more accurately, though not infallibly. Some typical family names are:

- Brahmans: आचार्य 'Acharya',अधिकारी 'Adhikari',अर्याल 'Aryal'etc.
- Kshatriyas:

अधिकारी,'Adhikari',बस्नेत,'Basnet' ,भाट, 'Bhat' etc.

- Vaisyas: जोशी,'Joshi', श्रेष,'Shrestha' etc.
- Sudras: सुन्दास, 'Sundas', नेपाली, 'Nepali'

The Nepalese give their children two names, a first name, e.g. विश्वनाथ,तोयनाथ।

### 4.2.2. Place name as heads

Place names when functioning as heads consist of an obligatory place name. As with the person names, place names do not inflect for numbers as they refer to one geographical place name, as काठमाण्डौं, गौंरिघाट etc.

### 4.3. Pronoun Phrase

The pronoun phrase follows the following internal structure [7]:

Pronoun Phrase (ProP) $=$ Optional Modifier + Obligatory Pronoun Head

In certain instances, the optional modifier occurs after the head. This applies to a few personal pronouns. The plural number suffix -हरू occurs with तिमी,तिनी,वहाँ,तिमी. The plural number suffix -हरू occurs optionally with the pronoun हामी, which shows an alternative form हामीहरू.

### 4.3.1. Pronouns as heads

The pronouns (pro) constitute a small closed class and belong indirectly to the gender (masculine vs. feminine) of the nouns which they substitute, but are not inflected for gender. The gender of the pronouns is expresssed morphologically by the verbs with which they stand in syntactic construction. Compared to nouns, pronouns inflect more irregularly for case and number. Following are the personal pronouns and their honorific forms [7]:

Table 23. Personal Pronouns and their honorific forms

| Person | Singular | Plural |
| :---: | :---: | :---: |
| First | म | हामी(हरू) |
| Second |  |  |
| Level of respect |  |  |
| Low Grade <br> Honorific <br> (I $\mathrm{F}$ H $)$ | สँ | तिमीहरू |
| $\underset{m}{\operatorname{mid}} \underset{\ldots}{ }$ Grade |  | तिमीहरू |
|  | तिमी |  |
|  | तपाइँ |  |
| High Grade <br> Honorific <br> (HनH) |  |  |
| Third |  |  |
|  |  | उनीहरू, तिनीहरू |
|  | तिनी | तिनीहरू |
|  | वहाँ | वहाँहरू |

In formal conversation तपाई and तपाईहरू (second person $\mathrm{HGH})$ show variants यहाँ and यहाँहरू.

The Royal honorific used to refer to the king and his family सरकार is used as both second person and third person pronoun, and follows the regular pattern.

### 4.3.2. Modifiers in the pronoun phrase

Pronouns do not occur with the determiners (demonstratives, numerals and classifiers), but they do cooccur with certain modifiers [7].

The following modifiers precede the pronouns they stand in construction with:

$$
\text { केवल 'only', }
$$

## खाली 'only'

The following modifiers follow the pronouns they modify:

$$
\begin{aligned}
& \text { एक्लै 'alone' } \\
& \text { मान्रै 'only, alone' } \\
& \text { दुवै 'both' } \\
& \text { सबै 'all' } \\
& \text { आफैं 'oneself' }
\end{aligned}
$$

### 4.4. Dependent nominals functioning as modifiers in larger nominals

Dependent nominals function as modifiers in larger CNPs. These dependent nominals are divided into four subgroups [7]:

i) characterizing modifiers;

ii) appositive modifiers;

iii) genitive modifiers;

iv) delimiting modifiers.

The order of the functional constituents of the larger nominals with dependent nominals as modifiers is presented in the following formula:

Larger Common Noun Phrase (CNP) = Modifier + obligatory head (dependent nominals)

The modifiers could be the following [7]:

i) The characteristic modifiers are adjectives, adjectival phrase or adjectival clauses.

ii) The appositive modifiers are nouns .

iii) The genitive modifiers are marked by the genitive case forms of nouns and pronouns.

iv) The delimiting modifiers are pronomial adjectives. When they occur independently in a syntactic structure, they occur like pronouns (with anaphoric reference), inflecting for cases, and distribute as complements or adjuncts of the verbs. But when they occur in the CNP structures they function as modifiers as they stand in construction with the nouns (heads).

### 4.4.1. Characterizing modifiers

Characterizing modifiers, that is modifiers describing the head(noun), are formally different from other modifiers. The characterizing modifiers are adjectivals, or participial forms of verbs with their complements [7]. For instance,

$$
\begin{aligned}
& \text { गाउँले + छिमेकीहरू } \\
& \text { village+ neighbours }
\end{aligned}
$$


### 4.4.2. Appositive modifiers

Appositive modifiers occur in noun phrases which are double-headed constructions consisting of two or more heads, all obligatory, filled by two or more juxtaposed noun phrases which show the same case. This may be represented as follows:

Appositive Modifiers $=$ Obligatory Head:NP+Obligatory Head:NP

Although structurally apposition consists of no more than the simple juxtaposition of two noun phrases each filling a head, the noun phrase in the second head serves to identify more completely the noun phrase filling the first, e.g.

### 4.4.3. Genitive Modifiers

Genitive modifiers are marked by the genitive case suffix -को of nouns, or genitive cases of pronouns; as मेरो,हाम्रो,तिम्रो,आफ्नो.Thus the genitive case of nouns and pronouns represents the adjectival use of nouns and pronouns [7], e.g.

## सुभद्राको कोख <br> देवीरमनको जित <br> उनको अभिमान

The genitive case markers -को,-रो,नो show their allomorphs (variants of minimal grammatical units) का,रा,ना when the genitive modifiers modify the nouns in plural number, or nouns in oblique cases, e.g.

## सन्तानका आशाले <br> देवीरमणका आँखा

Since the genitive modifiers function as adjectives, they show inflections not just for number but also for gender. For instance, the genitive case markers को,रो,नो show their allomorphs -की,री,नी when they stand in construction with the nouns of feminine gender:

$$
\begin{aligned}
& \text { घरकी पुरानी चाकर्नी } \\
& \text { सुभद्राकी सुखदु:खकी साथी }
\end{aligned}
$$

### 4.4.4. Delimiting Modifiers

The difference between the characterizing modifiers and the delimiting modifiers is that the characterizing modifiers are adjectives, adjective phrases, clauses. The delimiting modifiers are only pronomial adjectives in nominal case [7], e.g.

## 5. Adjectival Structure

### 5.1. The Adjective Phrase

The internal structure of the adjective phrase is as follows [7]:

Adjective Phrase (AdjP)=Optional Modifier+ Obligatory Head (Adjective) Eg.

$$
\begin{gathered}
\text { बहुत + पतिपरायणा } \\
\text { very +loyal (to husband) } \\
\text { झन् भयङ्र } \\
\text { more + dreadful } \\
\text { साहै नराम्रो } \\
\text { very +bad } \\
\text { केही शान्त } \\
\text { somewhat + pacified } \\
\text { एकदम साफ } \\
\text { very+clean }
\end{gathered}
$$

### 5.2. Adjectives as heads

Within the internal structure of the adjective phrase, an obligatory adjective occurs as the head, e.g.

$$
\begin{aligned}
& \text { राम्रो'handsome' } \\
& \text { अग्लो'tall' } \\
& \text { होचो'short' } \\
& \text { कड्गाल'poor' } \\
& \text { बिरामी'sick' } \\
& \text { असल'good' }
\end{aligned}
$$

Adjectives ending in -o which occur in the head reflect the gender and number of the noun with which they stand in construction. In other words, they simply manifest those morphological changes to mark the syntactic relationship to the gender of nouns with which they stand in construction with, e.g.

The Nepali adjectives which end in -o show inflected 'evaluative' forms ending in -अइ which show an evaluative degree of quality. These evaluative forms are not allomorphs but are similar to the syntactic comparative and superlative forms. Then an evaluative connotation 'fairly' or 'more or less' is added to the meaning of such adjectives, e.g.

$$
\text { ठुलो 'big' ठुलै 'fairly big' }
$$

सानो 'small' सानै 'fairly small' होचो 'short 'होचै 'fairly short' अग्लो 'tall' अग्लै 'fairly tall' मोटो 'fat' मोटै 'fairly fat'

The adjective सब, although not ending in -o, also shows an inflection for its evaluative form ending in अइ which adds to its meaning the connotation 'fairly' or 'more or less'. For instance, सब 'all' -सबै 'more or less all' [7].

### 5.3. Quantifiers in the AdjP

Quantifiers in the AdjP are divided into four categories [7]:

1) adverbs of quantity;
2) comparative quantifier phrases;
3) superlative quantifier phrases;
4) elative superlative quantifier.

### 5.3.1. Adverbs of quantity

The adverbs of quantity are the following [7]:

अझ more', अलिक 'somewhat', अलिकति 'a little', धैरै

'many',केही some,somewhat',बहुत 'very',ज्यादै

'very',साहै 'extremely'

These adverbs of quantity function as quantifying determiners in the CNP, e.g.

अझ गाह्रो काम ' more difficult task'

अलिक फरक कागज 'somewhat different paper' अलिकति लामो बाटो 'a little long way'

बहुत पतिपरायणा रमणी 'a very loyal wife'

धैरै नराम्रो खबर 'very bad news'

ज्यादै धेरै पैसा 'very much money' केही राम्रो परिणाम 'a somewhat better result' साहै नराम्रो रोग 'an extremely bad disease'

### 5.3.2. Comparative quantifier phrases

Comparative quantifier phrases are divided into two groups [7]:

i) comparatives with भन्दा;

ii) comparatives with झन,अझ.

### 5.3.3. Comparative with भन्दा

Comparative quantifier phrases with भन्दा consist of two obligatory nominals, i.e. common noun, proper noun, pronoun, plus a comparative degree quantifier भन्दा and a head filled by an adjective. The order of these obligatory constituents is shown in the formula $[7]:$

CompP-भन्दा = Obligatory nominal +Obligatory comparative भन्दा +Obligatory nominal +Obligatory head(adj)

### 5.3.3.1. Comparative adjective phrase with झन

Comparative quantifier adjective phrases with झन consist of an obligatory nominal, the comparative झन, and an obligatory head slot filled by an adjective. Unlike comparatives with भन्दा, comparatives with झन do not consist of more than one nominal in the clause. Thus, झन is anaphoric to the nominal of the proceeding clause. The order of the constituents is shown in the following formula:

Comp-झन=Obligatory nominal+Obligatory

comparative (झन)+Obligatory head

### 5.3.4. Superlative quantifier phrases

Superlative quantifier phrases with सब भन्दा consist of an obligatory subject, the superlative सब भन्दा and an adjective head. The order of the constituents is shown in the formula [7]:

SupP-सब भन्दा=Obligatory subject+Obligatory superlative(सब भन्दा)+Obligatory complement

$$
\text { सगरमाथा सब भन्दा अग्लो पहाड हो। }
$$

The order of the constituents of the superlative quantifier phrases indicates a statistical order (the most frequent order). However, the position of the subject is changeable. This is illustrated by the following example:

### 5.3.5. Elative superlative quantifier

The elative superlative quantifier सबै भन्दा is used in expressions with more emphatic connotations than the superlative quantifiers express [7], e.g.

## 6. Dependent adjectivals functioning as modifiers within CNPs

The dependent adjectivals modify the CNPs. The internal structures CNP with the dependent adjectivals as modifiers is present in the following formula [7]

CNP(with DepAdjls)=Obligatory Modifier + Obligatory Head

Dependent adjectivals are derived from verbal adjectives (participles).The participles are divided into two subclasses: (1) imperfect participle marked by the suffix -ने (2)perfect participle marked by the suffix एको. The imperfect participle marked by the suffix -ने, functioning as a dependent adjectival is not inflected for tense, person,number, gender and aspect. The
perfect participle marked by the derivational suffix एको is not inflected for tense and person, but it is inflected for number, and gender, e.g.

Table 24. Perfect Participle and the derivational suffix-एको

| Singular |  | Plural |  |
| :--- | :--- | :--- | :--- |
| Masculine | Feminine | Masculine | Feminine |
| -एको | एकी | -एका | -एका |

In the cases where the mode (nonprogressive vs. progressive) is marked, the imperfect participial suffixes -ने, and perfect participial suffix -एको follow the progressive mode marker -इरह- The nonprogressive mode is unmarked, e.g.

Table 25. Progressive and Nonprogressive modes

| Nonprogressive <br> mode |  | Progressive mode |  |
| :---: | :---: | :---: | :---: |
| Imperfect <br> participle | Perfect <br> participle | Imperfect <br> participle | Perfect <br> participle |
| नने | - <br> एको(male <br> singular) | -इरहने | -इरहेको <br> (male <br> singular) |
| -ने | - <br> एकी(fema <br> le <br> singular) | -इरहने | -इरहेकी <br> (female <br> singular) |
| -ने | -एका (pl.) | -इरहने | -इरहेका <br> (plural) |

The internal structure of all participles consists of the stem of the verb, and with the addition of one of the participial suffixes, i.e. -ने or एको.

### 6.1. The imperfect participle -ने as modifier.

The dependent adjectivals characterizing the head (noun) with the imperfect participle -ने consist of an obligatory derived verbal adjective, that is a verb with imperfect participle -ने, and an obligatory head (noun) [7].
CNP(with DepAdjl)-ने= Obligatory derived verbal adjective: verb with imperfect participle -ने + Obligatory head (noun)

Table 26: Adjectivals formed from the imperfect participle -ने, modifying nouns in the CNP structures.

| Verb stems | Imperfect <br> participle <br> (-ने) | Head (noun) |  |
| :--- | :--- | :--- | :--- |
| खा | खाने | कुरा | खाने कुरा |
| जानु | जाने | मान्छे | जाने मान्छे |
| लेख़्रु | लेखे | कलम | लेखे कलम |
| पढ्नु | पढ्ने | किताब | पढ्ने किताब |

Dependent adjectivals with the imperfect participle -ने may cooccur with the obligatory direct object(+DO), if the verb (in the imperfect participial form) is a transitive verb, and the head filled by a noun. The order of the functional constituents of the CNP with dependent adjectivals is shown in the formula [7]:

CNP (with DepAdjl-ने) = Obligatory direct object+Predicate: transitive verb - imperfect participial form (-ने)+ Head: common noun

The formula is illustrated by the following example:

## दुलही अन्माउने बेला

Adjectivals formed from the perfect participle -ने frequently occur in Nepali.

Table 27. Adjectivals formed from the perfect participle -ने

| Direct <br> Object | Verbs in <br> Imperfect <br> participle -ने | Head noun <br> modified <br> by the DepAdjl |
| :---: | :---: | :---: |
| दुलही | अन्माउने | वेला |
| दु:ख | पोखे्रे | भाँडो |


| Direct <br> Object | Verbs in <br> Imperfect <br> participle -ने | Head noun <br> modified <br> by DepAdjl |
| :---: | :---: | :---: |
| परेवालाई | पक्रने | कोशिश |
| तीर्थ | गर्ने | इच्छा |
| काम | गर्ने | मान्छे |

### 6.2. The perfect participle -ने as modifier

Dependent adjectivals marked with -एको which characterize the head noun consist of an obligatory past participle -एको and an obligatory head.

Table 28. Perfect participle -एको marking the dependent adjectivals modifying the head noun.

| Verb stems | Perfect participle | Head noun |
| :---: | :---: | :---: |
|  | -एको |  |
| सुत् | सुतिरहेको | कोठा |
| सोध् | सोधेको | प्रश्न |
| देख् | देखेको | कुरा |

Dependent adjectivals with the perfect participle एको may cooccur with an optional complement, the predicate filled by a verb (marked by the perfect participial suffix -एको), and the head filled by a noun. The order of the functional constituents of the CNP with dependent adjectivals is shown in the following formula [7]:

## $\operatorname{CNP}$ (with DepAdjl-एको) $=\quad$ Obligatory Modifier(Complement)+Predicate:verb-एको+ Head: common noun

The complement, an optional element, can be a noun in instrumental case, dative case,ablative case,locative case, or any noun phrase or postpositional phrase filling the same functional slot, i.e. complement. For instance,

Instrumental complement:

## तपाईले भनेको खबर

Dative complement:

## उसलाई दिएको पैसा

Ablative complement:

$$
\text { अमेरिकाबाट आएको चिठी }
$$

Locative complement:

## लण्डनमा भेटेको मान्छे

## 7. Adverbial Structures

The internal structure of adverb phrase (AdvP) is as follows [7]:

Adverbial Phrase (AdvP)= Optional Complement + Optional Modifier+ Head (Adverb)

The following adverbial phrase shows that the optional complement is realized in it:

### 7.1. Simple adverbs

Simple adverbs act as the head in an adverb phrase and are divided into two categories [7]: (1) derived adverbs, and (2) nonderived adverbs.

### 7.1.1. Derived adverbs

The derived adverbs are grouped into three subclasses:

i) adverbs ending in -अरी;

ii) adverbs ending in -साथ;

iii) adverbs ending in -पूर्वक;

The derived adverbs consist of a stem (adjective, adverb or noun) and one of the following suffixes: -अरी, -साथ, and -पूर्वक. The suffix -अरी occurs with the Nepali stems; the suffix -साथ occurs with stems borrowed from Hindi; and the suffix -पूर्वक occurs with stem borrowed from Sanskrit.

Adverbs ending in -अरी

Adverbs ending in -अरी in a manner are derived from Nepali adjectives, and Nepali adverbs. The underlying linear order consists of an adjective stem, or an adjective stem, or an adverb stem plus the adverb suffix -अरी in a certain way or manner,i.e.

Table 29 (a). Adjective Stem

| Nepali Adjective stem | Derived adverbs <br> in -अरी |
| :---: | :---: |
| राम्रो | राम्ररी |
| बेस | बेसरी |
| सुस्त | सुस्तरी |

Table 29. Adverbs ending in -अरी

| Nepali Adverb stem | Derived adverbs in -अरी |
| :---: | :---: |
| कसो | कसरी |
| जसो | जसरी |
| त्यसो | त्यसरी |

Adverbs ending in -साथ

Adverbs ending in -साथ are derived from Hindi adjective or nouns. The underlying linear order consists of a Hindi adjective or noun stem plus the adverb suffix -साथ,e.g.

Table 30. Adverbs ending in -साथ

| Hindi noun, <br> adj-stems | Derived adverbs in - <br> साथ |
| :---: | :---: |
| खुशी | खुशीसाथ |
| दिकदारी | दिकदारीसाथ |
| फूर्ति | फूर्तिसाथ |

Adverbs ending in पूर्वक
Adverbs ending in -पूर्वक are derived form nouns. Adverbs ending in -पूर्वक are of Sanskrit origin. The underlying linear order consists of a Sanskrit noun stem plus the adverb suffix -पूर्वक,e.g.

Table 31. Adverbs ending in-पूर्वक

| Sanskrit noun <br> stems | Derived adverbs in - <br> पूर्वक |
| :---: | :---: |
| उत्साह | उत्साहपूर्वक |
| आनन्द | आनन्दपूर्वक |
| धैर्य | धैर्यपूर्वक |

### 7.1.2. Nonderived adverbs

Nonderived adverbs are adverbials since they do not show the derivational suffixes that characterize the adverbs. The adverbials are distinguished from the adverbs only on the basis of their forms (morphology). In terms of the distribution, the adverbials fill the same functional slots as the adverbs do.

Table 32. Adverbials of most frequent occurrence

| अब'from now on' | अबेला'late' |
| :---: | :---: |
| अहिले 'now, at this <br> time' | आज 'today' |
| अघि 'before, <br> previously' | आफूखुशी 'voluntarily' |
| अहिले 'now' | अकस्मात 'suddenly' |
| आखिर 'finally' | अलि 'a little' |
| अत्यन्त 'extremely' | अहिल्यै 'right now' |
| बारबार 'frequently' | भोलि 'tomorrow' |
| भएपनि 'although' | बहुत 'very' |
| भरखर 'recently' | बाहिर 'outside' |
| वित्तिकै 'as soon as' | चाँडै 'soon, quickly' |
| एक्लै 'alone' | चटकै 'completely' |
| एकदम 'completely' | जहाँ 'where' |


| अब'from now on' | अबेला 'late' |
| :---: | :---: |
| जहिले 'when' | झण्डै 'almost' |
| जसरी 'in which way' | जता 'which way' |
| कहाँ 'where?' | कहिले 'when?' |
| कसरी 'in which <br> way?' | कता 'which way, <br> whither?' |
| केही 'somewhat' | किन 'why?' |
| परस्पर 'mutually' | मात्र'only' |
| नजिकै 'near' | पछि, 'afterwards' |
| पछिल्तिर 'behind' | फेरि 'again' |
| पनि 'also' | पिलपिल 'atwinkle' |
| सबेरै 'early' | साहै 'very' |
| सदैव 'always' | सम्म 'only' |
| तलतिर 'downward' | त्यहाँ 'there' |
| त्यसरी 'in that way' | त्यता 'there, on that <br> side' |
| उहिले 'then' | उता 'on that side' |
| व्यर्थै 'unnecessarily' | यहाँ 'here' |
| यस्तरी 'in such a way' | यता 'here, on this side' |

### 7.1.3. Interrogatives, relators and demonstratives

Among the nonderived adverbs, some of them are substitute forms. These substitute forms are grouped into three subclasses: interrogatives, relators, and demonstratives which are correlative forms. In other words, the demonstrative adverbials answer the questions posed by the interrogatives. For instance, the question कहाँ, is answered by त्यहाँ or यहाँ or कहिले is answered by उहिले or अहिले, कसरी is answered by त्यसरी or यसरी [7].
Table 33. Interrogatives, relatives and demonstratives

| K- <br> Interrogatives | J-Relatives | D-Demonstratives |
| :---: | :---: | :---: |
| कहाँ 'where?' | जहाँ 'where' | त्यहाँ,यहाँ 'there', 'here' |
| कहिले 'when?' | जहिले 'when' | उहिले,अहिले, 'then', <br> 'now' |
| कसरी 'how?' | जसरी 'which way' <br> क्यसरी, यसरी ,'that way', <br> 'this way" |  |
| कता 'which |  |  |
| way?' | जता 'which way' | त्यता,यता 'that way' 'this <br> way' |

### 7.1.4. Compound adverbials

Compound adverbials are combinations of two adverbials. The fact that they are compound adverbials is indicated by the hyphen (-) in their transcrtibed form although there is no hyphen in their Devanagari orthography [7], e.g.

मास्तिर 'upward'

मुन्तिर 'downward'

विचविचमा 'intermittently'

The traditional Nepali grammars call the second element in such compound adverbial postpositions, comparable to prepositions in the English language. When they occur alone, they are called compound adverbials, or adverb phrases (AdvP), i.e. as fillers of the optional adverbials adjunct (AA:) in the clausal structres, e.g.

## 8. The adverbial postpositional noun phrase

Postpositions are equivalent to prepositions in English. The postpositional phrase consists of a noun or a noun phrase (NP) acting as obligatory complement $(+\mathrm{C}:)$ and a postposition( $\mathrm{pp})$ filling the obligatory head $(+\mathrm{H}$ :) slot. The internal structure of the postpositional phrase (PP) is as follows [7]:

Postposition(PP) $=$ Obligatory

Complement:+Obligatory head (postposition):

The formula is illustrated in the following instance,

### 8.1. Postposition and its complements (Nps)

A postposition filling the obligatory head of the postpositional phrase (PP) stands in construction with the noun phrase ( $\mathrm{Nps}$ ) filling the optional complement slot. Some of the postpositions, e.g. अघि or पछि, which may occur alone filling an optional adverbial complement or adjunct slot in a clausal structure may also occur as nonderived adverbials [7].

The forms अघि and पछि, which may occur with clausal constructions are classified as subordinating conjunctions. They are homophonous forms which belong to different classes (subordinating conjunctions, postpositions, or adverbials).

Table 34. A list of Nepali postpositions

| अनुसार 'according <br> to' | बाबजुद 'in spite of' |
| :---: | :---: |
| बदला 'instead' | बाहेक 'except' |
| बाहिर 'outside' | बमोजिम 'according <br> to' |
| भर (भरा) <br> 'throughout' | भरी 'all over, in full' <br> भित्र 'inside, in, into' देखि 'since' |
| जस्तै 'like' | जस्तो 'like' |


| अनुसार 'according <br> to' | बाबजुद 'in spite of' |
| :---: | :---: |
| झैं 'like' | द्वारा 'by' |
| कहाँ 'in, at <br> (location)' | मध्ये 'among' |
| मनि 'under' | माथि 'on,above,over' |
| मुनि 'under' | नजिक 'near' |
| नजिकै 'very near' | नेर 'near' |
| निमित्त 'for the sake <br> of' | निम्ति 'for, for the <br> sake of' |
| पछि, 'after' | पछाडि 'behind' |
| पारि 'across (a river <br> or road)' | पट्टि (on the side of) |
| सँग 'with' | सम्म 'up to' |
| सामुन्ने 'right in <br> front' | सामु 'in front of' |
| सित 'with' | तल 'below, under' |
| तिर 'toward' | बारे 'about' |
| बिना 'without' | विरुद्ध 'against' |
| वारि 'on the closer <br> of two sides' | वारिपारि 'around' |

### 8.2. Postpositions occurring with the NPs in genitive case

A small group of postpositions which belong to this group occur with the complements (NPs) in genitive case. These postpositions occur with the NPs in genitive case only if the NPs refer to human beings. They do not occur with NPs in genitive case if the NPs refer to non human beings [7].

The following are examples of these postpositions cooccurring with complements (NPs) only in the genitive case:

अगाडि 'in front of' मेरो अगाडि नबस

'Do not sit in front of me.'

बावजुद 'in spite of' त्यसका बावजुद

'In spite of that'

निमित्त ' for the sake of' सन्तानका निमित्त

'for the sake of offspring'

निम्ति 'for' मेरो निम्ति यो गर।

'Do it for me please'

पछाडि 'behind' घरको पछाडि रूख छ।

'There is a tree behind the house.'

सामुन्ने

'right in front'

घरको सामुन्ने पोखरी छ।

'There is a pond right in front of the house.'

सामु

'in front of

## Postpositions occurring with morphologically unmarked forms of the NPs.

The following is a list of postpositions occurring with the morphologically unmarked forms of nouns or noun phrases (Nps) [7]:

Table 35. Postpositions occurring with the morphologically unmarked forms of nouns or noun phrases (NPs):

| कहाँ 'in, at location' | बाहिर 'outside' |
| :--- | :--- |
| बाहेक 'except' | भर 'throughout' |
| बमोजिम 'according to' | भित्र 'inside, in, into' |
| भरी 'all over, in full' | जस्तो 'like' |
| देखि 'since' | द्वारा 'by' |
| झैं 'like' | मध्ये 'among' |


| कहाँ 'in, at location' | बाहिर'outside' |
| :--- | :--- |
| मनि 'under' | माथि 'on, above, over' |
| मुनि 'under' | नजिक 'near' |
| नजिकै 'very near' | नेर 'near' |
| निर 'near' | पारि 'across ( a river or road)' |
| पछि, 'after' | पट्टि 'on the side of' |
| सँग 'with' | सम्म 'up to' |
| सित 'with' | तल 'below, under' |
| तिर 'toward' | बारे 'about' |
| विना 'without' | वारि 'on the closer of two sides' |
| वारिपारी 'around' |  |
| अनुसार 'according to' |  |

## 9. Conjunctions: Coordinate and subordinate

Conjunctions serve as the connector function, and conjoin two or more structures (words, phrases, or clauses). Conjunctions are of two types: coordinating conjunctions conjoining any two equal structures, and subordinating conjunctions conjoining unequal structures, e.g. a clause dependent on a word, phrase, or clause. The structures conjoined by conjunctions are called conjunctive structures (CX). The internal structure of the coordinating conjunctive structures $(\mathrm{CoCX})$ is presented in the following formula [7]:

$\mathrm{CoCX}=$ Obligatory Head: Optional Head : Optional Head: ... Optional Head: +Obligatory Connector : +Obligatory Head:

The items which fill the head preceding and following the connector may be words, phrases, clauses, or sentences. The preceding and the following heads need not both be of the same filler class but both always fill the same functional slots.

### 9.1. Coordinating conjunctions

The coordinating conjunctions conjoin any two equal structures: words, phrases, clauses or sentences.

Nepali coordinating conjunctions are presented alphabetically below.

Table 36. Coordinating conjunctions and the element they conjoin

| Coordinating <br> conjunctions | Words | Phrases | Clauses |
| :---: | :---: | :---: | :---: |
| अनि | - | - | + |
| अथवा | + | + | + |
| कि | + | + | + |
| कि ...कि | + | + | + |
| किन्तु | - | - | + |
| न ... न | + | + | + |
| नकि | - | - | + |
| परन्तु | - | - | + |
| र | + | + | + |
| तैपनि or यद्यापि <br> ..तैपनि | - | - | + |
| तर | - | - | + |
| तथा | + | + | - |
| वा | + | + | - |
| या | + | + | - |

The figure above indicates what elements are conjoined by which coordinating conjunctions. The coordinating conjunctions अनि, नकि, परन्तु, तैपनि, तर conjoin only clauses and sentences. The coordinating conjunctions अथवा, कि and र conjoin words, phrases and clauses. Following are examples of coordinating conjunctions in use:

A clause, occurring with the co-ordinating conjunction तैपनि 'even then', stands in construction with the preceding clause which is redundantly and optionally marked by यद्यपि which is glossed as 'although' and wrongly treated as subordinating conjunction by traditional grammars of Nepali. However, the following illustration proves that यद्यपि is not a subordinating conjunction and that it only redundantly marks the first of the two co-ordinate clauses connected by the coordinating conjunction तैपनि 'even then'।

### 9.2. Subordinating conjunctions

The subordinating conjunctions अघि 'before' , अगाडि 'before', भने 'if', पछि 'after', and पनि 'although' occur at the end of the subordinate clause. The subordinate clauses marked by these subordinating conjunctions occur before the principal clause.

Subordinating conjunctions कि 'that' and किनकि 'because' occur at the beginning of the subordinate clause. The subordinate clause marked by these subordinating conjunctions occur after the principal clause [7].

The following are illustrations of the subordinating conjunctions in context:

The subordinating conjunction अगाडि 'before' also distributes the same way as अघि 'before'.

As an exception to the formula for the subordinate clause in Nepali, the subordinating conjunction यदि 'if' (borrowed from Sanskrit) occurs at the beginning of the subordinate clause, and such a clause also occurs before the principal clause. However, such a clause is also marked according to the normal structure of the Nepali subordinate clause by भने 'if' thus making यदि optional and redundant.

## 10. Interjections, vocatives, and nuance particles

The Nepali Interjections, vocatives and nuance particles are uninflected, small, closed sets of forms which show no inflections, dependents, or lexical morphology. Interjections are syntactically free, and function as minor sentences, semantically complete but structurally reduced.

Vocatives like interjections, are syntactically free, and can be treated as interjections, representing minor sentences. Vocatives are, however, treated as different from interjections only on the basis that they can also occur in vocative phrasal constructions.

Nuance particles are also uninflected, and a small, closed set of forms. They are characterized by their having no dependents, show no characteristic lexical morphology, and occur in a syntactically independent way in phrases or sentences as optional elements and add to the meaning of a phrase or statement with which they cooccur [7].

### 10.1. Interjections

Interjections constitute a small closed class of independent particles. They function as minor sentences, semantically complete but structurally reduced. Thus, interjections are syntactically complete, and independent of any other element in phrasal, or
clausal structures. The most frequent interjections in Nepali are [7]:

```
अँ (approval)
                    अहँ (disapproval)
                    ओहो (great surprise)
                    अबुइ (fear)
धत्तेरी (frustration)
                    धत् (indignation)
जाँ (regret for forgetfulness)
                    लाँ (vindication)
लौं खा (greater vindication)
                    आचे (surprise)
                    अहाँ(pleasure)
                    ए (pleasure)
                ऐया (pain)
छि: (disapproval/disgust)
                        धत्तेरीका (frustration)
                    ला (Here you go)
लौं (surprise, vindication)
```


### 10.2. Vocatives

Vocatives, like interjections, are marked by the absence of inflection, dependents, and lexical morphology. The vocatives are attention drawers. The Nepali vocatives are: ए, आइ, हे, ओ, ओइ.The vocatives are similar to interjections as they occur alone and are syntactically free. The vocatives are slightly different from interjections as they may also occur with nouns in unmarked case, and may be constituents of a vocative phrase as: ए गोपाल, 'Hey Gopal!'. However, even in such instances it can still be argued that vocatives are not different from the interjections they still function like interjections (as minor sentences) [7].

### 10.3. Nuance particles

Nuance particles belong to a small closed set of uninflected forms, show no characteristic lexical morphology, and occur as syntactically dependent upon phrases or statements, but are characterized by their having no dependents of their own. The nuance particles in Nepali are [7]:
अरे 'they say so' (in reporting speech) है 'okey'

क्यारे 'probably, I guess (noncommital)'

न 'simply'

नि 'and how about (question)'

र 'in confirmation questions'

चाँहि 'this, that particular one'

कि 'expression of doubt'

लाउ 'granted that...'

नै really (emphatic particle)

पो'emphatic'

त (rather)

Certain nuance particles occur only in phrases, others occur in certain types of statements. So in terms of their distribution, the nuance particles are grouped as phrasal nuance particles and statement nuance particles.

Table 37. Phrasal and Statement nuance particles

| Nuance particles | Phrase | Statement <br> $\mathrm{s}$ | Types |
| :---: | :---: | :---: | :---: |
| अरे, रे | - | + | Declarative |
| चाँहि | + | - |  |
| है | - | + | Declarative, <br> Imperactive <br> , Question |
| कि | - | + | Question |
| क्यारे | - | + | Declarative |
| लाउ | - | + | Declarative |
| न | + | + | Imperative |
| नै | + | - |  |
| नि | - | + | Question |
| पो | + | - |  |
| र | - | + | Question |
| त | + | + | Imperative, |


| Nuance particles | Phrase | Statement <br> s | Types |
| :---: | :---: | :---: | :---: |
|  |  |  | Question |

### 10.3.1. Phrasal nuance particles

As evident from the above, certain nuance particles occur only with phrases, while others occur in different types of sentences (declarative, interrogative and imperative). Those nuance particles which occur only with the phrases are phrasal nuance particles [7].

The phrasal nuance particles are: चाँहि, नै and पो ।

The nuance particle त occurs in a phrase as well as question and imperative statements, e.g.

In the phrase:

## मलाई त

'For me in particular'

In a question statement तपाइंलाई गोर्खा कस्तो लाग्यो त?

'How did you like Gorkha?'

In an imperative statement:

### 10.3.2. Statement nuance particles

Those nuance particles that occur only with statements are statement nuance perticles. They are: अरे, है, कि, क्यारे, न,नि and र । These statement nuance particles are subdivided as imperative statements, nuance particles, declarative statement nuance particles, and question statement nuance particles [7].
10.3.2.1. Imperative statement nuance particles

The only nuance particle occurring in an imperative statement is न. The following example illustrates its use [7]:

10.3.2.2. Declarative statement nuance particles

The declarative statement nuance particle is क्यारे. The following example illustrates its use [7]:

10.3.2.3. Question statement nuance particles

The question statement nuance particles are: कि, नि, and र .They are exemplified in the following instances [7]:

Question statements:

The nuance particle है cooccurs with all the three types of statements: declarative, imperative, and question statements, e.g.

In a declarative statement है adds the nuance of warning:

In an imperative statement है adds to the nuance of emphasis:

In an imperative statement with first person singular, है changes the statement into a question:

The nuance particle न occurs in the phrases as well as in statements, e.g.

When the nuance particle नcooccurs with a statement, it cooccurs only with an imperative statement.

## 11. Verbal Structure

The internal structure of the verb phrase (VP) is as follows [7]:

Verb-nonfinite $=$ Optional negative (न-

...इकन)+Obligatory stem verb+Optional causative+Obligatory voice+Obligatory aspect

Verb Phrase-finite=Optional Prefix (Optional negative न-)+Obligatory stem verb+Optional causative+ Obligatory voice+ Obligatory mode+ Obligatory aspect + Obligatory Auxiliary suffixes( Obligatory person + Obligatory number + Obligatory gender+ tense (Optional negative -न-)

The nonfinite forms are:

i) infinitives marked by the infinitive suffix नor -नु; ii) participles marked by the suffixes -एको, -ने, -दै,-तै,-एर,-इ,-इकन;

iii) conditionals marked by the suffix -ए

## Infinitive forms:

जान or जानु 'to go'

खान or खानु 'to eat'

गर्न or गर्नु 'to do'

## Participial forms:

गरेको - (perfect participle) 'done'

गर्ने -(imperfect participle) 'doing'

गारैे (conjunctive participle) 'doing'

गरेर (absolutive participle) having done'

गरिकन '(absolutive participle) having done

## Conditional forms

गए 'if go'

खाए 'if eat'

गरे 'if do'

The verb stems in Nepali are grouped, into three types:

i) 1'st Conjugation;

ii) 2'nd Conjugation;

iii) 3'rd Conjugation.

## 1'st Conjugation type:

Verbs with bases which end in consonants. The bases of these verbs have only one form. For instance: गर- 'do', बस -'sit', दगुर -'run'.

## 2'nd Conjugation type:

Verbs with bases which end in the following vowels: -इ and आ, with a single exception of जा-'go'. The bases of these verbs have only one form. For instance, दि-give, लि-take, खा-eat, बिर्सी-forget.

## 3'rd Conjugation type:

Verbs with bases which end in the following vowels: आउ, अ,उ, and आ in the single case of जा -'go'. These bases have two variant forms which are known as primary and secondary

Table 38. Conjugate types of verbs.

| 1'st <br> Conjuga <br> tion | 2'nd <br> Conjugation | 3'rd <br> Conjugation |  |
| :---: | :---: | :---: | :---: |
|  |  | Primary | Secondary |
| गर -'do' | खा -'eat' | आउ 'come' | आ- |
| बस- 'sit' | ला -'take away' | पाउ 'get' | पा- |
| देख -'see' | दि -'give' | पठाउ -'send' | पठा- |
| सुन- 'hear' | लि -'take' | धु -'wash' | धो- |
| भन - 'say' | उभी -'stand' | रू - 'weep' | रो- |
| दगुर -'run' | बिर्सी-'forget' | दुहु -'milk' | दुह- |
| खस - | उम्ली -'boil' <br> 'drop' | जा 'go' | ग- |

### 11.1. Verbs as heads

The simple finite verb forms are the heads of the verb phrases. Thus the verb as a grammatical word may be represented as [7]:

Verb $=$ Optional Prefix + Obligatory Stem Verb + Optional Causative + Obligatory Voice + Obligatory Mode + Obligatory Aspect + Obligatory Suffix

The finite forms of the verbs are inflected for the following categories: causative, voice, mode, aspect, tense, person, gender and number. The verb shows whether it is a noncausative form (unmarked) or causative (marked by the suffix -आउ). The verb also shows one of the two voices, active (unmarked) vs. passive (marked by the suffix -इ), e.g. गर -'do' vs. गरी - 'be done'. If the non-causative stem is considered as a normal consonantal $\mathrm{C}$ stem, the causative form can be called the A stem. Likewise, if the active (unmarked) stem can be considered normal consonantal C stem, the passive form can be called the I stem because the इ is suffixed to the normal stem to make it a passive stem. Thus, the causative and the passive forms can be regarded as parts of the stem, and they can be grouped as A stems and I stems respectively, e.g.

Table 39. Verb stems

| C stem | A stems |  | I stem |
| :---: | :---: | :---: | :---: |
|  | Primary | Secondary |  |
| गर् | गराउ | गर | गरी |
| बस् | बसाउ | बस | बसी |
| देख् | देखाउ | देख | देखी |

The verb shows one of the two modes: nonprogressive (unmarked) vs. progressive (marked by the -इरह-) and one of two aspects: nonperfect (unmarked) vs. perfect (marked by -एको). The verb also shows person, number, tense and gender (at least in third person singular) by a portmanteau suffix (one morpheme which simultaneously represents many categories, e.g. person, number, tense and gender).

The verbs shows one of the three persons (first, second or third), one of the two numbers (singular vs. plural), one of the two genders (masculine vs. feminine), in the third person singular, and one of the three tenses (past, present or future). The past tense is further divided into simple past, habitual past, and unknown past. The unknown past refers to an activity once unknown to the speaker. The future tense is further divided into future definite and future nondefinite. The future definite indicates stronger probability than the future indefinite.

### 11.2. Auxiliary verbs in the Verb Phrase

The auxiliary verbs in Nepali are: पर्नु 'should,must', हुनु 'be' and सक्नु ' can, may'. Auxiliary verb पर्नु 'should,must' is inflected for tense, but uninflected for aspect, person, number or gender [7], e.g.

पई्छ (present) 'should, must'

पर्यो (simple past) 'had to'

पर्थ्यो (habitual past) 'had to'

परेछ (unknown past) 'had to'

पर्ला (future) 'will have to'

The auxiliary verbs हुनु 'be' and सक्नु 'can, may' are inflected for aspect, person, nymber and gender.

With the auxiliary हुनु 'be' the head of the Verb Phrase carries the perfect participial suffix -एको, which inflects like an adjective for gender, and number, e.g. -एको (masculine singular), -एकी (feminine singular), and -एका (plural).

With the auxiliary सक्नु 'can,may' and पर्नु 'should,must' the head of the verb phrase is in the infinitive form.

### 11.3. The negative verb forms

The negative verb forms are formed at the morphological level and the morpheme न- is prefixed (to the imperative, infinitive, conditional, and participial forms), or is suffixed (to the verb stems elsewhere) [7].

### 11.3.1. The negative prefix न-

The negator न- 'not' is prefixed to imperative, infinitive, conditional, and participial forms, e.g.

## Imperative:

## Infinitive:

## Conditional forms:

Participial forms:

नगरेको '(perfect participle) not done'
नगर्ने '(imperfect participle) not doing'

नग रैे ' (conjunctive participle) not doing'

नगरेर '(absolutive participle) having not done without doing'

नगरी '(absolutive participle) having not done, without doing'

नगरीकन '(absolutive participle) having not done, without doing'

### 11.3.2. The negative suffix -न-

The negative -न- is suffixed to the verb stem elsewhere, e.g.

In the third person plural forms the negative -न- is followed by the third person plural suffixes.

### 11.4. Verbs which require the obligatory fronting of the dative complement

Verbs which require the fronting of the dative complements (nouns, noun phrases, pronouns, or pronoun phrases in dative case) belong to the class of $\mathrm{d}$-secondary verbs. The following is a list of the most frequently occurring $\mathrm{d}$-secondary verbs which require the obligatory fronting of the dative complement [7]:

### 11.5. Modifiers in the Verb Phrase

Modifiers in the verb phrase are either adverbs (adv), adverbial phrases (AdvP), or postpositional phrases (PP) [7], e.g.

## Adverb:

## Adverbial Phrase:

## Postpositional phrases (PP)

Nepali has relatively few modal verbs as compared to English. The English modals 'will' and 'shall' are expressed through the Nepali future tense. The English modal 'would' is expressed through the Nepali habitual past tense. The English modal 'might' is expressed through the Nepali nondefinite future tense.

## 12. Clausal Structures

The internal structure of the clause may be represented by the following formula [7]:

Clause $(\mathrm{Cl})=$ Optional Adverbial Disjunct+ Optional Exclamation + Optional Connector+ Optional Subject+ Optional Instrumental Adjunct+ Optional Locative Adjunct+ Optional Ablative Adjunct+ Optional Adverbial Adjunct+ Obligatory Locative Complement+ Obligatory Dative Complement+ Obligatory Direct Object+ Obligatory Subject Complement+ Obligatory Object Complement+ Obligatory Predicate+ Optional Nuance Particle

The clauses in which the verb phrases occur may be categorized as: i) transitive;

A clause and its verb may be characterised as 'transitive' if the verb cooccurs with the direct object.

ii) Equational;

A clause and its verb may be characterised as 'equational' if the verb cooccurs with a subject complement.

iii) Intransitive;

A clause and its verb is characterised as 'intransitive' if the verb cooccurs without a direct object and without a subject complement.

Each of these three types of clauses and verbs may be further subcategorized according to other obligatory complements which cooccur in the clause.

The constituents which are obligtaory to the clause are:

i) predicate;

ii) obligatory complements of the predicate.

### 12.1. Verbals as predicates

The nucleus of a clause is a verb phrase which is either a finite or nonfinite form (infinitive, participle, conditional). The verb phrase is either a simple verb phrase or a complex verb phrase (main verb plus auxiliary).

### 12.2. Subjects in the clause

In Nepali the verb which fills the nuclear predicate of a finite clause is marked for the person and number of the Subject. Further specification of the subject by the occurrence of a niminal in the nominative cases is optional. If the subject is further specified, the form or forms which fill the optional Subject are nominal forms in nominative case, e.g. Nouns, pronouns, nominalized adjectives, noun clauses, etc. which show a cross reference tie to the verb in person, number and gender

### 12.3. Complements in the clause

The complement functions in a clause are: direct object (DO), object complement(OC), subject complement (SC), dative complement (DC) and
locative complement (LC). These functions are filled by nouns and pronouns in different cases, adjectives in nominative and accusative cases, and phrases (AdjPs, NPs and PPs).

### 12.3.1. Transitive verbs and their complements

All transitive verbs occur with an obligatory direct object. The transitive verbs are subcategorized as folows on the basis of other obligatory complements they take besides the direct object :

i) transitive verb-1;

ii) transitive verb-2;

iii) transitive verb-3;

iv) transitive verb-4.

### 11.3.1.1. Transitive-1 verbs

Transitive-1 verbs are verbs which occur with an obligatory direct object. Direct objects which are animate are marked by the accusative case marker लाई. Objects which are not animate are not marked by the accusative case marker -लाई, i.e. The nominative and accusative cases of nonanimate nominals are identical in both the singular and plural. The constituents of the clause with the transitive-1 verbs are:

Optional Subject:+ Obligatory Direct Object:accusative + Obligatory Predicate: transitive verb-1

### 12.3.1.1. Transitive-2 verbs

Transitive-2 verbs are verbs which occur with an obligatory dative complement besides an obligatory direct object complement. The dative complement of a transitive-2 verb is marked by the dative case marker -लाई while the direct object of the transitive-2 verb is not so marked. The constituents of the clause with the transitive- 2 verb are:[^1]

### 12.3.1.2. Transitive-3 verbs

Transitive-3 verbs are verbs which occur with an obligatory direct object in accusative case and an obligatory object complement in the accusative case. The constituents of the clause with the transitive-3 verb are:

Optional Subject: + Obligatory Direct Object:accusative+Obligatory Object Complement:accusative+Obligatory Predicate:Transitive-3 verb

### 12.3.1.3. Transitive-4 verbs

Transitive-4 verbs are verbs which occur with an obligatory direct object and an obligatory locative complement. The constituents of the clause with the transitive-4 verb are [7]:

Optional Subject:+Obligatory $\quad$ Direct
Object+Obligatory locative
Transitive-4 verb

### 12.3.2. The equational verbs

The equational verbs (i.e. verbs which cooccur with 'subject complement' (SC) in Nepali are हुनु 'be', देखिनु 'appear, seem', and लाग्नु 'feel'. The equational verb-1 हुनु 'be' has two forms:
i) the identificational 'हुनु';

ii) the existential हुनु

The equational verb-2 has two members: देखिनु and लाग्नु

### 12.3.2.1. Identificational हुनु 'be'

The function of the identificational हुनु is to identify the subject.

### 12.3.2.2. The existential हुनु 'be'

The function of the existential हुनु is to indicate the existence of the subject or locate it.

### 12.3.2.3. <br> The equational verbs-2 देखिनु and

लाग्नु 'appear'

The equational verbs देखिनु and लाग्नु occur with an obligatory subject complement plus an obligatory direct complement.

## देविरमणलाई कोठा नौंलो लाग्यो।

The room appeared strange to Deviraman.

### 12.3.3. Intransitive verbs and their complements

Intransitive verbs are verbs which do not stand in construction with a Direct Object or a Subject Complement. Nepali has three types of instransitive verbs [7]:

i) Intransitive-1 verbs

ii) Intransitive -2 verbs

iii) Intransitive -3 verbs

## Intransitive-1 verbs

Intransitive-1 verbs are verbs which occur with no complements.

## Intransitive-2 verbs

Intransitive-2 verbs are verbs which occur with an obligatory dative complement, e.g.


## Intransitive-3 verbs

Intransitive-3 verbs are verbs which occur with an obligatory locative complement.

### 12.4. Subject-predicate linking by personnumber-gender-honorific level inflection

The subject and the predicate of a clause are linked by person, number, gender, and honorific level inflection of the verb in the third person singular. The categories person, number, gender, tense, and honorific level are shown only in finite forms of the verbs. In nonfinite clauses these categories are not reflected.

### 12.5. Optional adverbial adjuncts

The clausal structure (transitive, equational, or intransitive) may also cooccur with one or more optional adverbial adjuncts, namely instrumental adjunct (IA), locative adjuncts (LA), ablative adjuncts $(\mathrm{AbA})$ or adverbial adjunct (AA).

Following are the examples of each of these optional adverbial adjuncts:

## Instrumental adjuncts

## Locative adjuncts

## Ablative adjuncts

## Adverbial adjuncts

### 12.6. Other optional elements

The other optional elements in clausal structure are [7]:

i) adverbial disjuncts;

ii) exclamations;

iii) connectors;

iv) subjects.

### 12.6.1. $\quad$ Adverbial disjuncts (AD)

The adverbial disjunct consists of an adverbial clause which is marked by the verb with absolutive participial suffixes -इ, -एर, -इकन, imperfect participial suffix -दा or the conditional form suffix -ए followed by subordinate conjunctions यदि 'if' and पनि 'although'. For eg.,

### 12.6.2. Exclamations

The optional function of the exclamation is filled by the interjections and the vocatives. For eg.,

### 12.6.3. Connectors

The optional connector function is filled by either coordinate conjunctions or subordinate conjunctions. For eg.,

### 12.6.4. The Subjects

The functional slot of the subject filled by nouns, noun phrases, pronouns, or noun clauses is optional. The subject is optional because it is marked in the finite form of the verbs.

For eg.,

In the above example, the form हुन्थे in mid level honorific indicates that the subject referred to by it is a third person, singular, masculine gender. Hence the subject is not necessary to explicitly mention.

## 13. Special type of clauses

Special type of clauses include [7]:

i) passive clauses;

ii) imperative clauses

iii) question clauses;

### 13.1. Passive Clauses

In Nepali the passive clause has a passive form of a verb which is marked by the derivational suffix -इ-. For instance,

Table 40. Active and Passive Stems and forms

| Active <br> stem | Active form | Passive stem | Passive <br> form |
| :---: | :---: | :---: | :---: |
| छेक् - छेक्छ, 'he blocks' | छेकी | छेकिन्छ |  |


| Active <br> stem | Active form | Passive stem | Passive <br> form |
| :---: | :---: | :---: | :---: |
| 'block' |  |  | 'is <br> blocked' |
| पा- 'get' | पाउँछ 'he gets' | पाइ | पाइन्छ, 'is <br> gotten' |
| पुछ् - <br> 'wipe' | पुछछ 'he wipes' | पुछी | पुछिन्छ 'is <br> wiped' |

When the passive form of a verb is used in a passive clause, the object of the verb in active clause occurs as subject; and the number, gender, person of the noun or pronoun filling the subject function slot are shown syntactically in the third person by their reference tie to the verbs, e.g.

Table 41. Active and Passive clauses

| Passive clause | Active clause |
| :---: | :---: |
| स्वर्गको बाटो छेकिन्छ। | स्वर्गको बाटो <br> छेक्छ। । |
| फलेफूलेको देखर्न पाइयोस व | फलेफूलेको देखर्न <br> पाओस口 |
| उनको आँसु पुछिने थियो । | उनको आसु पुछ्ने <br> थियो। |

### 13.2. Imperative clauses

The imperative clauses are marked by the imperative form of the verb with its complements. The imperative form of the verb inflects for the following four levels of honorifics. For instance,

गर, गरेस् 'do (LGH)'

गर 'please do (MGH)'

गर्नोस् 'please do(HGH)'

गरिबक्स्योस् 'please do (Royal Honorific')

### 13.3. Question clauses

The question clauses in Nepali are of two types:

i) K-question clauses;

ii) हो-होइन question clauses.

### 13.3.1. K-question clauses

A K-question clause has a word which begins with a ' $k$ ' and asks an information question. The following is a list of common information questions.

को 'who?' के 'what?'

कहाँ 'where?' किन 'Why?'

कसरी 'how?' के 'what?'

कहिले 'when?'

कति 'how much, how many?'

कस्तो 'what kind?'

### 13.3.2. Ho/hoina question clauses

Ho/hoina questions are so called because the answer to these questions is either हो 'yes' or होइन 'no'. The ho-hoina question clauses are divided into two categories: ho/hoina questions with question intonation, and ho/hoina questions with हगि.

### 13.3.2.1. हो/होइन question with question intonation

The ho/hoina question has the same grammatical or syntactic structure as the declarative sentence, but is differentiated by the shift in intonation, e.g.

13.3.2.2. Ho/Hoina question with the tag हगि

The ho/hoina question with the tag हगि has the same structural description as the declarative clause. The tag हगि, 'wouldn't it, isn't it, aren't you, etc', occurs in the final position in the sentence, and makes the clause a question clause, e.g.

## 14. Finite Dependent clauses : Nominal, adjectival, and adverbial

A finite clause has a finite form of verb filling the predicate slot. A finite dependent that fills the object slot or subject slot in the principal clause is a finite dependent noun clause; a finite dependent clause that fills the modifier slot in the principal clause is a finite dependent adjective clause; and a finite dependent clause that fills the adverbial adjunct slot in the principal clause is a finite dependent adverbial clause [7].

### 14.1. Finite dependent noun clause

The dependent noun clause functions either as an object or subject to the verb in the principal clause like a noun or noun phrase except that this is a clausal structure.

Dependent noun clause functioning as object to the verb in the principal clause has a finite verb in it. The verb in the principal clause is a transitive verb. The dependent noun clause functioning as object to the transitive verb in the principal clause is connected to the principal clause by कि भनेर, or quotation marks in written Nepali, e.g.

In Nepali a dependent noun clause functioning as subject to the verb in principal clause has a verb only in nonfinite (infinitive) form, and is, therefore ,a nonfinite clause

### 14.2. Finite dependent adjective clause

The finite dependent clause functioning as an adjective clause fills the modifier slot in the sentence and modifies the noun or noun phrase in the principal clause: such a dependent adjectival clause has a finite verb or verb phrase at its nucleus. The dependent clause is marked by the J-class substitute forms, e.g. जो 'who', जसलाई 'whom' जसले 'who', जसबाट 'from whom', जसको 'whose',जुन 'which', जहाँ 'where' and जहिले 'when'.

Finite dependent adverbial clause with भने 'if, किनकि or किन भने 'because'. Finite dependent adverbial clauses with भने 'if' किनकि or किनभने 'because' fill the slot of adverbial adjunct in the principal clause, e.g.

### 14.3. Finite dependent adverbial clause with भने' 'if', किनकि, किन भने,'because'

Finite dependent adverbial clauses with भने'if', किनकि, किन भने,'because' fill the slot of adverbial adjunct in the principal clause.

For eg.

## 15. Nonfinite dependent clauses: Infinitive, participial, and conditional

Nonfinite dependent clauses are of three types [7]:

i) nonfinite dependent noun clause;
ii) nonfinite dependent adverbial clause with a verb in either infinitive form -नु , न plus ले, or perfect participial form -एको plus ले,or imperfective participial form -ने plus ले functioning as adverbial adjuncts;

iii) nonfinite dependent adverbial clause with a verb in conditional form functioning as adverbial adjuncts.

### 15.1. Nonfinite dependent noun clause with a verb in infinitive form

A dependent noun clause that fills the subject slot in the principal clause in Nepali has a verb only in nonfinite (infinitive) form. Such a noun clause functioning as subject is connected to the principal clause by भन्तु or भनेको, e.g.

### 15.2. Nonfinite dependent adverbial clause as adverbial adjunct.

Adverbial clauses fill the functional slot of adverbial adjunct to the principal clause. Such dependent adverbial clauses are marked with the perfective participial form -एको plus -ले or imperfective participial fom -ने, plus -ले, or imperfective participial forms or infinitive forms -नु, -न of a verb plus -ले 'because', e.g.

The verb phrase consisting of a particular -एको and auxiliary हुनु in its infinitive हुना with the suffix -ले also marks a dependent adverbial clause, functioning as an adverbial adjunct, e.g.

### 15.3. Nonfinite dependent adverbial clause with a verb phrase in conditional form

The dependent clause with conditional form occurs in a simple verb, or a verb phrase form marked either by the conditional suffix -ए to a simple verb stem or complex verb stem, or by a verb phrase with the main verb in perfective form marked by the perfective aspect suffix -एको, imperfective form suffix -ने , or infinitive form marked by -नु, or ना and the auxiliary verbs in conditional form in the dependent clause.

Verb phrase with the main verb in perfective participial form marked by -एको and auxiliary verbs in conditional form:

Verb phrase with the main verb in imperfective aspect marked by -ने and auxiliary verbs in conditional form:

Verb phrase with the main verb in infinitive form marked by -नु and auxiliary verbs in conditional form:

Nonfinite dependent clauses with negative conditional form is connected to the principal clause by subordinate conjunction पनि or पछि which follows the verb (in conditional form, or absolutive participial form) in the dependent clause.

Note:

In Nepali the dependent clause may not precede the principal clause as it does in English, e.g.

The subordinate conjunction पनि 'although' should not be confused with the homophonous पनि 'also' which is an adverbial.

## 16. Dependent clauses in expression of comparision

Dependent clauses in expressions of comparision represent basically two degrees of comparision: comparative degree and superlative degree. Thus, the expressions of comparisions are subdivided into two types: Comparisions of inequality and Comparisions of equality $[7]$

### 16.1. Comparisions of inequality

Comparisions of inequality are structurally divided into two types: Symmetrical comparision and Asymmetrical comparision. Both types of comparisions consist of the comparative quantifiers अझ, भन्दा and झन in comparisions of two items.

The quantifier सबभन्दा, or its variant सबै भन्दा 'more than all' occurs in the superlative degree of comparision (comparing one item against many other items in symmetrical comparisions)

### 16.1.1. Symmetrical comparisions

In symmetrical comparisions one item is decribed as exceeding, or falling short of, another item with respect to some specified property or behavior. In such comparisions, there are two clauses (one is reduced to the form of a phrase). The first is the principal clause, the second is the reduced dependent clause. The constituents of the two clauses perform identical functions within their respective clauses. The constituents being compared with each other may be subjects, objects, complements, or predicates [7].

i) Comparision of subjects

ii) Comparision of objects:

iii) Comparision of subject complements:

iv) Comparision of predicates

Superlative degree comparision has the same structural pattern as the comparatie degree comparision in Nepali. The superlative degree comparision is marked by सबैभन्दा or सबै भन्दा 'than all'

### 16.1.2. Assymmetrical comparisions

In the assymetrical comparisions the compared item in the principal clause does not have anything overt to compare with. The compared item is said just to exceed the extent expected, apparent,understood. Such assymmmetrical comparisions are marked by अझ and झन् 'further'.

### 16.2. Comparisions of equality

The quantifiers जति 'as much', उति 'as much as that (remote)', त्यति 'as much as that (proximate)' occur in the comparisons of equality.

### 16.2.1. Comparisions of subjects

### 16.2.2. Comparisions of subject complement

### 16.2.3. Comparision of objects:

### 16.2.4. Comparision of dative complement

### 16.2.5. Comparision of locative elements

### 16.2.6. . Comparision of predicates

## 17. The Sentence as a speech act

Traditional grammars distinguish four types of sentences [7]:

i) declarative;

ii) interrogative; iii) imperative;

iv) exclamatory.

However, a sentence such as 'Can you open the door?' traditionally described as interrogative, is an imperative statement in terms of its function. So the assignment of the sentences to the various categories in question depends on the function of the sentence at a higher level - discourse level where utterances are simply considered as 'speech acts'. And it is the speech act, as a unit of discourse, that either

(1) makes a statement requiring no speech act in response,

(2) asks a question requesting another speech act in response, or

(3) issue a request or order expecting compilance in a word (speech act) or deed (other act)

It is in correlation with these various pragmatic functions that the sentence as speech act possesses certain formal properties.

Nepali sentences as speech acts can be divided into two main categories on formal basis:

(1) direct speech acts, which are unmarked and

(2) indirect speech acts, marked by lexical items: रे, अरे, and भनेर; in such indirect speech acts the speaker reports the speech of another speaker.

Sentence as speech acts also have structure pragmatically reduced to a mere word or phrase, called elliptical sentences.

### 17.1. Direct speech act

The direct speech acts are speech acts in which the speaker makes his own statements as opposed to reporting the speech act of someone else, including mainly four types of sentences [7]:

(1) declarative speech acts;

(2) interrogative speech acts;

(3) imperative speech acts (Commands);

(4) exclamatory speech acts. For instance,

## Declarative speech acts (Statements)

## Interrogative speech acts (Questions):

## Exclamatory speech acts (Exclamation)

### 17.2. Indirect speech acts

Indirect speech act is the act of reporting what a third person has said. There are two ways of reporting speech in Nepali [7]:

i) Using the particle रे or अरे 'is said,they say';

ii) Using the absolutive participle भनेर 'having said'.

### 17.2.1. Indirect speech acts with रे or अरे

The nuance particle अरे or रे occurs at the end of the statement to signify information that is received indirectly about a subject. It carries the meaning of 'I hear that...' or 'They say ...',e.g.

### 17.2.2. Indirect speech act with भनेर

The most frequent way to report a speech in Nepali is to use the absolutive participle भनेर ('having said'). The use of भनेर is divided into two ways [7]:

(1) Reporting the actual speech, and

(2) Reporting the intention.

17.2.2.1

Reporting the actual speech act
The absolutive participle form भनेर of the verb भन्तु 'say' is employed to report the words actually uttered by the speaker. The reporter does not change the words of the speaker. So the written Nepali texts present the reported speech in quotation marks, e.g.

### 17.2.2.2 $\quad$ Reporting the intention

The absolutive participle भनेर is also employed in the speech act to report the intention of the speaker. The words reported by means of भनेर in such sentences are not the actual speech acts of the person being reported about, but the speech acts of the reporter who translates in his own words the intention of the person. The fact that only the intention is reported is also reflected in written Nepali where the reported intention is not put within the quotation marks, e.g.

### 17.3. Elliptical sentences as declarative speech acts

Reduced sentential structures are elliptical sentences which lack either the subject and objects, or the predicate. Such sentences as declarative speech acts are complete semantically because the redundant element in them is deleted since these elements are anaphoric to a prior sentence.

### 17.3.1. Reduced sentences with elliptical subject and object

Reduced sentences with elliptical subject and object consist of a verb phrase which is a repetition of the verb form of the question. e.g.

## Full sentence:

## Reduced sentence with elliptical subject and object:

### 17.3.2. Reduced sentences with elliptical predicate

In speech acts of declarative statements made as short answers to the questions asked to the speaker the predicate may be elliptical in Nepali. When the predicate becomes elliptical, the optional element is obligatory [7]. Consider the following conversation for instance.

Table 42. Interrogative and Declarative Speech Act

| Interrogative speech <br> act (Question) | Declarative speech act <br> (Answers) |
| :---: | :---: |
| को सँग आइस्? | रातमाटे भण्डारीका |
| Who did you come | जहानसँग |
| with? | With Ratmate Bhandari <br> Pandit's family. |
| कैले जान्छेस्? | भोलि बिहानै |
| When will you go? | Tomorrow morning |

## 18. Conclusion

This report does not in any sense capture all the aspects of the Nepali Grammar structure. Furthermore, the findings of the study presented might be subjected to changes and corrections as well as newer concepts and ideologies emerge. However, this report can serve as a strong base document for further research. The findings are but sure to serve as an invaluable source for the development of the grammar checker and other Natural Language Applications for Nepali.

## 19. Reference

[1] http://iris.lib.virginia.edu/tibet/education/nepali/in dex.html

[2] "THDL: Nepali Language" http://www.thdl.org/education/nepali/

[3] "Nepali alphabet, pronunciation and Language" http://www.omniglot.com/writing/nepali.htm
[4] Hutt, M. and Subedi, A. Teach Yourself Nepali Complete Course, McGraw-Hill; 2 edition (October 16, 2003)

[5] Karki, T. B. and Shrestha, C.K Basic Course in Spoken Nepal, Open Support Service Center Press, 1992

[6] Mathew, D. A Course in Nepali, RatnaPustak Bhandar, 1998

[7] Acharya, J. A Descriptive Grammar of Nepali and an Analyzed Corpus, Georgetown University Press, 1991


[^0]:    1 यहाँ and वहाँ are occasionally used in place of तपाईँ to address a second person, in which case, of course, they would be translated 'you' in English. This usage is felt to be extra polite.

[^1]:    Optional Subject+Obligatory Dative Complement+ Obligatory Direct Object+ Obligatory Predicate:transitive-2 verb

