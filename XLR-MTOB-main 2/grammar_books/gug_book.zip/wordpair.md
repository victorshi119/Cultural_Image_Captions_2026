सँग    with
गाएँ    village
संग     with
गाऊँ    village
गाउं    village
अङ्क    number
अंक    number
अञ्चल    zone
अंचल    zone
द+ि+द + ी दिदी    Elder sister
प्राय:    usually or mostly
दु:ख    pain
राजा    king(sing.)
राजाहरू    kings(pl.)
यो    this
त्यो    that
मेरो    my
तिम्रो    timro
हाम्रो    our
राम्रो    pleasing to the eye
राम्रो    beautiful
मीठो    good to the taste
असल    of good quality
असल    morally good
सब    all
सब    every
कहाँ    where?
के    what?
को    Who?
कुन    Which?
तपाईकी    of you, your
खानु    to eat
जानु    to go
दिनु    to give
उभिनु    to stand
धुनु    to wash
रूनु    to weep
बिर्सनु    to forget
दुहुनु    to milk
आउनु    to come
पठाउनु    to send
पिउनु    to drink
भन्नु    to say
सुन्तु    to hear
देख्रु    to see
गर    do
बस्    sit down
खा    eat
उभि    stand
धो    wash
पठा    send
पि    drink
आ    come
दुही    milk
बिर्सिई    forget
सम्झी    remember
गर्नुहोस्    do
बस्नुहोस्    sit
आउनुहोस्    come
सजिलैसँग    with ease, easily
कहिले    when?
कहिले कहीं    sometimes
कतै    somewhere
कसरी    how?, by what means?
कस्तो    how?, of how quality?, in what state
जस्तो    like, such as
केही    anything
निश्चितता    Certainty
घरै    at home
बिस्तारै    slowly
एकाबिहानै    early in the morning
बिहान बेलुकै    morning and evening
निको    good, wwell
निकै    extremely well, very much
एक    1
दश    10
सय    100
हजार    1,000
दश हजार    10,000
एक लाख    1,00,000
दश लाख    10,00,000
करोड    1,00,00,000
दश करोड    10,00,00,000
आइतबार    Sunday
सोमबार    Monday
मङ्लबबार    Tuesday
बुधबार    Wednesday
बिहिबार    Thursday
शुकबार    Friday
सञ्चरबार/शनिबार    Saturday
केवल    only
खाली    only
एक्लै    alone
मान्रै    only, alone
दुवै    both
सबै    all
आफैं    oneself
राम्रो    handsome
अग्लो    tall
होचो    short
कड्गाल    poor
बिरामी    sick
असल    good
अब    from now on
अबेला    late
अहिले    now, at this time
आज    today
अघि    before, previously
आफूखुशी    voluntarily
अहिले    now
अकस्मात    suddenly
आखिर    finally
अलि    a little
अत्यन्त    extremely
अहिल्यै    right now
बारबार    frequently
भोलि    tomorrow
भएपनि    although
बहुत    very
भरखर    recently
बाहिर    outside
वित्तिकै    as soon as
चाँडै    soon, quickly
चटकै    completely
एकदम    completely
जहाँ    where
जहिले    when
झण्डै    almost
जसरी    in which way
जता    which way
कसरी    in which way?
कता    which waym whither?
केही    somewhat
किन    why?
परस्पर    mutually
मात्र    only
नजिकै    near
पछि    afterwards
पछिल्तिर    behind
फेरि    again
पनि    also
पिलपिल    atwinkle
सबेरै    early
साहै    very
सदैव    always
सम्म    only
तलतिर    downward
त्यहाँ    there
त्यसरी    in that way
त्यता    there, on that side
उहिले    then
उता    on that side
व्यर्थै    unnecessarily
यहाँ    here
यस्तरी    in such a way
यता    here, on this side
त्यहाँ,यहाँ    there, here
उहिले,अहिले    then, now
कसरी    how?
जसरी    which way
क्यसरी, यसरी    that way, this way
कता    which way?
त्यता,यता    that way, this way
विचविचमा    intermittently
मास्तिर    upward
मुन्तिर    downward
कहाँ    in, at location
बाहेक    except
भर    throughout
बमोजिम    according to
भित्र    inside, in, into
भरी    all over, in full
जस्तो    like
देखि    since
द्वारा    by
झैं    like
मध्ये    among
मनि    under
माथि    on, above, over
नजिक    near
नजिकै    very near
नेर    near
निर    near
पारि    across (a river or road)
पछि    after
पट्टि    on the side of
सम्म    up to
सित    with
तल    below, under
तिर    toward
बारे    about
विना    without
वारि    on the closer of two sides
वारिपारी    around
अनुसार    according to
जान    to go
खान    to eat
गर्न    to do
गर्नु    to do
गरेको    (perfect participle) done
गर्ने    (imperfect participle) doing
गारैे    (conjunctive participle) doing
गरेर    (absolutive participle) having done
गरिकन    (absolutive participle) having done
गए    if go
खाए    if eat
गरे    if do
आउ    come
बस    sit
ला    take away
पाउ    get
देख    see
दि    give
पठाउ    send
सुन    hear
लि    take
धु    wash
भन    say
उभी    stand
रू    weep
दगुर    run
बिर्सी    forget
दुहु    milk
उम्ली    boil
जा    go
गरी    be done
पई्छ    (present) should, must
पर्यो    (simple past) had to
पर्थ्यो    (habitual past) had to
परेछ    (unknown past) had to
पर्ला    will have to
हुनु    be
सक्नु    can, may
पर्नु    should, must
न-    not
देखिनु    appear, seem
लाग्नु    feel
लाग्नु    appear
यदि    if
पनि    although
गर    do (LGH)
गरेस्    do (LGH)
गर    please do (MGH)
गर्नोस्    please do(HGH)
गरिबक्स्योस्    please do (Royal Honorific)
को    who?
किन    Why?
कति    how much, how many?
कस्तो    what kind?
हो    yes
होइन    no
जो    who
जसलाई    whom
जसले    who
जसबाट    from whom
जसको    whose
जुन    which
भने    if
किनकि    because
किन भने    because
सबै भन्दा    more than all
जति    as much
उति    as much as that (remote)
त्यति    as much as that (proximate)
रे    is said, they say
अरे    is said, they say
भनेर    having said
