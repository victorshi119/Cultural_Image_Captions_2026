[Dong] tidak panggil kau.
Mereka di sana petik alpukat.
Hari minggu Unyil pu bapak dong su pulang.
Saya sendiri duduk di sana.
Pi di laut, ada komo di laut.
Saya punya dada sakit.
Saya ambil tali keranjang.
Mereka su pulang di Halmahera.
Anak itu minum susu ibunya sampai tidur.
Dia pu mama pu ujung susu sakit.
Mereka bikin kebun di Kambur.
Mustafa pu bapak bakar kebun di Kamberar.
Dia itu melahirkan di rumah sakit.
Saya pi pancing di jembatan.
Saya punya rica habis.
Saya sendiri belum ambil, dorang su ambil.
Gunung Banda meletus.
Ciput batu laga kecil banyak.
Saya suruh dorang bikin saya punya pintu.
Saya punya anting-anting sudah pata.
Dorang hela ikan lima ekor, ikan merah lima ekor.
Dorang menyelam udang di Baki Tanggeun.
Saya cuci piring terlalu bunyi.
Kau usir ayam dulu!
Kita kikis pepaya pu batang.
Kau naik potong kayu satu pohon!
Dia gergaji perahu di sana.
Saya kenal barang tajam, baru saya kaget: adih!
Dorang lihat pohon kayu merbau itu besar.
Hari jumat orang pergi solat di mesjid.
Pohon pisang itu besar.
Mereka solat asar.
Saya masuk di cela itu.
Dia angkat tangan.
Lakilaki tondak kambing tapi kambing tidak suka.
enam belas
Hujan su tara turun; bakbak su kering.
Anjing kejar rusa.
Ruslan pu mama rau daun pisang bikin lamet.
Urkia masak kacang hijau bikin bubur posyandu.
Belut itu tinggal di air tawar dia tidak tinggal di air garam.
Anakanak sekola punya bangku kurang enam.
Dorang ikut jalanan turun dari sana.
Anak itu pu malas lagi.
Kita semua menangis, saya lagi menangis.
Suara pun saya tidak dengar.
Orang itu penyakit badan bikin dia.
Salima pu mama gali kuning di Kamberar banyak.
Tuti dorang masak nasi kuning.
Dian pu bapak dong putar perahu pi di Tat sana.
Orang itu jual bawang putih, tidak jual bawang merah.
Dorang punya bawang merah banyak.
Mayor dorang tanam bayam di kebun.
Bebek berenang di pinggir air satu kelompong.
Saya punya bahu sakit saya suru nenek Ruslan yang bikin.
Dia jatuh dia punya tulang bahu pata.
Dari Belanda yang datang belajar kitong punya bahasa.
Anak itu senang belajar di rumah.
Davit pu bapa pu tombak satu tapi tajam.
Orang itu punya lida panjang.
Rajiba pu mama itu baik.
Kau pigi lama begini.
Burhan dong mau main bola tapi gawang tidak baik.
Bakri pu mama mau bacuci tapi dia punya parteng su picah.
Anakanak banyak mereka tangkap ikan kecil mau goreng makan.
Meti besar kering Tamandi pu mama dong bori ikan kecil.
Binkur pu bapa bisa potong perahu dan juga bisa papan.
Tete Nostal yang bela papan La Deka yang pikul.
Saya makan saya gigit mulut luka.
Nostal bor pinggir perahu.
Mari o, kita makan.
Nabil pu mama dia pu bibir pedis.
Saya makan sedikit dulu.
Dia bawa lari dia.
Dia bicara dengan Yaban bapak.
Kamu bikinbikin kerja apa?
Dorang kerja fundasi di sana.
Om imam bor perahu pu papan.
Saya tidak suka pergi di depan, kamu di depan.
Dong tiga berdiri, satu di depan, dua dari belakang.
Anak itu su kasi mandi ka belum?
Anjing itu gonggong kucing.
Dia mau sekola tapi buku tidak ada.
Kiba dong pohon bunga banyak dia pu bunga merah.
Banda dong kumpul kayu tinggi.
Orang dari Faur yang datang mau jual pinang di sini.
Kelelawar malam itu dia terbang pukul-pukul mangga.
Sejenis burung nuri bertelur di lubang kayu.
Dia pu hidung jerawat bikin sakit.
Dorang jalan turun dari tanggatangga itu.
Kau punya ikan banyak, saya punya ikan sedikit.
lakilaki dari Kei, lakilaki dari Jawa, lakilaki dari Gorom
Lakilaki itu panjat kelapa.
Kiba pu mama beli cangkir dua dusin.
Mama kecil dan bapa kecil pergi di kebun potong pisang.
Kamong pu pinang bawa di bawa sana.
Di Gorom itu cengkeh banyak, pala itu kurang.
Bilal pu bapa dong pu rumah besar. Ibu guru dong pu kecil.
Dorang bikin sapu gamutu dengan bulubulu pohon enau.
Ikan dadir satu ekor baru dia warna bunga-bunga bagus.
Binatang kucing makan ikan di atas meja.
Kalamang dia mara potongpotong dia pu baju.
Irjan lompat dari atas jembatan.
Tamandi pu mama takut ular sampai lompatlompat.
Nostal pi belah bintangur bikin kudakuda perahu jonson.
Kukus nasi di panci dandang besar itu.
Buaya telang satu orang di sana.
Anakanak sekola cabut rumput di lapangan.
Bakri pu mama kau pu ipar su pi Gorom.
Malik dorong Banda di air garam.
Kaleng satu hanyut sinar matahari kenal kilaukilau.
Kitong masak air panas tungku terbakar.
Saya pu dapur kecil tapi dong pu dapur besar.
Rajiba pu mama dong asar pala asap sampai.
Api menyala dia kasih keluar.
Bakar kulit kayu besi api sampai bara.
Mereka bikin api dia pu bara banyak.
Mereka bikin api rumah terbakar.
Daun tikar banyak di tanjung.
Daun sirih tadi ka tumbu, dari mana, dari pasir putih?
Kamong duduk-duduk saja eh.
Burung bangau satu ekor terbang balik tanjung.
Gula habis apa kita makan.
Ada gula?
Kamu pu gelas berapa lusin?
Hujan besar jadi lampu tidak menyala.
Burung merpati putih satu kawan yang terbang.
Saya cabut akar.
Tada air hujan di dalam drem, drem sudah penuh.
Nene Ruslan minta bibit di Mustafa pu mama dorang.
Mereka jalan di ujung pasir.
Wowa Nona cuci piring gelas baku tatoki gelas retak.
Guntur sudah bunyi lagi.
Dia punya saudara tiga orang lakilaki.
Orang dari Fakfak naik jual durian.
Kitong mau pi pancing tapi perahu berlubang.
Saya pu laki lubang perahu mau pasang pokpok.
Dorang masak makanan baru dorang makan.
Makan oh, makan supaya dia cepat habis.
Anak itu menangis.
Ayam dua ekor baku tetok.
Bilal pu bapa tunduk pilih batu.
Kau usir ayam dulu!
Dia pencuri. Dia curi barang.
Mereka bikin Hawa dan Darfin pu tiga hari alas tikar lebar.
Saya turun di bawa itu timba air garam.
Saya pu mama su meninggal saya masih kecil.
Saya punya mama adik turun dari Gorom.
Mama tua pu badan panas.
Burung muntahmuntah suara itu tanda orang mau hamil.
Rehan pu poro bagaru dia munta.
Nenek itu bikin apa? Bikin ikan.
Ibu-ibu itu duduk cerita saja.
Pulau Besar (Pulau Kasuari)
Tol pu mama dong pigi duluan di distrik, kitong dari belakang.
Siapa dorang yang di belakang sana? Urkia dorang.
Dela dorang naik di dorang pu rumah.
Ular itu merayap di atas pohon mangga.
Siapa dong yang menangis itu? Anak-anak yang baku pukul.
Nabil pu bapak dong beli es mau taruh di ikan.
Bapak su pulang dari Fakfak.
Bapak kecil kasi saya uang lima pulu ribu.
Bapak tua beli baju kasi dia.
Iyo, pukul dia lagi.
Tete itu su tara kuat, dia su tua.
Anak kecil itu suda jalan.
Binkur pu bapak pi papan perahu.
Orang Fakfak tadi su berangkat?
Saya sisir saya pu rambut dulu.
Sarang elang di situ.
Burung gaga bicara terlalu.
Siapa dorang makan pala kau pu air gember keluar.
Pala itu dia pu pohon yang su kering.
Hari itu ikan banyak.
Kitong tukar tarapal di orang Bugis dengan papan.
Satu orang filoit di ujung pasir.
Ibu-ibu di sana duduk jahit atap.
Dulu itu dorang pili buah manggi-manggi masak makan.
Om Moktar pu bapa gosok dia pu tombak.
Mangga suda tunas, dia su mau bunga.
Semua tiga bakul ada ikan di dalam.
Durian satu buah yang gantung sana.
Nabil pu bapa angkat ikan.
Alam pu bapak kerja di kantor distrik.
Fikri merayap masuk di kamar.
Anak-anak mandi tumpah air habis.
Bapak-bapak duduk cerita.
Saya ambil bambu bikin keranjang.
Dia pu paru-paru sakit.
Anjing cium anjing pu pantat.
Ruslan pu mama dong pi pili gayang di Kambur.
Saya tidak, dia yang potong pisang itu.
Kau ambil dari sini? Tidak o, dari pasar.
"Kau mau bikin apa?" "Tarada, saya makan."
Babi itu dia pu taring ada.
Mustafa pu bapak gantung kaleng dan botol. Angin tiup dia bunyi.
Faris dia pu mama pukul dia, dia berteriak.
Alun dan Jikri dorang dua bikin jerat burung gosong.
Dong minum obat tewer pala hutan, kalo tidak dong muntah darah.
Dia pakai dia pu baju baru.
Pertama kali dorang datang dong belum tahu orang.
Rehan pu gigi jatu tapi tumbu baru.
Dia pu tutang gigi bengkak.
Saya pu anting su hilang.
Dong mau pi menyelam tapi kaca menyelam tidak ada.
Hari ini su sore lampu belum menyala.
Burhan dorang tanam pohon waru di ujung pasir sana.
Dia tanya perempuan itu. Dia pu mama-bapa tidak mau dia bawa lari dia.
Mulai sore serangga kecil mulai suara.
Malam kita cerita.
Saya tidur suda pagi saya bangun.
Mulai sore su hujan.
Saya mau jemur pakaian tapi mendung.
Matahari turun suda senja.
Dong pi tinggal di tempat kosong.
Malam hujan turun.
Kemarin hujan, sekarang terang.
Separuh masih di kampung. Sampai siang baru dong kembali.
Burhan dong tinggal di distrik.
Guntur suda bunyi su mau lagi mendungdung.
Tadi malam kilat menyala.
Dong petik mengkudu baru masak.
Saya menyapu pinggir rumah.
Kamu su mengerti bahasa Kalamang?
Kita panggil anak pulang dulu.
Bawa datang karung itu isi pasir.
Dinding ini su lapuk.
Taru lemari itu di terang.
Burung gagak itu bikin sarang di pohon kelapa.
Kamu hitam seperti burung gagak.
Pepaya itu dia pu tangkai tidak pegang.
Gufasal pantai itu pohon besar baru tinggi.
Saya punya tas sudah hilang.
Saya pi ambil bambu bikin keranjang.
Ruslan pu mama dong di Tanah Besar.
Sarang tewan di sana.
Barang bunyi dia lihatlihat sekeliling.
Dorang piara belut di dalam air.
Saya minta langkuas mau masak ikan.
Guru-guru pergi semua habis libur.
Dulu mereka timba air paki guci.
Kabar orang hilang itu betul?
Nika Darfin dorang.
Dorang hidup di mana itu semua baik.
Sakina dorang gali ubi kayu bikin holang saja.
Dia di sebelah itu.
Tiga puluh kitong beli.
Lemon hanyut datang.
Saya bilang Keica angkat barang.
Dorang tidur dia gua Wer.
Bakri pu mama dorang pigi gali cacing putih.
Ikan punya empedu yang pecah.
Mustafa pu mama dengan Abdula pu mama dorang dua pigi.
Orang-orang separuh pigi panjat kelapa separuh pigi pancing lagi.
Pisang contoh-contoh banyak.
Pisang papan itu sudah masak.
Pisang seleng itu pohon besar.
Pisang sepatu itu belum masak.
Pisang raja itu sudah tua.
Ikan bubara itu besar.
Satu perahu datang dari Fakfak, orang banyak.
Satu orang yang itu.
Potong daun pisang itu!
Kita bo pili ciput.
Dia itu pu nama panjang.
Jangan ribut!
Kita semua duduk bicara.
Dia tahu bahasa Inggris, saya tidak.
Nenek bikin tikar.
Ikan bubara makan, Dela pu bapa dorang yang hela.
Anak itu putih kaya orang Jawa.
Mereka adik-kakak delapan orang.
Saya punya baju itu bunga putih.
Pak Sam dong pi balobi tikam ikan pari.
Kain itu dia pu bunga garis-garis.
Tami pu bapak dong pu teras dong pasang tehel.
Biawak itu dia makan ayam.
Saya pamalas o, saya tidak mau pigi.
Jikri jaga Alun mau pukul.
Setiap hari jumat jam sembilang kitang kerja bakti.
Orang itu ada jenggot lagi.
Binkur bapak pi pancing tapi ikan tidak makan.
Perempuan Jawa dengan lakilaki Jawa dua dong datang dengan jonson.
Mayor suruh Salima pu tete bikin jendela.
Kalamang pu mama dong pigi di distrik beli barang-barang.
Orang itu main jinn.
Sakina pu mama bisa pegang jonson.
Kau pigi di mana? Tarada o, saya pigi di sana.
Dong su panggil dari darat.
Mangga itu sudah buah kecil-kecil.
Rustam pu nenek pakai kabaya.
Supri pu bapak pigi pancing gurapu.
Gurapu bintik-bintik itu di Tanah Besar banyak.
Madi pu mama bori batu la ikan poro bibi yang mati.
Saya lihat makanan saya sudah rasa kenyang.
Saya mau pulang di rumah, saya su lapar.
Fikri itu buah pelir yang bikin dia.
Dela ambil ikan punya tali perut.
Kelapa itu dia punya buah kalongkong banyak
Madi pu mama yang bori ikan sembilan.
Saya marah dia, saya hati kurang dia.
Salima pu mama badan jatuh, badan kurus.
Dia kasi miring kepala dengan badan di sebela.
Malik punya urat badan sakit.
Saya pu adak pu badan panas lagi.
Laki-laki Jawa itu dia punya bulu-bulu badan panjang.
Kursi itu gedung punya.
Bapak Agus yang jual kain.
Mama-mama dari Antalisa bilang...
Saya pi potong kayu ular.
Saya duduk di atas batu, saya pu pantat sakit.
Orang itu dia punya lubang pantat luas.
Tali is tall.
Sakina mau mandi dia buka baju.
Fatima dorang pigi ambil kayu bakar.
Kayu turi itu bunga yang masak sayur.
Pohon marunggu itu dia punya pohon besar.
Kayu buah besar itu dia pica terbang.
Rumah itu kamu punya.
Nenas itu belum tua.
Di Baki Tanggiun itu keong hitam itu banyak.
Kitong pigi pili ciput lagi di Mas.
Di pohon pisang itu cacing tanah banyak.
Pulau Karas yang di sana itu.
Kamu tidak tahu bahasa Kalamang, jangan kamu bicara.
Kiba pu mama dong pu depan besar.
Tanjung alangalang yang di sana.
Ciput ini sudah putih memang. ; Makanan su siap.
Anak itu lembek sekali.
Saya ambil daun tikar mau bikin tikar.
Afdal dong pigi perahu miring dia pu mama takut.
Tol pu bapak beli matakail mau pigi pancing.
Unyil pu mama dong pu koali besar su berlubang.
Ruslan pu nene tanam kumbili di pinggir rumah.
Mau hujan ka tidak?
Hujan turun.
Hujan gerimis.
Pelangi yang sudah turun dari sana peli angin.
Di Suo itu nyamuk banyak.
Dian pu tete dia sipat kayu.
Nangka itu masih muda.
Bayu pu rumah itu kamar dua.
Alif itu tidak makan, badan lombo.
Moktar pu bapa sasi kelapa di Tetar.
Supri pu mamapu ranting hilang.
Dia kirim saya seratus lima puluh.
Abas pu mama dong bikin kebun di tanjung alang-alang.
Sara songer bikin dia pu mulut bibir luka-luka.
Alun dong tikam ikan durian mau makan.
Moktar pu bapa itu dukun.
Di Toran itu angrek banyak.
Dian pu bapak dorang pasang seru di Kambala.
Ikan itu banyak di dalam manggi-manggi.
Irjan pu bapak tikam ikan pari.
Muklis pu bapak tikam ikan pari parut-parut satu ekor.
Pari burung itu di Tetar banyak.
Mama Jawa jatuh di air garam dia basah.
Madi pu mama potong daun tikar mau bungkus ikan.
Anak-anak pancing ikan serui di jembatan.
Pace itu sudah duda.
Besi linggis sudah hilang.
Ikan garis-garis dengan kawan.
Suster dong dari Tuberuasa datang jual isi kenari.
Nyong pu bapak dong bikin teripang di Kanastangan.
Ikan ini punya tulang banyak, saya tidak suka.
Mayor punya parang itu tajam.
Duri lemon tikan Dalima.
Arlan pu tete anyam lantai bambu.
Tamandi yang main di air garam.
Anak-anak itu bermain bola saja.
Rehan pu permainan su rusak.
Dia pu mata luka.
Dia pu bulu mata tebal.
Su malam, Dalima su mengantuk.
Suci pu alis mata luka.
Anak itu dia punya mata buta.
Rajiba pu mama dia pu biji mata sakit.
Fit masak nasi tapi mantah.
Nazuwa punya suara besar.
Mayor habis makan, dia kumur-kumur mulut.
Nostal desil dalam perahu.
Saya makan jagung saya punya dagu lelah.
Ngais jatuh dia pu tulang kaki di dalam sakit.
Buran pi ambil tali ikat kayu bakar.
Jaring saya punya itu kasih tarei.
Anak-anak ayam sepuluh ekor tapi mati satu, tinggal sembilan.
Ikan komu empat ekor.
Tataruga dia itu hidup di dalam telaga.
Saya punya bapak itu dia punya moyang sudah enam.
Sara pi menyelam ciput bia.
Saya punya baju itu sudah lapuk.
Dia pu daun macam rica punya.
Dulu itu kitong masih kecil-kecil kapal beli kayu kitong baru lihat.
Ikan kecil itu di kitong pu kolom rumah itu banyak.
Orang itu garai makan dia.
Di Kambur itu ada pohon kapok besar satu di situ.
Perahu itu kamu sendiri punya ka?
Supri pu bapak kerja rumah.
Dia baminta kuat tapi dia tara malu.
Kayu ini keras.
Karanjang rotan.
Ubi kayu ini hancur.
Dian pu mama itu badan besar tapi su kurus.
Dian pu mama itu badan besar tapi su kurus.
Ikan satu kawan di dalam karang.
Jikri pukul piring kasi pica.
Kita berdiri di sana, ular lari datang di situ, kitong lari.
Saya kasih tarei tali mau jemur pakaian.
Musim barat itu katak sudah ada.
Bobi pu mama bori ikan, ikan kecil itu mati.
Pace desa tebang kayu baru dia potong-potong cabang-cabang.
Mangga itu anggin tiup dia pu cabang pata.
Halim dia panah rusa.
Di pohon ketapang itu kalo malam itu kunang-kunang banyak.
Nanti sore itu kirik-kirik sudah mulai ada.
Dian pu nenek mau pi pancing tapi dia pilih kumang dulu.
Kitong pi potong bambu besar baru isi air.
Saya asar ikan.
Saya asar kayu.
Saya taruh ikan di atas asaran.
Saya bakar ikan tiga ekor.
Sakina pu tangan pisau kenal darah.
Mustafa pu mama dorang labu banyak.
Irjan pu bapak bikin ulu kalawai.
Burung yang suara.
Burung tanah yang bertelur.
Di Tanah Besar itu kasuari banyak.
Lamani pu bapak garis kayu.
Abdula pu mama pica ciput bambu.
Saya kori kayu besi pantai ramas baru minum.
Besok kitong pigi di Antalisa baku nika Anafia dorang.
Malik dong pi potong bambu.
Kita pigi di kali Namandar baru pancing.
Jikri potong kayu katapel.
Bobi dorang pigi tebang sukun hutan.
Orang Makassar tebang pinang hutan.
Pohon pinang itu di Tanah Besar yang banyak.
Di pasir Sar itu pohon bentol banyak.
Tomi pu mama buang tali hela ikan kulit tebal.
Binkur pu bapak punya parang sudah pata.
Ular muria di dalam batu.
Saya lihat Hidayat punya bapak dorang kupas rusa.
Saya beli benang mau jahit baju.
Nazuwa punya mama duduk lipat pakain.
Afdal menangis topi mau beli.
Nostal kupas pohon mangga.
Nabil pu mama dorang beli kacang mau masak bubur kasih anak-anak.
Burung mata merah makan Sakina dorang punya rica.
Dia pi potong gagan kalawai.
Burung urip banyak.
Lusa pace desa dorang pi kota.
Nasi itu di atas masih mentah.
Pi di darat, ada komo yang main di sebelah darat.
Kayu bakar itu di atas sana.
Kemarin dulu itu hujan turun.
Saya su taru ikan itu di atas.
Anak-anak naik di atas pohon.
Saya tidur muka di atas.
Dia punya bulu ketiak ada.
Gustami itu nakal.
Capung telinga yang luka.
Saputra itu dia pu daun telinga besar.
Aya Tok itu kitorang tanya dia itu tuli.
Alif itu dia pu lubang telinga sakit.
Saya dengar dia bilang ikan tidak ada.
Kaimana itu kabupaten baru.
Musim barat itu pi di kota itu ombak.
Rustam punya nenek bilang dia pu badan lemah.
Penyu itu di muka kampung banyak.
Matahari naik la merah.
Pohon kobalet satu pohon di Mas.
Rumah lampu itu di atas kampung.
Safril pu bapak - saya panggil dia mantu.
Dela dorang beli jaung dari kota.
Dulu dorang pakai cawat.
Rumah itu sudah jatuh
Dorang pigi tebang tiang rumah.
Kamong pigi di mana?
Dia pu kakak tua datang.
Saya pu istri su datang.
Kamu punya istri naik di gunung?
Kamu punya istri su datang.
Saya cari tapi teripang tidak ada.
Tidak ada teripang gosok.
Di darat itu batu.
Panas, kita duduk cari angin di bawa bayangan.
Saya lihat satu bayangan.
Akar mangga itu besar.
Keranjang itu sudah rusak.
Saya kirim Burhan uang.
Pohon kelapa satu itu ada tewon.
Nenek bungkus kacang goreng.
Ramina pu mama bungkus nasi kuning.
Wer itu keladi hutan itu banyak.
Tahi anjing di Kiaba itu banyak.
Orang itu dia punya usus besar sakit.
Dia pu kentut bau!
Madi dia pu istri sudah kasi tinggal dia.
Dela pu bapak sudah kawin lagi. Dia pu istri kedua Tuti pu mama.
Ikan hias di Mas itu banyak.
Kamorang punya kelapa banyak.
Kita makan di rumah Tami dong.
Perahu punya depan.
Saya kira dia mau jatuh.
Dulu itu Ayah Ludin pu bapak berlayar turun di kebun.
Sakina pu mama bisa pegang jonson.
Bobi pu mama dia punya ayam banyak tapi masih kecil.
Yang kecil tadi su naik.
Mayor kawin dia Makassar.
Ular lingkar Unyil dong pu ayam.
Saya garam ikan tapi ulat banyak.
Om Nostal itu sikakar.
Davit pu mama parut kelapa.
Anjing itu punya tulang rusuk saja.
Binkur pu bapak dia pu rusuk sakit.
Langit su mau bersih, baru biru lagi.
Dorang dua molo akar baha.
Dia di Tanggor.
Rustam pu nenek dia salah ludah saya.
Kucing itu sudah jilat pang itu.
Rifai pu mama itu dia pu anak satu, Rifai sendiri.
Kita dua dengan Bakri pu mama makan, saya tamba lagi.
Mei dia panggil Bakri pu bapak.
Anak itu menangis gula-gula.
Nanti musim timur itu debu sampai terbang.
Anak-anak dong petik Sakina dong pu kandodong, dong marah dong.
Bobi pu mama dengan Kiba pu mama dorang duduk minum kopi.
Saya lari dari tawon ini.
Unyil pu bapak pu kaki sakit dia bungkus.
Hujan turun kitong lihat Pulau Faor dekat.
Burung madu isap bunga kapok.
Rustam dorang itu ayam putih banyak.
Sara dia cari telur ayam mau bikin obat.
Alun pu bapak dong bagi dong pu harga kelapa, masih kurang.
Tuti dorang pi di gunung panjat pala.
Nadia pu bapak dong pi potong perahu di hutan sana.
Dari rumah sakit dong bagi kolambu.
Dia orang dari luar.
Davit pu mama pu paha sakit.
Bilal pu bapak kasih keluar perahu.
Bobi pu mama pigi pancing dia pu urat talingkar.
Om imam pigi ambil linggis mau cabut paku.
Jikri dorang pigi pancing dong hela ikan koltengteng satu ekor.
Tami pu bapak pi pancing dia dapat dorom satu.
Unyil dong pu belakang dapur itu ada tebu.
Kita pigi mandi safar, Irjan pu bapak tikam ikan pari satu ekor.
Kalamang dia pegang ayam baru dia lepas lagi.
Banda pu leher sakit.
Nyong pu mama dong belum tutup dong pu rumah.
Binkur pu bapak dia pu leher sakit.
Bapak desa dorang bakar dorang pu kebun di kolam.
Rustam pu nenek dong tutup dong pu penutup tong.
Kita duduk cerita, Bobi pu mama salah cerita, kitong tertawa dia.
Lakilaki lihat dia pu anak.
Motor satu datang Onin pu mama pigi lihat.
Bakar lampu pelita itu!
Mustafa pu bapak pu kebun di Kamberar itu timur banyak.
Salima pu bapak dong punya fiber satu.
Dia pu lebar mungkin lima meter.
Saya kira kita tidak turun.
Kiba bapak lihat motor satu pancing di situ.
Saya lupa saya pu sayur di dorang.
Faris pu kaki luka, tempel obat di situ.
Fatima pu mama meninggal itu dia ingat.
Mustafa pu bapak dia cukur jenggot.
Saya ambil sayur dari dia.
Separu saya su belah mungkin ada dua puluh ekor ka.
Dian pu mama dia siram Binkur pu bapak dengan air.
Burung elang satu ekor turun tangkap ikan.
Dong istirathat dulu di Usinona pu tete.
Irjan pu bapak pigi balobi dia tikam sonton satu ekor.
Nabil dia makan gula-gula karet tempel di dia pu baju.
Kau pu kaki sakit.
Yasin pu bapak dengan Bakri pu mama itu saudara sepupu.
Nyamuk gigit Aprilia.
Urkia itu telapak kaki luka.
Onin pu mama jalan kaki.
Saya pu mata kaki ini saya jatu jadi luka.
Pergelangan kaki ini bengkak.
Urat kaki ini dia luka kau jalan bagaimana?
Sila pakai dia pu mama pu sandal.
Unyil pu bapak itu dia pu kaki besar.
Davit pu mama pu metis besar.
Bebek laut satu ekor duduk di atas batu.
Randa pu mama potong ikan baru iris.
Kiba pu mama pu lutut sakit jadi dia tara pigi.
Abdula pu mama pu jari kaki sakit.
Nyong pu bapak pu kuku tatoki luka.
Dian pu bapak konta potong-potong mangga.
Suci pu bapak pu tulang kering la luka.
Saya tanam pala itu dia sudah tumbu.
Mayor pu perahu kayu ganti dengan Salima pu bapak pu fiber mau pigi di kota.
Unyil jalan dia kenal dia pu mama, dia pu mama jatuh.
Anak-anak duduk ambil Pak guru Sam dorang pu bunga pala.
Pak guru Banda pigi gait pala.
Kitong pigi di kota kitong kunci rumah.
Saya kasih dia teh.
Tamandi pu bapak dong pi dorong perahu ke laut.
Nabil pu mama cerita dengan saya tapi dia balik belakang.
Binkur pu bapak duduk isap rokok saja.
Dian pu nenek tusuk ikan baru bakar.
Randa pu mama dia kaget kucing.
Nabil pu bapak pigi pancing pancing tapi tidak dapat.
Bakri pu mama dong pakaian kotor banyak.
Suci pu mama tiup apa, dia pu api mau mati.
Rukmana pu mama sumpah Rukmana.
Ikan tanduk itu di Baki Tanggiun itu banyak.
Ikan paus satu ekor ikan halus naik dia putar putar di dalam.
Tomi pu mama duduk kasih naik keranjang.
Nenek Ruslan pu nenek dia bakar ikan dia jepitan api.
Kita alas lantai bambu di atas para-para.
Bobi pu mama pinjam beras dia sudah ganti.
Nenek Ruslan dorang tanam jagung di kebun.
Gustami potong kucing satu.
Desi duduk tapi Fit ganggu dia terlalu.
Dalima tutup makanan di atas meja.
Kitong punya beras sudah habis.
Alun bapak panjat kelapa.
Salima masak nasi.
Tadi malam angin utara jalan.
Satu ekor bubara kering di Baki Tanggiun.
Moktar pu bapak dia bahasa Kilimala lagi.
Binkur pu bapak cas saya punya hape orang pencuri.
Burung walik satu ekor duduk di sana.
Pohon beringin di kolam itu sudah mati.
Ikan samandar satu kawan makan lumut perhau.
Waktu ibu guru Ratna kawin ada kuli-kuli satu.
Pohon beringin pantai satu pohon di ujung pasir Kambur.
Sakina pigi pancing di jembatan dia hela ikan kulit tebal dua ekor.
Malik itu dia punya kulit badan hitam.
Kitorang itu pohon pala banyak yang lakilaki, tidak.
Mulis pu mama dong pu beras satu karong hampas-hampas banyak.
Abdula pu bapak dong pulang dari tanah besar itu lumba-lumba bermain.
Bakri pu mama goyang tumang mau bikin sagu.
Dia su pi di darat bawa pulang dia pu adik di laut.
Burung bangau besar berdiri di atas batu jaga ikan.
Nona dengan Alun dong dua buang jaring ikan kapas-kapas banyak.
Siti Kelsaba pu mama dorang dari Antalisa datang jual baju.
Di sini tidak ada kuda.
Rajiba pu tete pu badan panas.
Mamaria yang meninggal di Tarak.
Bebek laut dua ekor yang terbang pigi di sana.
Mulai sore itu lampu sudah menyala.
Saya mandi di air garam baru saya gosok dahi.
Abdula pu bapak pi potong kayu palangga mau kasi naik perahu.
Bilal pu bapak mau kasi naik perahu di situ tapi tempat sesak.
Anak-anak main silat.
Ikan ini su bau.
Dia jalan sampai dia pu kampung muncul.
Rifai pu mama baru keluar.
Tami pu mama masak air panas tapi dia su mendidih.
Kau terlalu cerita banyak, pi sana!
Perempuan Jawa itu muka lebar sedikit.
Alun dorang taru jambu di dalam baju.
Manado tarik ikan merah banyak.
Aina mama pigi ambil bambu kecil mau bikin goyang-goyang.
Janiba pu mama itu dia pu kandungan subur.
Sakina kasih masuk jambu di dalam baju.
Nyamuk gigit saya, dia gatal saya kori.
Saya pu badan-badan semua gatal.
Imam pi di Fakfak.
Onin pu bapak dia pikul pala.
Faldi pi jual biji pala seratus tapi lebi tiga biji.
Dia lewat kayu.
Kitong pu raja Ati-Ati.
Ratu itu orang Patipi.
Kandang kambing itu bikin di Mas.
Salima pu mama dia jemur kain dia terbang.
Dian pu bapak dorang pigi di distrik dorang gami.
Dulu itu dorang pakai kampak potong perahu.
Saya ambil tali bambu mau jahit atap.
Pulang yang di muka kampung.
Saya belum lihat kampak batu itu.
Di kampung Kiaba itu anjing banyak.
Gempa bumi itu saya rasa.
Mama Jawa Tuti cari rica tapi tidak ada.
Rajiba pu bapak dorang pigi di Karas Darat panjat pala.
Rajiba bapak dorang pigi pancing di tanjung Lengleng.
Faisal pu mama mau pigi pancing tapi dia pu perahu kayu tidak ada.
Nyong pu bapak suruh om Nadia pu bapak belah tiang rumah.
Orang cerita kayu putih itu di Buru-buru ada.
Saya mau cat perahu. Di atas biru, dia pu les kuning.
Hujan turun jadi jalanan licin.
Nabil pu mama dia teman dengan siapa?
Pat pu mama dia potong tali pusar.
Randa pu mama beli gelang.
Nabil pu bapak minta fiber Nabil pu tete dong, dia mau.
Binkur pu bapak kerja dari pagi sampai zuhur.
Aprilia pu mau bilang dong pi cepat.
Kulit kayu itu su busuk.
Kitong pu pinggir rumah itu daun banyak, daun afokat.
Unyil gali lubang mau tanam sampah.
Mustafa pu bapak dia pu jam tangan hilang.
Nenek Ruslan bikin lopalopa lagi.
Tomi pu mama legu tali pancing dia hela ikan hiu.
Kita di atas jembatan lihat gapura bagus.
Tamandi pu bapak minta lot di Binkur pu bapak.
Di Kamberar itu ada buah raus satu pohon di situ di mata jalan.
Minuman ini dingin.
Di sebelah timur itu air garam kabur.
Safaruding dorang datang dari Sorong.
Burung rajawali satu ekor turun tangkap ikan.
Kayu elang banyak di Sar tapi dia sudah kering.
Dia pigi di mana?
Saya makan kau kasih habis.
Ramina dia bungsu.
Dua anak bakalai. Dorang pu mama bilang: "Itu sudah, jangan bakalai lagi."
Maryam dia yang sulung.
Saya lunjur saya pu badan.
Orang-orang semua pigi di sana rapat.
Mariyam pu laki itu orang Fakfak.
Rumah itu dia punya.
Anak-anak sekarang ini Bahasa Indonesia saja.
Kita ambil Mustafa bapak bikin malam.
Irjan pu bapak kasih terbalik dia pu fiber kori lumut.
Tahan dia tetap tidak!
Samandar papan itu kalau malam itu masuk di kolam dengan kawang.
Kita kasih miring perahu irisiris dia pu sebelah kanan.
Samandar itu banyak di dalam karang.
Burhan dia panggil Tami pu bapak om.
Rajiba panggil Riska pu bapak itu om kecil.
Ruslan panggil Nadia pu bapak itu om tua.
Bayu pu bapak berdiri di pinggir perahu.
Ada ikan ka tidak?
Burung tahun itu di Suo banyak.
Manadu dong jual di Fakfak itu satu tumpuk lima puluh ribu.
Randa pu mama siram kopi tapi pahit.
Dulu itu dorang menari itu harus pakai gong.
Tami mama kasi saya ikan, saya masih gantung dia.
Irjan pu saudara kecil su merayap.
Burung gosong itu di Tanah Besar baru ada.
Di Werneti sana baru ada burung goura.
Dian pu tete pi di laut kasih betul perahu talempar.
Onin pu bapak dong rombak dong punya seng rumah.
Ngais dia makan la tulang ikan tasangku leher dia muntah makanan keluar.
Bakri pu tete kasih hancur nasi baru makan.
Binkur pu bapak dia taruh parang di sini dia pi cari di tempat lain.
Saya kasih kering perahu.
Nenek Ruslun itu pu gelang emas satu di tangan itu.
Tami mama Tomi mae tua Mayor mae tua dong jalan di jembaten.
Alam pu mama dorang dari distrik pi di laut.
Tami pu mama iris sayur.
Nabil ingus bikin dia.
Mas itu pu pasir putih.
Randa pu mama dorang menjemur pakaian.
Nyong pu bapak angkat kayu.
Orang Makassar datang bikin telur ikan terbang.
Unyil pu bapak potong ulu parang lagi.
Banda dari laut jalan piki di darat.
Laka pu mae tua merobek daun tikar.
Rahman kaki seribu gigit dia.
Langit bersih kitong lihat naik di atas bintang banyak.
Hujan turun embun masuk di dalam rumah.
Mustafa pu bapak dorang pameri di Mas, kebun kambing.
Saya pu celana pu tali su ikat mati.
Sorong kursi kamari.
Orang Fakfak yang datang.
Malam itu kunang-kunang banyak di pohon ketapang.
Dela esun pigi pancing tapi dia tarik ikan mata.
Tamandi kasih jatuh Arel pu sepeda.
Kayu ini bengkok.
Dia pu tangan sebelah dia bengkok naik.
Baju ini dia pu kain tebal.
Saya tidaur la angin tiuptiup saya rasa enak.
Tamandi pu mama dia bela-bale ikan garam.
Baju itu bagus.
Kitorang ini sial lagi.
Dari darat sampai di laut berapa mil?
Kucing naik Kalamang mama kasih keluar
Bapak desa dorang duduk cerita.
Nanti tunggu dorang di situ.
Kau pu belakang su baik? Baik sudah mu.
Rustam pu nenek tahi lalat satu di dia pu kening mata.
Kiba pu bapak kumpul kelapa di Kuek.
Bobi pu tete itu pu messa belum ada.
Saya kasih keluar ikan pu insang.
Nasi ini kitong makan rasa ampas.
Kayu batang itu su di situ.
Nanti bulan dua itu Elin dengan dia pu bapak datang.
Saya mau bikin saya pu baju banyak begini.
Hawa pu anak suda tidur.
Saya pu sakit hati.
Saya pu hati hancur.
Kalamang mam bilang dia minum air itu tenggorokan sakit.
Dia punya tempat tidur kotor.
Saya pu minyak goreng tidak ada.
Manado dong suruh Mayor potong ikan.
Ladeka pu anak merayap di atas semen.
Nabil bapak pu fiber itu laju.
Alun itu malas.
Mangga itu masih asam.
Saya goreng ikan tapi saya masih sembunyi.
Desi itu rajin.
Ini sudah musim pala.
Mereka dari distrik yang datang.
Dalima naik beli mi tapi Sakina dong masih makan.
Di Kiaba itu pohon tumang (sagu) banyak.
Isi tumung sedikit saja.
Ulat sagu itu banyak.
Dorang bikin makanan di Randa mama dorang. Dorang bikin fundasi.
Burhan bilang dia su lapar.
Anak-anak lempar mangga pakai batu.
Tempat itu dorang punya.
Dorang pigi di gunung durang su pulang lapar-lapar.
Mustafa pu bapak yang mujin.
Dian pu nenek pigi lego tadi.
Salima berdiri goyang dia pu badan.
Rehan tidak mau pigi dia angguk dia pu kepala.
Jikri dong pigi goyang-goyang jambu.
Kau pu pinggang sakit.
Dia masuk dari sebelah sana.
Ikan itu sudah busuk.
Faisal pu mama dorang itu lemon banyak.
Sundus pu mae tua itu kutu banyak.
Jangan ganggu!
Saya lagi pu telur kutu ada.
Kalamang pu bapak dong di Teporat.
Moktar dorang pigi di sebelah barat panjat pala.
Kita mau pi di Fatar pu sebelah barat.
Unyil dong cari kutu di sana.
Kitong naik di puncak tete oyang.
Burung pergam pu anak satu.
Saya makan mangga pakai gigi.
Ikan pari itu pu isi putih.
Mutiara itu di sini tidak ada.
Kita pata dia pu ujung.
Ini saya pu bapak mantu, ini saya pu bapak.
Saya makan kue.
Kucing kasih jatuh barang itu turun.
Kemaring saya tidak kerja dengan baik.
Hati-hati di jalan, kirim salam di dorang!
Orang Buton itu dong sendiri tenun kain.
Bayu pu bapak tampar Bayu.
Mayor pikir kampung ini baik saja.
Dorang bagi jata beras tapi masih ada sisa.
Pohon lontar itu tidak ada di sini.
Burung itu pu bulu-bulu macam daun-daun.
Rukmana pu mama pu anak kecil poro sesak.
Suci mama pu kepala sakit.
Halim pu anak dia pu ubun-ubun belum keras.
Jafaris itu dia bilang dia pu baju itu kucak saja.
Kita ambil kapas baru kucak di dalam air.
Unyil mama pijit Unyil bapak pu kaki.
Rustam pu ayam mati.
Salima pu mama giling rica mau masak ikan.
Saleha pu laki pigi di Kiaba.
Tamandi pu mama bilang di geli ikan itu.
Lubang batu pi dalam.
Siapa dorang itu? Tidak o, Kalamang dorang.
Mama-mama dong manggurebi dengan koli-koli.
Alun kasih kembali baju di Jikri.
Saleha sudah kawin.
Dalima dengan Salima dong dua bakalai, Nazua yang peli.
Nabil pu mama cium Dian pu mama pu anak.
Bobi lagi pi di Fakfak.
Penyakit makang kamorang dua o!
Kitong semua yang su dapat jonson.
Anak-anak ribut.
Saya tindis saya pu kaki.
Bakri pu mama iris sayur.
Kucing dua berkelahi.
Pace desa dia hitung pala lagi.
Saya angkat perahu, tidak bisa.
Dia tongka dagungnya.
Om imam dorang tondak papan.
Dia kasih kandas pertama.
Telur ayam tidak ada.
Rustam belum sunat.
Bulan puasa itu anak-anak rajin sembayang.
Mayor pu istri duduk di kursi baru sandar.
Citra dia jalan baru Ngais tarik tali dia jatuh.
Kalamang tidak puasa dia batal.
Air penuh baru balang-balang kayu hanyut.
Anak-anak mengaji di Rajiba pu tete.
Nyong mama rebus daun pepaya.
Dia goyang dia pu badan, dia pu tanah terhambur.
Ruslan pu nenek dia tusuk daun tikar.
Tomi pu mae tua mau siram kopi tapi gula tidak ada.
Supri jangan kau maju kau mundur saja!
Dong pukul tipa orang-orang menari.
Hujun turun saya tada air.
Burung bangau tetok ikan.
Saya tulis Elin pu bahasa Kalamang.
Dorang baku pukul.
Dian pu bapak kasih lurus perahu.
Dorang baku ketemu di perusahan.
Di atas sekola itu tanah merah.
Dorang kasih tanda kelapa.
Tadi pagi itu hujan turun.
Hairul pegang jonson lari putar-putar.
Salima mama sendok sayur lagi.
Mustafa pu bapak dong mau pigi di kebun tapi masih tunggu Sakina.
Bakir pu mama tidur tapi Desi kasi bangun dia.
Suci gendong Inaya.
Rajia mama bikin kue lagi.
Kerang itu pu lubang besar-besar, tempel pakai daun.
Dia sendiri kasih bersih dia pu rumah di atas.
Ikan apa yang tetuk?
Kau rasa dia pu apa lagi beras tadi itu...
Jangan kau apa ini!
Bikin apa? Tarada o...
Di Gorom itu ikan julung banyak.
Bak di sekola itu air di dalam.
Ibu itu lebih tinggi daripada saya.
Mulai sore itu jangkrik suda suara.
Dalam rumah gelap.
Mari, tidak, duduk di dalam rumah.
Ujung kayu itu sudah pas.
Perahu di sana terlempar.
Saya sudah bayar utang di Sakina dorang.
Manado pigi beli tali nika.
Saya kan tidak isap rokok.
Nenek dia pu badan panas.
Saya belum lihat moyang perempuan.
Pak guru Marlan pu gigi sakit.
Gustami dong mara dia, dia diam.
Dong dua duduk bisik-bisik.
Bambu air di kampung ini tidak ada.
Motor satu yang bunyi.
Yusra pu mama pukul dia dia pi sembunyi.
Dia pu mata sudah tutup, jangan kau ganggu dia.
Dengan batu kerikil supaya hujan jangan tanah padat to.
Nabil mama dorang bikin gado-gado ciput.
Irul mama minta ofen di Mustafa pu mama.
Saya tada air hujan.
Afokat pu daun jatuh banyak di bawah.
Botak hela ikan walu-walu besar satu ekor.
Tadi hujan turun besar.
Anak tadi jual ikan.
Hari ini dorang paku Nyong bapak dong pu seng rumah.
Davit bapak suruh Dian bapak potong belakang perahu.
Kitorang lihat jam.
Laka pu mae tua pi pancing hela ikan pogo-pogo.
Orang kampung pigi angkat pasir mau bikin taluk.
Ciput kecil itu di pinggir taluk ada.
Di pantai Kambur itu pasir bersi.
Kita pigi naik di gunung kitong masih istirahat.
Om imam dorang masuk di pantai Kambur.
Kitong semua mandi safar di ujung pasir Kambur.
Di ujung jembatan itu ikan kulit licin banyak.
Ikan kulit tebal itu kasih habis umpang.
Hujan turun terus, siang malam.
Banyak lalat di dapur.
Madi pu mama jinjing keranjang.
Bibi Ruslan pu mama ambil daun tikar.
Orang dari Fakfak datang pasang tiang lampu baru pasang lampu.
Dong kasih berdiri dong pu tiang gorden.
Tiang-tiang sudah lapuk.
Ciput itu tidak ada di sini di Tanah Besar baru ada.
Mester pu mata kotoran masuk, dorang buka baru tiup.
Arus di laut ini kuat.
Tali arus di pulau besar itu ada.
Randa pu mama makan pinang.
Bulan maulud itu matahari masih panas di bulan in su hujan.
Ikan bulan itu di manggi-manggi ada.
Di Wer itu kayu buah jiku empat satu pohon ada di situ.
Bulan purnama.
Nabil pu balan meledak.
Nabil pu balan meledak.
Kalamang bapak pi di Fakfak.
Benalu satu pohon di atas pohon kenari.
Jalanan itu dia licin.
Saya anyam lantai bambu.
Madi mama dia makan pinang baru dia ludah.
Bulat mama dorang jahit atap daun nipa.
Kitong naik di puncak sana di rumah lampu.
Ciput madiki besar di pasir kecil itu ada.
Roti ini sudah bengkak.
Ubi kayu baik itu di Sakina dong pu kebun itu ada.
Cepat langkah sudah!
Nabil pu bapak itu dia langkah.
Lintah itu di kampung tidak ada.
Pangkut itu siapa punya? Tarada o, Binkur bapak punya.
Irul minta kelapa.
Bilal mama pigi di Bau-bau. Rajia mama dia pesan kompor.

Arifin Jido taruh janji basunat dia pu anak-anak.
Suryan mama dorang mau pi di Gorom, dong jalan pesan-pesan.
Ciput cipek itu di Suo itu banyak.
Di distrik begini kalau hujan begini lagi itu lumpur.
Burung hantu itu kalau malam dia suara.
Tami mama belah ikan garam.
Bakri pu mama dong potong-potong ikan.
Buaya itu di sini tidak ada.
Nyong bapak dinding dia pu rumah.
Yahya dorang punya kebun itu dekat saja.
Bakri pu tete sudah bangun.
Kita alas palanga dari pantai ke darat.
Fitri alas tikar.
Burung elang satu ekor yang terbang.
Api bara ini kitong bakar jagu boleh.
Rustam dia jual pala.
Sakina mama dong pi di kebun dia lagi ikut.
Randa dengan Nazua dong dua bakalai. Randa cakar Nazua.
Pace desa dorang yang duduk di Mayor dorang pu para-para.
Supri pu mama petik sayur.
Bapak tua potong buang pinggir perahu.
Ikan itu sudah busuk, Nabil mama sudah buang.
Burung lepas ikan, anjing su makan dia.
Ayam itu pu sayap pata.
Suci bikin ikan lagi.
Dong belum bikin rumah.
Dorang turun dari mana? Dari perahu.
Beras jata belum datang lagi.
Kedondong itu siapa dong punya?
Keladi kuning itu di Sakina dong ada.
Moktar bapa pigi buang air.
Kau usir anak-anak dulu!
Air garam itu bersi sekali.
"Angin besar?" "Tidak, tedu."
"Angin besar?" "Tidak, tedu."
Air di pinggir mesjid itu air payau.
Hami mama sudah janda.
Abdulah maam dia goreng pisang.
Amin pu bapak dorang dari Kiaba datang di sini taruh harta.
Saya duduk jahit Burhan punya celana.
Saya duduk jahit Burhan punya celana.
Dia lempar pi kenal dia pu luka.
Bekas luka satu di Mayor pu istru pu tangan.
Dulu itu saya pu nenek dorang bakar pisang pakai batu.
Dulu dong bikin bakar batu.
Binkur bapak dorang bikin bak tapi papan tidak ada.
Burhan dorang pigi isi pasir mau bikin bak.
Kita pu anak tidak ada.
Di Kindius itu air di bandar kayu ada satu di situ.
Perempuan itu datang dari mana?
Dong potong pisang.
Pisang itu berapa sisir?
Kalau di Tetar itu sibu-sibu kuat.
Kapal perintis itu dia pu tiang tidak ada.
Teh ini belum manis.
Penyakit makan kau!
Babi satu yang mati.
Air minum tidak ada.
Dia minum air putih saja.
Kau minum teh ka kopi?
Kopi tidak ada.
Air tawar itu kasih dia tidak.
Air di Unyil dorang itu air tawar.
Dong di sebelah tepi sungai di sana.
Manado dorang pigi pancing di air terjun.
Citra dia menangis tapi dia pu air mata tara keluar.
Fadila kupas pisang.
Dalima punya bila-bila besar Irjan pu mama dong pinjam.
Sampa di pinggir gedung itu banyak.
Dulu itu dorang taruh pakain di dalam peti.
Kita bikin apa lagi?
Uang itu kita punya.
Piring itu berapa lusin?
Kamong kumpul pasir di sebelah sana.
Uang itu siapa punya?
Kalamang bapak dorang punya uang sisa.
Unyil dong jual sukun.
Muklis pu bapak berlabuh bual garapu.
Siput bor itu di telaga-telaga ada.
Tewer apa itu? Tewer nangka.
Nazua pu mama potong kue besar-besar.
Air mengalir di lubang batu itu di Bakri dorang pu pinggir rumah itu ada ikan gurapu.
Pisau jatuh di lubang turun.
Wosiwosi siapa punya?
Bakri bapa potong lot.
Unyil pu bapak tikam ikan pari.
Derem satu yang hanyut di sana.
Nyong bapak dukung Aprilia.
Abdula pu mama dorang pigi di Faur.
Ciptu bor pasir itu di kampung tidak ada.
Saya pukul kau itu kau mati.
Marni ikan itu potong dia pu sayap ka?
Orang itu pu mata mengedip-mengedip.
Batang sirih itu di sebelah barat itu ada.
Tuma cubit Ona.
Juairia pu nenek dorang yang jual sirih.
Telur kupu-kupu di daun jambu.
Baling-baling pesawat itu dia putar kencang.
Belalang makan daun kelapa.
Sirih buah ini Randa pu mama beli dari Fakfak.
Kelap itu berapa buah?
Kelapa itu semua lima puluh buah.
Saya pu rambut tidak rapi.
Keladi ini duah puluh buah.
Pala itu semua dua puluh satu.
Bakri mama cuci pakaian tapi sabun dia busa sampai...
Jikri bikin panah mau panah ikan.
Berapa puluh? Tara tau.
Dorang delapan puluh orang yang pigi rapat.
Kayu itu semua sembiilan puluh.
Bunga pala semua dia pu berat sembilan puluh sembilan.
Uang itu empat puluh ribu.
Ikan itu empat puluh satu ekor.
Desi pu uang tiga puluh ribu.
Fit pu gulagula empat puluh empat biji.
Mama desa minta pinang saya kasih dia tiga puluh tiga.
Kayu itu dia pu banyak tiga puluh satu.
Kayu bakar itu dia pu banyak tiga puluh dua.
Alun pu baju sepuluh panggal.
Kalamang punya baju nomor dua belas.
Faldi pu sepatu nomor tiga belas.
Telur ayam itu sebelas buah.
Pepaya itu semua enam puluh buah.
Nabil pu kelereng pu banyak semua tujuh puluh.
Kamong pi tumbang!
Saya dengar bunyi jonson.
Dian pu mama pigi ke sana.
Tamandi mama pu rak pakaian besar.
Karang di laut ini sudah mati.
Karang ciput itu di pinggir air biru.
Mangga itu enam buah.
Dorang adik kakak itu mungkin tujuh orang.
Bakri bapak dorang tarik ikan banyak.
Ikan beranang bolak-balik.
Anak satu berteriak.
Di laut sini itu tedu.
Air itu masih hangat-hangat.
Orang Makassar datang mau jual kalong.
Dorang pancing di tengah itu.
Nyong mama dorang cerita la tertawa.
Nema pu laki itu orang Seram.
Nenek mau bikin tikar, dia kasih lombo daun tikar dulu.
Rica itu banyak.
Kau kasih dia keladi itu terlalu banyak.
Dia kasih kau ikan kurang banyak.
Onin pu bapak jual dia pu kating-kating harga lima ratus ribu.
Faldi pu pala seratus biji.
Mungkin Mayor pu mae tua kasih kau baju?
Kita pigi di Kindius la saya tebang kayu yang ada duri satu pohon.
Bibi Ruslan dorang cerita.
Ikan so besar satu ekor mungkin begini ka.
Kue ini seribu satu.
Kelapa itu tinggi.
Nanti hari rabu baru Dela bapak dong pigi di Fakfak.
Pohon karet itu di sini tidak ada.
Kayu putih itu di Sanggalabai baru ada.
Kulit kayu itu kau sudah kupas?
Kulit kayu itu kau sudah kupas?
Tual kayu itu kau belum potong ka?
Cabang itu sudah kering.
Pohon ketapang itu sudah jatuh.
Dian bapak lari sampai di sana baru balik lagi.
Hairul padam lampu.
Arlan pu tete dia pu kaki bengkak.
Malik tarik ikan hiu satu ekor.
Hiu satu ekor mati di sana.
Manggiwang tutup mata kitong jarang lihat.
Bobi mama hela ikan tefar banyak.
Mama Putih itu dia pu laki orang Onin.
Di pasir Kambur itu bunga matahari pantai bagus-bagus.
Abdulah mama gali ubi kayu.
Kamu masak nasi sudah masak.
Di bawah pantai sana anak-anak bermain.
Abdulah pu bapak dia potong rutas mau papan dia pu perahu.
Di Suo itu pohon kasuari kurang, satu-satu pohon saja.
Onin bapak dia buang jaring ikan satu tali.
Rita pigi pinjam Nabil dorang punya lesun.
Mama Jawa punya anak lesun Tamandi bapak potong bikin lot.
Riski pu mama dong pu pala satu pohon kering.
Mayor potong bambu mau ikat pagar.
Pak guru Elisa itu orang Buruwai satu.
Depan perahu itu su bocor.
Nyong mama dorang punya rumah pakai kolam.
Mayor itu pameri dia pu bekas kebun lagi.
Ramli pu mae tua bisul bikin dia.
Alun bapak pakai celana panjang.
Saya itu parang tidak ada.
Mustafa mama dorang gula tidak ada.
Kelapa itu dong punya semua.
Pamali, jangan kau makan nanti kau hosa.
Ikan parang itu jarang baru kitong dapat lihat.
Muklis bapak pigi pancing di kelat.
Ayah Tok bakar pisang.
Usman dengan Kadir dong pigi molo udang.
Bibi Kambur mama mau tanam ubi kayu tapi linggis tidak ada.
Laka dorang bikin dorang pu rumah di Tat tapi dong pasang kasur kaya.
Fitri dia yang sala.
Kau bilang salah.
Om imam pu muka perahu terlepas.
Saya punya parang itu sudah tonda.
Pala satu laksa.
Ciput telinga sakit itu di manggi-manggi ada.
Saling keranjang itu.
Burung teduh itu dia suara itu teduh.
Musang dia lubang kelapa hampir semua.
Angin barat daya dia jalan sampai putih.
Nazua itu dia pakai kalung manik-manik.
Baju ini tipis.
Orang Baham yang datang.
Ona pu saudara itu cacar air yang bikin dia.
Maimai kelapa itu dia makan kelapa lubang dia.
Ember itu pu penutup su hilang.
Alun pu bapak pi cari Alun.
Usman ikat semang di dia pu perahu jonson.
Bakri pu mama dia bakar sagu.
Lubang papan itu Irjan pu bapak su tutup.
Burung cenderawasih itu kalau dia suara meti kei itu dia pu bagus.
Burung cenderawasih itu kalau dia suara meti kei itu dia pu bagus.
Moktar potong cabang kayu.
Kayu besi satu yang patah.
Rumah atap itu sudah tarombak.
Mei pigi pancing la hela ikan anja banyak sekali.
Sundus dia pakai kitong punya jangkar.
Tataruga satu yang timbul di sana.
Ladeka pegang ikan taiseng.
Om Ipin dorang yang naik dari Antalisa.
Kitong semua pi panjat pala.
Alif yang bikin kertas itu dia bunyi.
Kutu hujan yang burung walet makan.
Burhan su pigi buang saya pu kaca mata.
Teripang nenas itu sekarang ini su tidak ada.
Rajiba mama yang pu topi sawa satu.
Bakri pu bapak dorang pigi pancing tongseng lagi.
Pagi Dian pu bapak dong mau pigi di Fakfak tapi perahu kandas.
Ibu guru pu mama dorang yang pu halia ada banyak.
Faris dia pu bapak suruh dia tapi dia pamalas dia pu bapak kejar dia.
Di Tarus itu baru ada tebing.
Di Tat itu ada pohon dedap satu pohon di situ tapi sudah mati.
Di Mas itu buah jambu banyak.
Di Mas sikaru kecil itu ikan makan.
Ubi kayu itu sudah tunas-tunas lagi.
Unyil pu bapak cukur dia pu kumis. ; Irul runcing dia pu pinsil.
Bakri pu mama dia pu ayakan ada.
Di Pasir Kecil itu ada halia hutan.
Dia ambil kayu bakar tapi dia cepat kembali.
Supri pu mama dia legu tali pancing di jembatan dia hela ikan so.
Mei dia ikut dia pu semang perahu.
Tami bapak dorang pigi potong bambu kecil mau bikin asaran pala.
Suci mama pesan sendok dengan Bilal mama.
Tadi malam tiu hujan tara turun.
Unyil pu mama dong nonton itu sampai larut malam.
Nanti bulan puasa itu anak-anak panggil sahur itu kitong sudah bangun.
Lampu mati itu kampung sudah gelap.
Saya turun gelap itu saya raba-raba turun.
Sawarer itu di laut ini banyak.
Pala su tua.
Tali turun dari batu itu di Namandar itu ada.
Gustami itu kitong suruh dia itu terlalu pamalas.
Pohon pala itu hujan jadi dia licin.
Bunga pala satu kali ini dia punya harga bagus.
Pala biji juga pu harga baik.
Sainudin itu dusun pala banyak.
Sudir dorang ambil kuskus satu dorang ikat di pohon kendondong.
Binkur pu bapak dorang bikin bak tapi su habis.
Soasoa satu ekor pi di laut makan Rusam pu ayam satu ekor.
Kitong potong kayu soasoa itu soasoa ikut kitong.
Parang itu pu harga berapa?
Ardi pu bapak pi pancing di kelat.
Orang Sekar itu tidak datang di sini.
Yanti itu su tara sekolah lagi.
Fasal bapak itu isap seklilin.
Pigi pakai kau pu baju sepanggal.
Unyil pu anak takut saya.
Ikan garis-garis itu di pinggir jembatan ada.
Anak-anak dong bermain tendang bola di Tat.
Randa mama itu dia orang penakut.
Dia pu mae tua berenang dalam air sampai begini.
Nanti hari senin baru Camat datang.
Saya kasih naik pala di atas loteng.
Saya gai-gai pala.
Dong pigi menyelam tapi gatal-gatal banyak.
Bakri pu tete suruh Kiba pu bapak gosok daun gatal di dia pu belakang.
Faldi dong pigi panah ikan la gatal-gatal laut kenal dia.
Burhang dorang pigi menyelam ikan hias dong mau piara.
Irul mama kupas keladi.
Rifai pu mama pigi pancing hela ikan tasbe banyak.
Bobi mama gatal-gatal di paha kenal dia.
Tami pu bapak pi cari umpang.
Lamani pu bapak potong kayu bakar la mancadu tersimpir kenal dia pu kaki.
Kampung ini dia pu nama Mas.
Satawia bapak pigi pancing la dia hela ikan racun.
Angin jalan putih su tidak baik sekali.
Gatal laut kenal saya. ; Tomi dia gosok parang.
Anak-anak itu main di ujung-ujung.
Bayu esun dia potong ujung tali.
Nabil pu mama ingus bikin dia, dia bersin.
Kucing makan say pu ikan saya tidak tahu.
Waktu itu di tanusan Tiporat itu teripang trompet itu banyak.
Burung pantai satu yang jalan-jalan di pantai sana.
Jafaris eh, jonson itu kasih pelan!
Merpati uncal itu di Tanah Besar ada.
Ciput besar itu nasib baru kitong dapat.
Saya yang kemuka dia di belakang.
Aina pu mama dorang ambil daun tikar mau bikin tikar dengan.
Salima pu mama mau jahit pakain tapi jarun tidak ada.
Unyil dorang pu rumah itu semut banyak.
Burung cuit satu bikin dia pu sarang di sana.
Suryan pu mama bikin sinali tumang.
Cuaca sudah terang.
Bobi pu mama garam ikan.
Tami pu mama dia bikin sapu-sapu.
Saya pu tungku itu sudah patah.
Rukmana pu mama suruh Rukmana pi beli sirih.
Ikan bisa kenal Madi pu mama.
Saya mau sisir rambut tapi sisir tidak ada.
Nanti malam dulu baru kita tahlil.
Salima pu bapak kupas kulit kayu buah-buah.
Subuh dia sudah pigi di Fakfak.
Binkur bapak ikat tali sampai keras.
Hawa pu anak kecil itu dia cikukan.
Tali rotan di sini tidak ada.
Tomi mama cigi tembang mau makan.
Orang itu datang bikin apa?
Yo, betul sudah mu!
Kitong dua su pulang sudah mu!
Satu orang meninggal di Faur.
Orang-orang itu semua pigi di mana?
Orang itu dia suanggi.
Tol pu mama itu orang luar.
Dia pu contoh bagaimana?
Mama Agus dorang datang jual kep.
Kitong tidak ada ikan.
Tulang ikan yang Mustafa pu bapak bakar.
Tami mama bikin ikan garam.
Irul pu mama dorang pigi di Sorong.
Tunggu saya lujur saya pu kaki di atas meja dulu.
Dian pu bapak dorang pi luncur papan.
Di Randa pu mama dorang itu tikus banyak.
Burhan itu pu celana longgar.
Halim sudah cukur dia pu babar.
Irjan pu bapak dia hela ikan komo banyak.
Nyong mama dorang parut ubi kayu mau bikin suamin.
Itu di atas kampung itu ada lubang batu satu.
Kiba pu bapak dorang pigi pancing di pinggir rep.
Juaria dong bual cacing mau pigi pancing.
Papan ini dia ringan.
Nabil mama bilang dia senang baju itu.
Selagur Wadan tidak mau: "Kau duluan!"
Papan ini dia ringan.
Arlan pu nenek bikin tali keranjang.
Pace desa pigi potong sambuku mau bungkus di kaki.
Jafaris dia beli dia pu celana empat pasang.
La Deka kupas kelapa mau bawa pigi jual.
Faris dong pana ikan lompat-lompat.
Saya duduk mencuci la belakang sakit.
Dia pu tulang belakang yang sakit.
Saya pu tulang belakang sakit.
Jikri dia tikam kura-kura kenal di atas belakang.
Belut satu yang ada di dalam batu itu.
Angan su jalan itu kitong mau pi susah.
Ayah Tok bakar kebun la api menyala makan pagar.
Madi dorang su pigi?
Ka pu kantung yang ini?
Kita keluar dari Temi Nepnep, angin begitu.
Binkur bapak dorang potong kawat mau bikin bak dengan.
Rokok di kampung ini tidak ada.
Kayu itu berapa potong?
Supri pu mama dia pancing di jembatan dia hela ikan tefar satu.
Katong pu bak itu air se tengah.
Onin bapak dorang dengan Suci pu bapak dorang baku tabrak.
Bakri pu bapak pasang timah di jaring.
Irul pu mama dorang bikin sayur nangka.
Aina pu mama dorang pigi potong bambu.
Madi pu mama dorang pigi pilih siput.
Di pinggir Talok itu ada ciput kecil.
Kayu ini pendek.
Alun pu tete itu dia batuk.
Irul dorang pigi tembak burung dorang dapat lihat kanguru satu.
Biar air garam kenal lagi baik.
Bikin dapur, baru, atap tidak sampai ambil atap lagi.
Supri dia berdiri buka kaki sampai.
Pala satu karung ini berat.
Hasrun dia hela ikan tenggiri dua ekor.
Angin timur jalan kitong su tara makan ikan.
Nanti musim angin timur baru burung merpati Kaimana datang.
Nanti musim timur baru orang bikin teripang.
Paku lepir sebelah darat!
Nabil pu mama orang su pigi mungkin setengah jam.
Saya sendiri kasi dia baju saya punya itu.
Papan ini semua berapa lembar?
Randa mama dia petik belimbing mau masak ikan dengan.
Mustafa pu bapak ikat pagar kayu.
Dalima dorang di luar itu.
empat puluh satu
Irjan pu bapak dia tikam ikan kulit tebal satu tapi dia terlepas.
Satu yang mana yang ko ambil?
Kalo uang tidak ada kita mau bikin bagaimana? ; Kabar bagaimana (kabar baik)?
Kamong pulang dari mana? Tarada o, dari sana.
Mustafa pu bapak petik tomat banyak.
Rajiba pu mama taruh beras di mana?
Dorang ke mana? Tarada o, dorang pigi di sana.
Kalamang dorang pigi di Antalisa.
Yahyah pu mama dia pu tangan sakit.
Tomi pu mama dia pu pergelangan tangan sakit.
Bakri pu bapak pilih kerikil dia pu telapak tangan sakit.
Rustam pu nenek itu dia tangan kanan.
Burung elang turun tangkap Sakina dong pu anak ayam satu ekor.
Muklis bapak pu perahu fiber itu rejeki.
Desi belum potong kuku.
Cincin itu Rajia pu mama punya.
Kau pu jari kelinci itu apa yang kenal?
Nona Marni kau pegang apa itu?
Meti pagi itu ikan peti pigi di darat makan rumput lamun.
Pohon manggi-manggi di sana banyak yang su mati.
Kau pu sika kenal apa?
Siapa yang sudah buka pintu?
Biji pala itu pu harga bagus.
Di Baki Tanggiun itu ketapang banyak.
Bayu pu bapak bilang dia pu ibu jari luka.
Binkur pu bapak dia pu jari tangan luka.
Mama pasang cincin satu di jari manis.
Gani dia pu jari tengah batu kenal.
Saleha itu pu jari telunjuk bengkak.
Rustam itu dia tangan kiri.
Ona pu mama bakar tempurung.
Binkur pu bapak minta pahat di Salima pu tete.
Suryan pu mama dia mengantuk la dia turun baring-baring.
Dulu itu dia Tetar kanguru banyak.
Mustafa pu mama dorang beli tepung terigu satu sak di Fakfak.
Hujan turun setan api suara.
Kiba pu bapak lingkar tali pancing.
Kamong iskap papan!
Faldi yang tutup pintu.
Moktar pu bapak tanya Dian pu tete: "Kau pu cucu di mana?"
Anak-anak beribut la Unyil pu anak dia kaget.
Tali hutan itu di Yahya dong pu kebun ada.
Kau pu tali itu berapa depa?
Air su naik jadi angin selatan sudah jalan.
Dian pu nenek pigi pancing tapi dia pu mata kail putus.
Tiang jembtan sana itu tirang banyak.
Unyil mama pu tumit kaki sakit.
Irjan pu bapak pigi balobi dia tikam ikan tanduk satu ekor.
Onin mama yang su bilang dengan dorang.
Kau pu tete yang itu.
Di Perusahan baru ada orang Buruwai.
Kau pu nenek itu bikin apa?
Saya belum lihat sayu pu moyang perempuan.
Dong pu moyang laki-laki su meninggal.
Burung merpati Cina satu pu sarang sana.
Dorang separuh yang pigi di sana.
Nyong dia pikul semen satu sak itu sampai bengkok-bengkok.
Kelapa satu tumpuk yang di sana.
Aina dorang cincang kelapa.
Tamandi pu mama angkat pakain.
Dorang lipat kertas isi nasi bungkus.
Bahasa itu sudah tidak baik.
Unyil pu mama pu kaki luka tapi ada nanah.
Dia beli satu kilo berapa ribu
Mereka tangkap dia bawa datang.
"Kau itu di belakang!"
Kamu bikinbikin kerja apa?
Bakri dia panah ikan di pinggir air biru.
Tomi pu mama dia pigi pancing paki lot di Mas pu di laut.
Nabil pu bapak dia kasih Maryam pu mama kelapa semua.
Dong susun batu, mau bikin rumah.
Ayah Tok lutur pagar batu.
Perempuan injak pasir, baru kita taru pasir di dia pu testa.
Maryam pu mama turun dari Gorom dia kasih saya pisau satu.
Bia sekarang ini kitong susah baru dapat.
Rajiba pu mama dia potong kenari la tampias.
Manado hela ikan mamin satu ekor.
Ayam itu saya lempar dia tapi dia tetap.
Di Suo itu kumbili pasir ada.
Di Tonggerai itu bia kecil banyak.
Afokat itu angin tiup la dia bergerak.
Ikan tefar besar-besar.
Dia berdiri di ujung batang kayu.
Sakina pu baju itu besar sekali.
Ada anak besar satu kecil satu. Yang besar bilang besok...
Kiba pu bapak pu perahu kayu sudah rusak.
Makanan yang kotor bisa kau makan.
Orang tidak pi pancing (jadi) uang tidak ada.
Mayor pu lunas perahu tambelu sudah makan.
Kue itu sudah rusak.
Rustam pu nenek bikin batang lidi.
Burung elang bondol satu ekor yang duduk di caga kayu di sana.
Dia su panggil dorang, datang ambil kamong pu barang, kumpul kamong pu barang o!
Orang-orang semua kumpul di sana.
Anjing makan ayam la dia pu bulu di sana.
Musim kabut.
Afokat ini sudah berbuah.
Anak makan dua buah pisang.
Desi minta tepeles di saya.
Air biru itu dekat.
Fit dia beli teh di Sakina dorang.
Gustami pu bekas bisul di paha.
Meti itu sudah kering dari tadi.
Usman dorang lari dengan jonson pi di darat naik di meti-meti karang.
Dong terus pigi di Tarus.
Mangga itu dia pu buah ada.
Baju itu lakilaki pu baju.
Onin pu mama dorang pigi di distrik lama.
Onin pu mama dorang pigi di distrik lama.
La Deka panjat kelapa pigi di ujung kelapa.
Dian pu mama pu test tatoki.
Aina dong pigi di Teluk Sebakor potong pisang.
Aina dong pigi di Teluk Sebakor potong pisang.
Di Tanah Besar sana itu masih hutan rimba.
Anak-anak dorang lomba lari.
Dela pu bapak beli tifa di Fakfak.
Tanjung Tiporat itu ayah tok pu kebun di situ.
Bilal pu bapak belum datang.
Batang yang dekat ujung, masih lembek.
Saya haria saya punya tali nika dulu.
Belum! Jangan kau datang ke sini dulu!
Kambing itu masih hidup.
Belum, kita masih sobek.
Ikan serui itu di Mas ada.
Cikcak satu yang meraya di pinggir dinding sana.
Nanti dulu kitong pigi.
Saya pi di gunung tapi tidak tahu jalanan lagi.
Saya pu mama masih hidup.
Burung pekakak satu yang di sana.
Jafaris dengan Burhan dong puasa.
Nabil pu bapak pu tali nika satu orang potong.
Nenek Ruslan bikin noken.
Tempat air ini semua sudah penuh habis.
Abdulah pu bapak dorang di Tonggerai.
Manado bilang dia mau pigi pancing tapi angin.
Dia tebang, dia bilang mau sambung (pinang hutan supaya) ambil dia pu anjing.
Malik dia pigi goyang-goyang ikan lalosi.
Bibi Kambur pu mama dia jual terong.
Yasin pu bpak dorang pigi di Tarak.
Madi pu kaki parang kenal dia terbuka.
Dulu itu orang masih beli lola, sekarang ini sudah tara beli lagi.
Di pinggir jembatan itu duri babi banyak.
Rajia pu mama itu dia belum kawin.
Sakina pu mama pukul dia.
Nenek tumbuk pinang.
Dulu itu Gani dorang tinggal di Kambur.
Ikan bisa satu ekor tikam Saula.
Gustami tusuk dia pu bapak dari lubang.
Dong dari Tuberuasa pigi di laut jual durian.
Di Distrik itu buah semangka ada di sini tidak ada.
Dulu itu baru kutu busuk ada, sekarang ini kutu busuk tidak ada.
Saya pu anak masih di sekola.
Dian pu babapk bikin rumah kecil.
Dian pu bapak punya anak lakilaki tidak ada.
Halim itu pu anak permpuan.
Saya goyang pala di karung.
Dorang goyang pasir di karung.
Om Nos ikat pagar paki tali maurat.
Kitong pu bubungan rumah bocor.
Malik kasih naik bambungan dapur.
Muklis dia lari dia jatuh.
Kindius itu bukit.
Saya pu om pu istri itu saya panggil bibi.
Bakri pu mama mau bikin sagu tapi nyiru tidak ada.
Kau pu bapak pu saudara kau panggil itu bibi.
Bayu pu bapak pu kemudi picah.
Kau tahan kencing itu nanti kandung kemih pecah.
Bilal pu bapak pigi buang jaring, dia dapat ikan jengkot yang banyak.
Rehan kencing di air garam.
Dia kasih tunjuk dia pu diri
Dia hela ikan tefar sedikit.
Kitong pu anak tidak ada.
Tamandi pu bapak hela anja satu ekor tapi dia pu lemak saja.
Lamani pu bapak dong pu guci satu ada.
Angin timur tiup datang dari teluk Buruwai.
Randa dorang panjat mangga dorang baku bagi.
Mama sudah habis melahirkan.
Bobi pu mama pigi tonda ikan bubara.
Dian pu mama dorang pigi di Fakfak, air laut teduh.
Irjan pu bapak dong pigi cari pohon nibun tapi tara dapat.
Angin timur sudah jalan itu daun kuning sudah kering.
Angin tadi malam itu jalan.
Awan hitam dia naik.
Kita mau pigi tapi ombak besar.
Jalanan turun dari sekolah itu licin.
Kitong pigi di Kambur itu ombak.
Onin pu mama dorang tiba-tiba berangkat pigi di tanjung.
Yusra itu telanjang dia pu kemaluan keluar-keluar.
Saya duduk kasih lurus daun tikar.
Malik dia kasih berdiri dapur.
Jikri dong pancing di tanusan Kambur.
Dalima dorang pancing di jembatan la hela ikan kulit tebal putih.
Dian pu tete dia tandah pohon sukun.
Salima pu mama dia bikin kue tersendiri.
Kalamang pu mama itu orang Buton.
Di Sakina dorang pu rumah itu cikcak warna coklat ada.
Supri pu bapak dia datang dari Gorom.
Di laut kampung ini itu arus kuat.
Anak-anak lempar mangga dengan kayu.
La Deka panjat daun kelapa mau pigi pancing.
Nabil pu nenek dia bikin lidi.
Saya duduk gulung daun tikar.
Kau su berapa kali datang?
Nanti kau bikin begini.
Ini kau punya tidak?
Desi itu mandi satu kali.
Riski pu mama itu datang satu-satu kali.
Di tanjung Wanim itu ombak.
Faldi sudah dua kali makan.
Rajiba bapak pi pancing.
Dia pakai ilmu sihir dengan saya.
Perempuan suanggi dorong dia di air garam, ambil dia pu rupa.
Muklis pu bapak hela ikan hiu garis-garis satu ekor.
Nyong dorang menyelam akar bahar.
Jana dia dapat kulit ciput satu.
Mama Gorom bilang dia duduk tapi dia pu badan merinding.
Ciput berduri satu di bawah jembatan.
Meti su mau kering sampai hilang.
Meti kering la Madi pu mama pigi pilih ciput.
Air sudah naik perahu sudah berlabu.
Kalau malam itu air pono.
Kalau su hampir siang itu air su turun.
Saya pu rambut kotor saya cuci dengan sampo.
Fatimah dorang pigi gali ciput di pasir.
Kiba pu bapak panjat kelapa tapi kalongkong.
Aina pu mama dia kukur kelapa mau masak minyak.
Gani donrang pigi panjat kelapa kering.
Alun pu bapak panjat kelapa muda mau bikin bubur kelapa.
Rustam ada di sini.
Di Tanah Besar baru kelapa hutan banyak.
Nyong pu bapak lagi dia pigi.
Di Kambur itu lola laki-laki banyak.
Dela dong pigi petik sayur genemu.
Rustam pu baju bola itu warna biru.
Sarang madu satu di sana tapi sudah rusak.
Mei punya pokpok sudah karat.
Dela itu dia pu rambut tebal.
Binkur pu bapak mau pigi ambil kayu tapi kampak tidak ada.
Mangga su mulai tua.
Binkur pu bapak mau pigi pancing tapi dia pu tali pancing tidak ada.
Ikan kakatua biru satu kawan yang lari pi di sana.
Madi pu mama pigi tonda-tonda.
Gustami pu mata pasir di dalam dorang buka bara tiup.
Kemarin dorang dari Tuberuasa datang jual durian.
Dulu itu harga lola masih baik.
Burung urip kepala hitam itu di Tanah Besar baru di kampung ini tidak ada.
Burhan dorang panggil Tami pu mama itu tante.
Saya pulang dari bibi kecil dorang.
Belalang satu ekor di situ.
Supri yang bersiul itu.
Malik yang rubu pohon pinang itu.
Tadi malam itu saya mimpi la? orang datang.
Pak guru Banda cari burung kakaktua mau beli.
Kakatua raja itu di tanah besar itu banyak.
Lubang kakatua satu di Kamberar.
Penggayung gufasal itu siapa punya?
Siapa dorang yang bersama itu?
Siapa dong yang bagi beras jata itu?
Ruslan pu mama dia tanam kumbili.
Sakina dong jual petatas.
Batu ini pu nama Yar Dakdak.
Di om Nostal pu pinggir rumah itu batu tajam-tajam.
Nyong pu mama dorang pilih batu kerikil mau cor dorang pu rumah.
Di Langgor itu ciput bia batu banyak.
Di air Kiti-kiti itu batu buntal banyak.
Di Kamberar itu pu tempat batu-batu
Di Sowir itu ikan lompat ada di situ.
Bakri pu mama dia bakar kapur lagi.
Bakri pu bapak dong yang pulang pancing.
Kitong masak kayu obat.
Suster dorang bagi obat cacing.
Apa begitu saya tidak tahu.
Kalamng sudah tahu berenang. Rehand belum tahu berenang.
Dia bilang di laut ini.
Barang satu itu mana dia?
Berapa hari kamong pigi?
Muklis pu bapak dong kapan dorang pigi di Fakfak?
Barang apa satu yang menyala-menyala sana?
Matahara ini hari kurang panas.
Usman dia gosok lumut perahu.
Aduh, tuhan o, matahari sembeleh kau!
Unyil pu bapak dong pigi di gunung pulang itu mata hari sudah turun.
Ini sudah musim panas.
Moktar dorang mau pigi tapi matahari su tinggi.
Kita tidur matahari su naik.
Rajiba pu mama dia tanam bunga raja di jalan.
Di sekolah itu sudah rumput-rumput sampai peli-peli.
Bakri dengan Jikri dorang dua berkelahi tapi Bakri itu benar Jikri itu salah.
Betul, kitong turun kembali habis.
Jalan ini lurus lagi.
Aisa dia pesan ciput di saya.
Fitri kau cari siapa? Saya cari Alif. Ini dia.
