import json

def create_json(file1_path, file2_path, output_path, lang1="en", lang2="gn"):
    # Open the two files and read the lines
    with open(file1_path, 'r', encoding='utf-8') as f1, open(file2_path, 'r', encoding='utf-8') as f2:
        lines1 = f1.readlines()
        lines2 = f2.readlines()

    # Check if both files have the same number of lines
    if len(lines1) != len(lines2):
        raise ValueError("The two files must have the same number of lines.")

    # Create a list of dictionaries
    data = []
    for line1, line2 in zip(lines1, lines2):
        data.append({
            lang1: line1.strip(),
            lang2: line2.strip()
        })

    # Write the data to the output JSON file
    with open(output_path, 'w', encoding='utf-8') as out_file:
        json.dump(data, out_file, ensure_ascii=False, indent=4)

# Example usage
file1 = "/home/saycock/personal/mtob/splits/flores.dev.en"  # Path to the file containing English sentences
file2 = "/home/saycock/personal/mtob/splits/flores.dev.gn"  # Path to the file containing Guarani sentences
output = "flores_dev_examples_en-gn.json"  # Path for the output JSON file

create_json(file1, file2, output, lang1="en", lang2="gn")
